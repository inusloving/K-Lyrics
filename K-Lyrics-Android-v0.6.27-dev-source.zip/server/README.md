# K-Lyrics Study API

This optional backend powers online Korean sentence analysis and on-demand line translation. The Android client stores only the HTTPS endpoint and a revocable app access token. The model-provider API key stays on the server.

## Configuration

Use Node.js 20 or newer. Set these environment variables on a trusted server:

- `OPENAI_API_KEY`: provider credential; server-side only.
- `APP_ACCESS_TOKEN`: a long random access token for this app's requests.
- `OPENAI_MODEL`: optional model override; default is `gpt-6-astra`.
- `OPENAI_API_URL`: optional Responses API endpoint override; defaults to the official OpenAI endpoint. Use only a trusted HTTPS endpoint in production.
- `PORT`: optional listening port; default `8080`.
- `MAX_REQUESTS_PER_MINUTE`: per-IP request limit; default `20`.

Copy `.env.example` into the hosting platform's secret/environment settings. Do not commit real values. Put the service behind HTTPS before configuring the Android app. The service never logs lyric request bodies or credentials and sends `store: false` to the model API. It accepts JSON only, caps request bodies at 24 KB, applies per-IP rate limits with bounded in-memory buckets, and configures HTTP socket timeouts, and rejects provider responses larger than 1 MB while streaming them (without buffering an unbounded response).

## Run

```bash
npm test
npm start
```

`GET /health` checks process health. `POST /v1/study` accepts `{ "task": "translate" | "translate_batch" | "analyze", "text": "...", "targetLanguage": "简体中文" }` and requires `Authorization: Bearer APP_ACCESS_TOKEN`.

This is a reference backend, not a hosted service. Online AI features remain unavailable until a trusted operator deploys it, configures provider credentials, and enters its HTTPS URL and app access token in K-Lyrics.
