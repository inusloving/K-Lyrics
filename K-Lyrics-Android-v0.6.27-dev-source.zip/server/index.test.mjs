import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import http from 'node:http';

const port = 18_887;
const base = `http://127.0.0.1:${port}`;
const upstreamPort = 18_888;
let child;
let upstreamServer;
let upstreamMode = 'valid';

before(async () => {
  upstreamServer = http.createServer((_req, res) => {
    if (upstreamMode === 'oversized') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ output: 'x'.repeat(1_000_100) }));
      return;
    }
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ status: 'completed', output: [{ type: 'message', content: [{ type: 'output_text', text: '테스트 번역' }] }] }));
  });
  await new Promise(resolve => upstreamServer.listen(upstreamPort, '127.0.0.1', resolve));
  child = spawn(process.execPath, ['index.mjs'], {
    env: { ...process.env, PORT: String(port), OPENAI_API_KEY: 'test-only', APP_ACCESS_TOKEN: 'test-token', OPENAI_API_URL: `http://127.0.0.1:${upstreamPort}/responses` },
    stdio: 'ignore'
  });
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`${base}/health`);
      if (response.ok) return;
    } catch { /* server is still starting */ }
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('test server did not start');
});

after(async () => { child?.kill('SIGTERM'); if (upstreamServer) await new Promise(resolve => upstreamServer.close(resolve)); });

test('health endpoint is public and returns process status', async () => {
  const response = await fetch(`${base}/health`);
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { ok: true });
});

test('study endpoint rejects missing or incorrect app access token', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ task: 'analyze', text: '안녕하세요' })
  });
  assert.equal(response.status, 401);
  assert.deepEqual(await response.json(), { error: 'unauthorized' });
});

test('study endpoint validates task before contacting model provider', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'unsupported', text: '안녕하세요' })
  });
  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'invalid_task' });
});

test('study endpoint rejects oversized lyric payloads', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'translate', text: '가'.repeat(2_001) })
  });
  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'invalid_text' });
});

test('study endpoint recognizes the batch-translation task', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'translate_batch', text: '' })
  });
  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'invalid_text' });
});

test('study endpoint requires JSON content type', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { authorization: 'Bearer test-token', 'content-type': 'text/plain' },
    body: '{"task":"analyze","text":"안녕하세요"}'
  });
  assert.equal(response.status, 415);
  assert.deepEqual(await response.json(), { error: 'unsupported_media_type' });
});

test('study endpoint rejects malformed JSON without exposing parser details', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { authorization: 'Bearer test-token', 'content-type': 'application/json' },
    body: '{broken'
  });
  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'invalid_json' });
});

test("invalid credentials do not consume the authenticated client rate limit", async () => {
  for (let index = 0; index < 30; index += 1) {
    const response = await fetch(`${base}/v1/study`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Bearer wrong-token' },
      body: JSON.stringify({ task: 'analyze', text: '안녕하세요' })
    });
    assert.equal(response.status, 401);
    assert.deepEqual(await response.json(), { error: 'unauthorized' });
  }
  const valid = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'unsupported', text: '안녕하세요' })
  });
  // It reaches task validation, proving invalid-token traffic did not exhaust the bucket.
  assert.equal(valid.status, 400);
  assert.deepEqual(await valid.json(), { error: 'invalid_task' });
});


test('study endpoint rejects requests above the byte limit before parsing', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'translate', text: 'x'.repeat(30_000) })
  });
  assert.equal(response.status, 413);
  assert.deepEqual(await response.json(), { error: 'request_too_large' });
});

test('study endpoint rejects oversized upstream provider responses', async () => {
  upstreamMode = 'oversized';
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'translate', text: '안녕하세요' })
  });
  assert.equal(response.status, 502);
  assert.deepEqual(await response.json(), { error: 'invalid_upstream_response' });
  upstreamMode = 'valid';
});

test('study endpoint returns a valid bounded provider result', async () => {
  const response = await fetch(`${base}/v1/study`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
    body: JSON.stringify({ task: 'translate', text: '안녕하세요' })
  });
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { result: '테스트 번역' });
});

test('study endpoint enforces the per-IP request limit for authenticated clients', async () => {
  let last;
  for (let index = 0; index < 30; index += 1) {
    last = await fetch(`${base}/v1/study`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: 'Bearer test-token' },
      body: JSON.stringify({ task: 'unsupported', text: '안녕하세요' })
    });
    if (last.status === 429) break;
    assert.equal(last.status, 400);
  }
  assert.equal(last.status, 429);
  assert.deepEqual(await last.json(), { error: 'rate_limited' });
});



