# K-Lyrics Android v0.6.27-dev — development build

K-Lyrics is an Android companion for Korean lyrics while listening in Kugou Music. It reads the active Kugou media session, displays the current lyric line in a floating window, and keeps lyric data on-device.

## Implemented in this source snapshot

- Detects Kugou media sessions and reads track metadata, playback state, and estimated playback position.
- Imports timestamped `.lrc` files and plain-text lyric files.
- Looks up lyrics through the public LRCLIB API after the user explicitly taps the online-search button, or automatically after a track change when the opt-in setting is enabled. Timed LRC is preferred; plain lyrics are also accepted for static display and manual calibration. The lookup sends the current track title and artist; a match is cached locally.
- Supports line-by-line manual timing for plain-text lyrics using the current playback position. If the player does not expose a usable position, the overlay falls back to a scrollable static full-lyrics view; a local elapsed-time estimate can still support calibration after playback detection, but should be started from the beginning for accuracy.
- Imports a UTF-8 text file of Chinese translations, one line per lyric line.
- Displays Korean lyrics and imported Chinese translations in the floating overlay.
- Tap a Korean word to open a small offline dictionary panel; tap the sentence to see fixed-pattern grammar hints. The curated offline dictionary includes selected ㄷ/르/ㅂ/ㅅ irregular conjugations dictionary-backed connective forms (-고, -지만, -아/어서, -(으)면), selected adnominal forms (-는, -(으)ㄴ, -(으)ㄹ, -던, -았/었던), and selected nominalized -기 forms and remains conservative for unknown words. The learning panel can use the device's installed Korean text-to-speech voice for word or sentence playback.
- Includes an optional HTTPS AI client and reference Node.js backend for sentence analysis and on-demand line and batch translation; deployment and provider credentials are external prerequisites. The server requires a revocable app access token and keeps the provider API key server-side.
- Switches between simple and detailed learning views.
- Adjusts overlay font size, background opacity and color preset; drag the title bar to save its position.
- Exports/imports portable `.kllyrics` backups containing original lines, translations and timing data.
- Caches lyrics, translations, and manual timestamps by normalized title + artist.

## Known limitations

- This version does not read or decode Kugou's private KRC files. Online results depend on LRCLIB coverage and may be unavailable for some tracks.
- Manual online lookup requires an explicit tap. Optional automatic lookup is off by default and must be enabled in the app; it sends the playing track title and artist to LRCLIB.
- Chinese translation can be imported from a text file or generated on demand per line / in small batches through the optional AI backend.
- The offline learning dictionary is a small curated set with explicit conjugation mappings conservative recognition of the plural marker 들 before supported particles, and explicit nominalized -기 forms for selected dictionary entries; it is not a full Korean morphological analyzer. Unknown words are not guessed; grammar results are pattern hints, not complete syntax analysis.
- IPA transcription and bundled pronunciation recordings are not implemented; spoken pronunciation depends on the device's installed Korean text-to-speech voice. AI features require a separately deployed HTTPS backend and a server-side provider credential; no hosted endpoint or credential is included.
- Device-specific Xiaomi/Android 16 validation is not complete in this source snapshot.
- An Android SDK/Gradle environment is required for a full APK build. Passing the pure Kotlin logic tests does not prove the Android app works on a device.

## Build

From this directory, run the Android build:

```bash
gradle testDebugUnitTest assembleDebug
```

The optional AI backend has its own checks:

```bash
cd server
npm test
```

The GitHub Actions workflow runs backend tests, Android unit tests, and the debug APK build on pushes/pull requests to `main` and on manual dispatch. It verifies the APK exists and publishes the APK plus SHA-256 checksum as a 14-day workflow artifact. The workflow configuration has not yet been executed in this environment; the first successful CI run is still required to confirm a full Android build.


### v0.4.2-dev notes

- AI study results are displayed by task (analysis vs. translation) rather than mixing whichever cached response was found first.
- Repeating a completed sentence task reads the local cache before making a network request; cached translations still synchronize to the selected lyric line.
- Android build and device integration remain unverified in this environment.


### v0.4.3-dev notes

- Batch translation responses are validated before they are mapped back to source lyric lines. The parser rejects missing/extra lines, mixed numbering, duplicate or out-of-order indices, and explanatory commentary that could shift line alignment.
- Added focused parser tests; standalone Kotlin smoke checks and the 9-test Node backend suite pass.
- Full Android Gradle build and Xiaomi Android 16 device validation remain outstanding.


### 0.4.4-dev hardening

- LRCLIB response bodies are capped at 1,000,000 characters and oversized responses are rejected rather than truncated.
- Track changes cancel obsolete queued lyric lookups to reduce stale background work when skipping rapidly between songs.
- Added bounded-reader boundary tests.


### v0.4.5-dev hardening

The Android AI client now rejects oversized backend responses before parsing and bounds streamed response text. The local AI study cache is capped at 250 entries with least-recently-used eviction and per-entry size limits.


### v0.4.6-dev lyric matching hardening

LRCLIB result selection now uses a bounded pure Kotlin matching policy, validates title/artist/duration, and falls back to plain lyrics when a synced-LRC field is malformed. Added selector unit tests.

### v0.4.7-dev backend authentication hardening

- The study API now verifies the revocable app access token before applying per-IP rate limits or revealing whether the provider API key is configured.
- Invalid credentials no longer consume the legitimate client's rate-limit quota.
- Added regression coverage for unauthenticated quota isolation and authenticated per-IP throttling; the backend suite now contains 10 passing tests.

AI access tokens are encrypted locally with Android Keystore (AES-GCM); provider API credentials remain server-side only.


### v0.4.9-dev import safety

Text and translation imports are capped at 1,000,000 characters, and portable backup imports at 5,000,000 characters. Oversized files are rejected rather than loaded unbounded into memory.


### v0.5.0-dev backend response bounds

The study backend now caps streamed provider responses at 1 MB before JSON parsing, including responses without a declared content length. The provider endpoint can be overridden with `OPENAI_API_URL` for trusted deployments and integration tests; the default remains the official Responses API endpoint.


### v0.5.1-dev playback clock correctness

The monotonic fallback clock now treats zero as a valid start timestamp, ignores backward clock samples, and saturates position arithmetic instead of overflowing. Regression tests cover these edge cases.

### v0.5.2-dev local lyric-cache limits

Local lyric persistence now validates metadata, lyric row counts, per-line lengths, and timestamp values before writing. Oversized or malformed cached data is rejected or safely ignored on read, including corrupt calibration and translation records. This protects the SharedPreferences-backed cache from unexpectedly large imports and damaged stored values.


### Local cache limits (v0.5.3-dev)

The on-device lyric cache uses least-recently-used eviction and is bounded to 80 tracks or approximately 8,000,000 stored characters. The track most recently written is protected during an eviction pass.


### v0.5.4-dev cache behavior
The lyric cache now updates LRU recency on successful reads, with access-time writes throttled to one per track per five minutes to avoid frequent preference writes while the overlay refreshes.


### v0.5.5-dev cache behavior
Cache access recency is stored separately from the lyric content revision. Routine reads therefore do not trigger overlay content reloads, while LRU eviction continues to use last-access time.


### v0.5.7-dev lyric lookup validation
LRCLIB searches validate title/artist length and control characters, constrain track duration to a plausible 24-hour maximum, and do not follow HTTP redirects. Provider candidate durations are validated before scoring.


### v0.5.8-dev playback clock safety
MediaSession position extrapolation now validates playback speed and monotonic timestamps, and uses saturating arithmetic to prevent position overflow.


### v0.5.9-dev playback clock overflow fix
The playback fallback clock now also saturates safely when accumulating elapsed time during a pause transition, preventing a near-maximum position from wrapping to a negative value.


### v0.6.0-dev build compatibility
The Kotlin Gradle Plugin is now 2.3.0, aligned with Android Gradle Plugin 8.13.0 and the CI Gradle 8.13 toolchain. Full Android build validation remains delegated to CI.


### v0.6.2-dev CI hardening
GitHub Actions now uses read-only repository permissions, cancels superseded runs, applies a job timeout, checks backend JavaScript syntax, and reports Android unit-test and APK-assembly stages separately.

### v0.6.2-dev build toolchain
Android Gradle Plugin is pinned to 8.13.2 for the Kotlin 2.3 toolchain, with Gradle 8.13 and JDK 17 in CI.


### v0.6.3-dev tap-to-study
Sentence learning now extracts distinct Korean words and presents bounded one-tap shortcuts to the existing offline/AI word-learning view.


### v0.6.4-dev offline morphology improvement

- Recognizes dictionary-backed noun forms with the plural marker 들 followed by supported particles, such as 사람들이, 사람들은 and 사람들을.
- The detailed learning view displays the plural marker and case/topic particle separately.
- Unknown stems remain unknown rather than receiving guessed meanings.

### v0.6.6-dev

- Offline Korean lookup recognizes supported stacked particle sequences (for example, 에게+도 and 에서+만), including plural-marker forms when the dictionary stem is known.
- Detailed word learning displays stacked particles in grammatical order. Unknown stems remain unresolved rather than receiving guessed meanings.


### v0.6.7-dev — connective-ending lookup

- Added a bounded set of exact, dictionary-backed connective forms such as 가고, 먹고, 보고, 사랑하고, and 걸어서.
- The detailed word view labels connective endings separately from attached particles.
- Unknown stems remain unresolved; this is a curated lookup aid, not a general Korean morphological analyzer.


### v0.6.8-dev — expanded connective-ending coverage

- Added selected dictionary-backed contrast (-지만), cause/sequence (-아/어서), and condition (-(으)면) forms alongside the existing -고 forms.
- The learning panel labels the grammatical ending separately from particles, including contracted surface forms such as 추워서 and 기다려서.
- Added regression coverage for regular and irregular examples; unsupported stems remain unresolved.


### v0.6.9-dev — connective ending + particle parsing

Offline lookup can now resolve curated connective forms followed by auxiliary particles (for example, 가고도, 추워서도, 먹지만은). The connective ending and particle are displayed as separate grammatical components. Unknown stems remain unresolved rather than receiving guessed meanings.


### v0.6.10-dev — connective-ending explanations
- Detailed word study now explains the distinct functions of supported connective endings: -고 (coordination/sequence), -지만 (contrast), -아/어서 (cause/sequence), -(으)면 (condition), and -으며 (formal coordination/simultaneity).
- The grammatical explanation remains attached when an auxiliary particle follows the connective form.
- Added regression tests for each meaning and for connective-ending-plus-particle combinations. This is still a curated, dictionary-backed reference set, not a full Korean morphological analyzer.


### v0.6.12-dev — selected adnominal forms

Offline word lookup now recognizes a curated set of noun-modifying verb forms, including present `-는`, past `-(으)ㄴ`, and prospective `-(으)ㄹ` examples. Detailed learning mode labels these separately from connective endings. Recognition remains dictionary-backed and deliberately conservative; this is not a full Korean morphological analyzer.


### 0.6.12-dev
- Added selected explicit retrospective adnominal forms such as 가던, 갔던, 먹던, 먹었던, 봤던, 사랑했던 and 기다리던.
- Learning notes distinguish -던 from -았/었던 without claiming they are interchangeable.

### v0.6.15-dev — selected -(으)ㅁ/-ㅁ nominal forms

- Added exact, dictionary-backed noun forms 웃음, 울음, 믿음, 걸음, and 앎, linked to their source predicates.
- These entries show noun-specific meanings, part-of-speech labels, and example sentences rather than reusing only the source verb gloss.
- Supported particles remain separable (for example, 웃음도). Unknown forms are not guessed.
- Added regression tests for the five entries, noun glosses, particle attachment, and unknown-form rejection.


### v0.6.16-dev — additional adjective adnominal forms
- Added exact forms for 슬프다, 예쁘다, 힘들다, and 그립다, including present-state adnominals and selected retrospective past forms.
- The lookup notes distinguish ㅡ deletion, ㄹ deletion, and ㅂ irregular conjugation.
- Added particle-attachment and unknown-word regression tests.
- This curated lookup does not claim complete productive morphology; Android build and device validation remain pending.


## v0.6.17-dev

- Expanded the curated -음/-ㅁ noun inventory with 삶, 죽음, 얼음, 졸음, 묶음, and 엮음.
- Added noun-specific meanings/examples and regression tests for attached particles.
- Recognition remains exact-entry based; unknown forms are not stemmed speculatively.


## v0.6.18-dev — expanded lexicalized -음/-ㅁ nouns

- Added six dictionary-backed nominal forms: 갈음, 솎음, 수줍음, 서러움, 앙갚음 and 용솟음.
- Added source lemmas with concise glosses and examples; nominal forms display their noun sense rather than the source predicate gloss.
- Added regression coverage for exact lookup, attached particles, and unknown-word protection.


## 0.6.19-dev — distinguish lexicalized -음/-ㅁ nouns

- Corrected the grammar label for curated lexicalized -음/-ㅁ nouns: these are identified as derivational suffix formations and lexicalized nouns, not presented as the productive sentence nominalizing ending.
- Updated the learner explanation to prioritize the established noun meaning instead of mechanically applying the source verb/adjective gloss.
- Kept productive -기 nominalization distinct and unchanged.
- Added regression tests for the distinction and for particle attachment after a lexicalized noun.
- Reference: Korean orthography rule 19 distinguishes established -음/-ㅁ derived nouns and gives examples including 걸음, 묶음, 믿음, 얼음, 엮음, 울음, 웃음, 졸음, 죽음, 앎, 삶, 갈음, 솎음, 수줍음, 서러움, 앙갚음, and 용솟음.
- Full Android build and physical-device validation remain pending.


## 0.6.20-dev — offline dictionary consistency audit

- Added a test-facing integrity audit for dictionary lemmas, morphology-map targets, parts of speech, meanings, explanations, and Korean examples.
- The audit validates data structure and required fields; it does not replace expert review of linguistic correctness.
- Recognition behavior remains conservative and dictionary-backed.


## 0.6.22-dev — clarify lexicalized noun labels and examples

- Changed the learner-facing part-of-speech label for curated -음/-ㅁ lexicalized forms to “词汇化派生名词”, avoiding the ambiguity of calling them generic “名词化形式”.
- Improved the 엮음 example to demonstrate the noun in a grammatical sentence.
- Extended the dictionary integrity audit to require that each curated lexicalized-noun example actually contains the target noun form.
- Added regression coverage for the label, example quality guard, and retained particle handling.
- The distinction follows the National Institute of Korean Language explanation: derivational suffixes change the word class, while nominal endings make a predicate function like a noun without changing its part of speech.
- Full Android build and physical-device validation remain pending.


### v0.6.22-dev

- Clarified detailed study labels: lexicalized `-(으)ㅁ/-ㅁ` nouns are shown as derivational suffixes and established nouns, while productive `-기` forms remain labeled as nominalizing endings.


## 0.6.23-dev — preserve sentence context in word study

- Added track/artist and lyric-line context to the learning screen when available.
- Added same-sentence word switching from an individual word-study screen, preserving the source lyric line and track metadata.
- The selected word remains the pronunciation target; switching words does not discard sentence context.
- Android build and physical-device verification remain pending.


### v0.6.24-dev — word-study navigation

- Switching words within one lyric sentence no longer leaves a chain of word-study activities in the Back stack; Back returns to the sentence-study page.
- Track metadata, lyric context, line number, and sentence-keyed cached AI results remain available after switching words.
- Full Android build and device navigation verification remain outstanding.


### v0.6.25-dev — sentence translation in word study

- The sentence-level Chinese translation is now displayed directly beneath the source lyric on both sentence-study and word-study screens.
- Word-study screens load the sentence-keyed translation cache, keeping the translation visibly linked to the selected word's original sentence.
- Running AI translation updates this dedicated translation area; loading and failure states are shown there rather than being detached from the sentence.
- Android build and physical-device validation remain pending.


### v0.6.26-dev — selected-word highlighting

- The original Korean lyric sentence now highlights every exact occurrence of the currently selected study token on the word-study screen.
- Highlighting is presentation-only: the source sentence, translation cache key, tokenization, dictionary lookup, and TTS target are unchanged. A pure Kotlin range finder has regression tests for repeated, missing, blank, and overlapping matches.
- If the selected token is not present verbatim in the source sentence, the UI safely displays the unmodified sentence.
- Android build and physical-device validation remain pending.


### v0.6.27-dev — reproducible Android CI handoff

- Aligned the CI build with the project Android Gradle Plugin 8.13.2 requirement by using Gradle 8.13 and JDK 17.
- Made Android unit-test and APK assemble task paths explicit.
- Added toolchain diagnostics, APK existence validation, SHA-256 generation, and a versioned CI artifact name.
- Bumped the app version to versionCode 51 / versionName 0.6.27-dev.
- This change prepares CI validation; it does not claim that the workflow or APK build has already succeeded.
