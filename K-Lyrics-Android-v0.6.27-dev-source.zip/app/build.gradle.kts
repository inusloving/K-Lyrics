plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.klyrics"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.klyrics"
        minSdk = 26
        targetSdk = 35
        versionCode = 51
        versionName = "0.6.27-dev"
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}
