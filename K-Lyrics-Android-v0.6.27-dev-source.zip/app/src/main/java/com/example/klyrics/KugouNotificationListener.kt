package com.example.klyrics

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.Future
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class KugouNotificationListener : NotificationListenerService() {
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = Runnable { readActiveSession() }
    private val lookupExecutor = Executors.newSingleThreadExecutor()
    // Keep only the most recent track-change lookup queued. Rapid track skipping must not
    // build an unbounded backlog of obsolete network requests.
    private var pendingLookup: Future<*>? = null
    private val playbackClock = PlaybackClock()

    override fun onListenerConnected() {
        super.onListenerConnected()
        scheduleRefresh(0L)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) = scheduleRefresh(150L)
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = scheduleRefresh(150L)

    private fun scheduleRefresh(delayMs: Long) {
        handler.removeCallbacks(refreshTask)
        handler.postDelayed(refreshTask, delayMs)
    }

    private fun readActiveSession() {
        try {
            val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions: List<MediaSession.Token> = manager.getActiveSessions(
                ComponentName(this, KugouNotificationListener::class.java)
            )
            val controller = sessions.asSequence()
                .map { android.media.session.MediaController(this, it) }
                .firstOrNull { it.packageName.lowercase().contains("kugou") }

            if (controller == null) {
                clearCurrentTrack()
                return
            }

            val metadata = controller.metadata
            val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
            val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
            val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            val state = controller.playbackState
            val playing = state?.state == android.media.session.PlaybackState.STATE_PLAYING
            val mediaPosition = estimatedPosition(state)
            val positionAvailable = state != null && (state.position >= 0L && (state.position > 0L || state.lastPositionUpdateTime > 0L))
            val trackPrefs = getSharedPreferences("klyrics_track", Context.MODE_PRIVATE)
            val previousKey = trackPrefs.getString("active_track_key", "").orEmpty()
            val currentKey = if (title.isBlank()) "" else trackKey(title, artist)
            val reading = playbackClock.update(
                currentKey,
                playing,
                mediaPosition.takeIf { positionAvailable },
                SystemClock.elapsedRealtime()
            )
            val calibrationPosition = reading.positionMs
            val position = calibrationPosition ?: 0L
            trackPrefs.edit()
                .putString("title", title)
                .putString("artist", artist)
                .putString("active_track_key", currentKey)
                .putLong("duration", duration)
                .putLong("position", position)
                .putBoolean("playing", playing)
                .putBoolean("position_available", positionAvailable)
                .putLong("calibration_position", calibrationPosition ?: -1L)
                .putBoolean("calibration_available", calibrationPosition != null)
                .apply()
            publishTrack(title, artist, playing, position, positionAvailable)
            if (currentKey.isNotBlank() && currentKey != previousKey) maybeLookupLyrics(title, artist, duration)

            if (playing) scheduleRefresh(1_000L)
        } catch (_: SecurityException) {
            // The user may revoke notification-listener access while the service is active.
            clearCurrentTrack()
        } catch (_: Exception) {
            // Media sessions can disappear during a player transition; retry once shortly.
            scheduleRefresh(500L)
        }
    }

    private fun estimatedPosition(state: android.media.session.PlaybackState?): Long {
        if (state == null) return 0L
        return PlaybackPositionEstimator.estimate(
            positionMs = state.position,
            playing = state.state == android.media.session.PlaybackState.STATE_PLAYING,
            lastUpdateElapsedMs = state.lastPositionUpdateTime,
            nowElapsedMs = SystemClock.elapsedRealtime(),
            playbackSpeed = state.playbackSpeed
        )
    }

    private fun maybeLookupLyrics(title: String, artist: String, durationMs: Long) {
        if (!KLyricsSettings(this).autoLookupEnabled) return
        val store = LyricStore(this)
        if (store.hasLyrics(title, artist)) return
        pendingLookup?.cancel(true)
        pendingLookup = lookupExecutor.submit {
            runCatching { LyricProvider.search(title, artist, durationMs) }.getOrNull()?.let { result ->
                store.save(title, artist, result.rawLyrics)
                val prefs = getSharedPreferences("klyrics_track", Context.MODE_PRIVATE)
                val activeTitle = prefs.getString("title", "").orEmpty()
                val activeArtist = prefs.getString("artist", "").orEmpty()
                if (trackKey(activeTitle, activeArtist) == trackKey(title, artist)) {
                    sendBroadcast(Intent(LyricOverlayService.ACTION_UPDATE).setPackage(packageName).apply {
                        putExtra(LyricOverlayService.EXTRA_TITLE, title)
                        putExtra(LyricOverlayService.EXTRA_ARTIST, artist)
                        putExtra(LyricOverlayService.EXTRA_PLAYING, prefs.getBoolean("playing", false))
                        putExtra(LyricOverlayService.EXTRA_POSITION, prefs.getLong("position", 0L))
                        putExtra(LyricOverlayService.EXTRA_POSITION_AVAILABLE, prefs.getBoolean("position_available", false))
                    })
                }
            }
        }
    }

    private fun publishTrack(title: String, artist: String, playing: Boolean, position: Long, positionAvailable: Boolean) {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        sendBroadcast(Intent(LyricOverlayService.ACTION_UPDATE).setPackage(packageName).apply {
            putExtra(LyricOverlayService.EXTRA_TITLE, title)
            putExtra(LyricOverlayService.EXTRA_ARTIST, artist)
            putExtra(LyricOverlayService.EXTRA_PLAYING, playing)
            putExtra(LyricOverlayService.EXTRA_POSITION, position)
            putExtra(LyricOverlayService.EXTRA_POSITION_AVAILABLE, positionAvailable)
        })
    }

    private fun clearCurrentTrack() {
        val prefs = getSharedPreferences("klyrics_track", Context.MODE_PRIVATE)
        val hadTrack = prefs.getString("title", "").orEmpty().isNotBlank()
        prefs.edit().remove("title").remove("artist").remove("position").remove("active_track_key")
            .putBoolean("playing", false).putBoolean("position_available", false)
            .putLong("calibration_position", -1L).putBoolean("calibration_available", false).apply()
        playbackClock.reset()
        if (hadTrack) publishTrack("", "", false, 0L, false)
    }

    override fun onListenerDisconnected() {
        handler.removeCallbacksAndMessages(null)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        pendingLookup?.cancel(true)
        pendingLookup = null
        lookupExecutor.shutdownNow()
        super.onDestroy()
    }
}
