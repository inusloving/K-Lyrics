package com.example.klyrics

/** Extracts distinct Hangul tokens from a lyric line for tap-to-study shortcuts. */
object KoreanWordTokenizer {
    private val tokenPattern = Regex("[가-힣]+(?:[·][가-힣]+)*")

    fun tokenize(sentence: String, maxTokens: Int = 24): List<String> {
        if (maxTokens <= 0 || sentence.isBlank()) return emptyList()
        return tokenPattern.findAll(sentence)
            .map { it.value }
            .distinct()
            .take(maxTokens)
            .toList()
    }
}
