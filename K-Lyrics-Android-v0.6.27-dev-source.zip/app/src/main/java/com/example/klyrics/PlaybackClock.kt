package com.example.klyrics

/** Combines MediaSession timestamps with a monotonic fallback clock for manual calibration. */
class PlaybackClock {
    data class Reading(val positionMs: Long?, val fromMediaSession: Boolean)

    private var trackKey = ""
    private var accumulatedMs = 0L
    // -1 is the only "not running" sentinel: elapsedRealtime() is allowed to be 0.
    private var startedAtMs = NOT_RUNNING
    private var wasPlaying = false
    private var initialized = false

    fun update(key: String, playing: Boolean, mediaPositionMs: Long?, nowMs: Long): Reading {
        if (key.isBlank()) {
            reset()
            return Reading(null, false)
        }
        val monotonicNow = nowMs.coerceAtLeast(0L)
        if (mediaPositionMs != null && mediaPositionMs >= 0L) {
            trackKey = key
            accumulatedMs = mediaPositionMs
            startedAtMs = if (playing) monotonicNow else NOT_RUNNING
            wasPlaying = playing
            initialized = true
            return Reading(mediaPositionMs, true)
        }
        if (key != trackKey) {
            trackKey = key
            accumulatedMs = 0L
            startedAtMs = if (playing) monotonicNow else NOT_RUNNING
            wasPlaying = playing
            initialized = playing
            return Reading(if (initialized) 0L else null, false)
        }
        if (playing && !wasPlaying) {
            startedAtMs = monotonicNow
            initialized = true
        } else if (!playing && wasPlaying && startedAtMs != NOT_RUNNING) {
            accumulatedMs = safeAdd(accumulatedMs, (monotonicNow - startedAtMs).coerceAtLeast(0L))
            startedAtMs = NOT_RUNNING
        }
        wasPlaying = playing
        if (!initialized) return Reading(null, false)
        val elapsed = if (playing && startedAtMs != NOT_RUNNING) {
            (monotonicNow - startedAtMs).coerceAtLeast(0L)
        } else 0L
        return Reading(safeAdd(accumulatedMs, elapsed), false)
    }

    fun reset() {
        trackKey = ""
        accumulatedMs = 0L
        startedAtMs = NOT_RUNNING
        wasPlaying = false
        initialized = false
    }

    private fun safeAdd(left: Long, right: Long): Long =
        if (Long.MAX_VALUE - left < right) Long.MAX_VALUE else left + right

    private companion object {
        const val NOT_RUNNING = -1L
    }
}
