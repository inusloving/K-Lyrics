package com.example.klyrics

import java.util.Base64

/** Versioned portable backup format. Text fields are Base64 URL-safe encoded to preserve all languages. */
object LyricBackupCodec {
    private const val HEADER = "KLYRICS_BACKUP\t1"
    private const val MAX_LINES = 10_000
    private const val MAX_TEXT_LENGTH = 20_000

    data class Backup(val title: String, val artist: String, val lines: List<LyricLine>)

    fun encode(backup: Backup): String {
        require(backup.title.isNotBlank() && backup.title.length <= 500) { "歌曲标题无效" }
        require(backup.artist.length <= 500) { "歌手名称过长" }
        require(backup.lines.isNotEmpty() && backup.lines.size <= MAX_LINES) { "歌词行数无效" }
        val output = StringBuilder().append(HEADER).append('\n')
            .append("META\t").append(enc(backup.title)).append('\t').append(enc(backup.artist)).append('\n')
        backup.lines.forEach { line ->
            require(line.text.isNotBlank() && line.text.length <= MAX_TEXT_LENGTH) { "歌词文本无效" }
            require(line.translation.orEmpty().length <= MAX_TEXT_LENGTH) { "译文文本过长" }
            require(line.timeMs in -1L..86_400_000L) { "时间戳无效" }
            output.append("LINE\t").append(line.timeMs).append('\t')
                .append(enc(line.text)).append('\t').append(enc(line.translation.orEmpty())).append('\n')
        }
        return output.toString()
    }

    fun decode(content: String): Backup {
        require(content.length <= 5_000_000) { "备份文件过大" }
        val normalized = content.removePrefix("\uFEFF")
        val rows = normalized.lineSequence().filter { it.isNotBlank() }.toList()
        require(rows.size >= 3 && rows.first() == HEADER) { "备份版本或格式不受支持" }
        val meta = rows[1].split('\t')
        require(meta.size == 3 && meta[0] == "META") { "备份信息损坏" }
        val title = dec(meta[1])
        val artist = dec(meta[2])
        require(title.isNotBlank() && title.length <= 500 && artist.length <= 500) { "备份歌曲信息无效" }
        val lines = rows.drop(2).map { row ->
            val fields = row.split('\t')
            require(fields.size == 4 && fields[0] == "LINE") { "歌词数据行损坏" }
            val time = fields[1].toLongOrNull() ?: error("时间戳无效")
            require(time in -1L..86_400_000L) { "时间戳无效" }
            val text = dec(fields[2])
            val translation = dec(fields[3])
            require(text.isNotBlank() && text.length <= MAX_TEXT_LENGTH) { "歌词文本无效" }
            require(translation.length <= MAX_TEXT_LENGTH) { "译文文本过长" }
            LyricLine(time, text, translation.takeIf { it.isNotBlank() })
        }
        require(lines.isNotEmpty() && lines.size <= MAX_LINES) { "备份歌词行数无效" }
        return Backup(title, artist, lines)
    }

    private fun enc(value: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(Charsets.UTF_8))
    private fun dec(value: String): String = String(Base64.getUrlDecoder().decode(value), Charsets.UTF_8)
}
