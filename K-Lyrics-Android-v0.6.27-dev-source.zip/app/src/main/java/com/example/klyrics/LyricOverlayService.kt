package com.example.klyrics

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.method.ScrollingMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.View
import android.os.Build
import android.os.IBinder
import android.content.pm.ServiceInfo
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class LyricOverlayService : Service() {
    companion object {
        const val ACTION_UPDATE = "com.example.klyrics.UPDATE"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_PLAYING = "playing"
        const val EXTRA_POSITION = "position"
        const val EXTRA_POSITION_AVAILABLE = "position_available"
        private const val NOTIFICATION_CHANNEL = "klyrics_overlay"
        private const val NOTIFICATION_ID = 4102
    }

    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var lyricView: TextView? = null
    private var translationView: TextView? = null
    private val store by lazy { LyricStore(this) }
    private var lines: List<LyricLine> = emptyList()
    private var activeTrackKey: String = ""
    private var activeRevision: Long = -1L
    private var receiverRegistered = false

    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_UPDATE) renderTrack(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        startOverlayForeground()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlay()
        val filter = IntentFilter(ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(updateReceiver, filter)
        }
        receiverRegistered = true
        val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
        renderTrack(Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_TITLE, prefs.getString("title", "").orEmpty())
            putExtra(EXTRA_ARTIST, prefs.getString("artist", "").orEmpty())
            putExtra(EXTRA_PLAYING, prefs.getBoolean("playing", false))
            putExtra(EXTRA_POSITION, prefs.getLong("position", 0L))
            putExtra(EXTRA_POSITION_AVAILABLE, prefs.getBoolean("position_available", false))
        })
    }

    private fun startOverlayForeground() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(
                NOTIFICATION_CHANNEL,
                "K-Lyrics 悬浮歌词",
                NotificationManager.IMPORTANCE_LOW
            ))
        }
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notificationBuilder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, NOTIFICATION_CHANNEL)
        } else {
            Notification.Builder(this)
        }
        val notification = notificationBuilder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("K-Lyrics 正在显示歌词")
            .setContentText("悬浮歌词已开启，点击返回管理")
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createOverlay() {
        val settings = KLyricsSettings(this)
        val appearance = settings.appearance()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(Color.argb(
                appearance.backgroundAlpha.coerceIn(0, 100) * 255 / 100,
                Color.red(appearance.backgroundColor),
                Color.green(appearance.backgroundColor),
                Color.blue(appearance.backgroundColor)
            ))
        }
        titleView = TextView(this).apply { text = "等待酷狗播放歌曲"; textSize = 15f; setTextColor(0xFFFFFFFF.toInt()) }
        artistView = TextView(this).apply { textSize = 12f; setTextColor(0xFFB9A5FF.toInt()) }
        lyricView = TextView(this).apply {
            text = "先导入 LRC 或在线搜索歌词"
            textSize = appearance.fontSizeSp
            setPadding(0, 12, 0, 0)
            setTextColor(appearance.activeColor)
        }
        lyricView?.movementMethod = LinkMovementMethod.getInstance()
        lyricView?.maxLines = 7
        lyricView?.isVerticalScrollBarEnabled = true
        translationView = TextView(this).apply {
            textSize = (appearance.fontSizeSp - 2f).coerceAtLeast(12f)
            setPadding(0, 4, 0, 0)
            setTextColor(appearance.chineseColor)
            maxLines = 7
            isVerticalScrollBarEnabled = true
            movementMethod = ScrollingMovementMethod.getInstance()
        }
        root.addView(titleView); root.addView(artistView); root.addView(lyricView); root.addView(translationView)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val position = settings.overlayPosition()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = position.first
            y = position.second
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        titleView?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = (startY + (event.rawY - touchY).toInt()).coerceAtLeast(0)
                    runCatching { windowManager.updateViewLayout(root, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    settings.saveOverlayPosition(params.x, params.y)
                    true
                }
                else -> false
            }
        }
        windowManager.addView(root, params)
        panel = root
    }

    private fun renderTrack(intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val artist = intent.getStringExtra(EXTRA_ARTIST).orEmpty()
        val playing = intent.getBooleanExtra(EXTRA_PLAYING, false)
        val position = intent.getLongExtra(EXTRA_POSITION, 0L)
        val positionAvailable = intent.getBooleanExtra(EXTRA_POSITION_AVAILABLE, false)
        titleView?.text = if (title.isBlank()) "等待酷狗播放歌曲" else title
        artistView?.text = if (title.isBlank()) "" else artist + if (playing) " · 正在播放" else " · 已暂停"

        val newKey = if (title.isBlank()) "" else trackKey(title, artist)
        val revision = if (newKey.isBlank()) 0L else store.revision(title, artist)
        if (newKey != activeTrackKey || revision != activeRevision) {
            activeTrackKey = newKey
            activeRevision = revision
            lines = if (newKey.isBlank()) emptyList() else store.load(title, artist)
        }
        val currentIndex = currentLyricIndex(lines, position)
        val current = lines.getOrNull(currentIndex)
        val appearance = KLyricsSettings(this).appearance()
        when {
            title.isBlank() -> {
                lyricView?.setOnClickListener(null)
                lyricView?.text = "等待酷狗播放歌曲"
                translationView?.text = ""
            }
            lines.isEmpty() -> {
                lyricView?.setOnClickListener(null)
                lyricView?.text = "未找到歌词：可在线搜索或导入 LRC/TXT"
                translationView?.text = ""
            }
            !positionAvailable -> renderStaticLyrics(title, artist, appearance)
            current == null && lines.any { it.timeMs < 0L } -> renderStaticLyrics(title, artist, appearance)
            current != null -> {
                val styled = SpannableString(current.text)
                Regex("[가-힣]+").findAll(current.text).forEach { match ->
                    styled.setSpan(object : ClickableSpan() {
                        override fun onClick(widget: View) {
                            openLearning(title, artist, current.text, match.value, currentIndex)
                        }
                    }, match.range.first, match.range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                lyricView?.setTextColor(appearance.activeColor)
                lyricView?.text = styled
                lyricView?.setOnClickListener { openLearning(title, artist, current.text, "", currentIndex) }
                val nextUntimed = lines.drop(currentIndex + 1).firstOrNull { it.timeMs < 0L }
                translationView?.text = current.translation?.takeIf { it.isNotBlank() }
                    ?: nextUntimed?.let { "下一句待校准：${it.text}" }.orEmpty()
            }
            lines.any { it.timeMs < 0L } -> {
                lyricView?.setOnClickListener(null)
                lyricView?.setTextColor(appearance.koreanColor)
                lyricView?.text = "歌词尚未校准：播放到每句开始时点击校准按钮"
                translationView?.text = ""
            }
            else -> {
                lyricView?.setOnClickListener(null)
                lyricView?.setTextColor(appearance.koreanColor)
                lyricView?.text = "等待歌词开始…"
                translationView?.text = ""
            }
        }
    }

    private fun renderStaticLyrics(title: String, artist: String, appearance: LyricAppearance) {
        val bilingual = SpannableStringBuilder()
        lines.forEachIndexed { index, line ->
            val start = bilingual.length
            bilingual.append(line.text)
            val end = bilingual.length
            bilingual.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) {
                    openLearning(title, artist, line.text, "", index)
                }
            }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            Regex("[가-힣]+").findAll(line.text).forEach { match ->
                bilingual.setSpan(object : ClickableSpan() {
                    override fun onClick(widget: View) {
                        openLearning(title, artist, line.text, match.value, index)
                    }
                }, start + match.range.first, start + match.range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            bilingual.append('\n')
            line.translation?.takeIf { it.isNotBlank() }?.let { translation ->
                val translationStart = bilingual.length
                bilingual.append(translation)
                bilingual.setSpan(ForegroundColorSpan(appearance.chineseColor), translationStart, bilingual.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                bilingual.append('\n')
            }
        }
        lyricView?.setOnClickListener(null)
        lyricView?.setTextColor(appearance.koreanColor)
        lyricView?.text = bilingual
        translationView?.text = ""
    }

    private fun openLearning(title: String, artist: String, sentence: String, word: String, lineIndex: Int) {
        startActivity(Intent(this, LearningActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(LearningActivity.EXTRA_TITLE, title)
            putExtra(LearningActivity.EXTRA_ARTIST, artist)
            putExtra(LearningActivity.EXTRA_SENTENCE, sentence)
            putExtra(LearningActivity.EXTRA_WORD, word)
            putExtra(LearningActivity.EXTRA_LINE_INDEX, lineIndex)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE) renderTrack(intent)
        return START_STICKY
    }

    override fun onDestroy() {
        if (receiverRegistered) runCatching { unregisterReceiver(updateReceiver) }
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
