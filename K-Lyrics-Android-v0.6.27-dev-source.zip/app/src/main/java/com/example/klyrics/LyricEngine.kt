package com.example.klyrics

import java.util.Locale

/** A timestamped lyric line. timeMs is the start time relative to the track. */
data class LyricLine(
    val timeMs: Long,
    val text: String,
    val translation: String? = null
)

/** Parses standard LRC timestamps, including multiple timestamps on one line. */
object LrcParser {
    private val timestamp = Regex("\\[(\\d+):(\\d{2})(?:[.:]([0-9]{1,3}))?]")
    private val offsetTag = Regex("\\[offset:([+-]?\\d+)]", RegexOption.IGNORE_CASE)

    fun parse(content: String): List<LyricLine> {
        val offsetMs = content.lineSequence().mapNotNull { line ->
            offsetTag.find(line)?.groupValues?.getOrNull(1)?.toLongOrNull()
        }.firstOrNull()?.coerceIn(-86_400_000L, 86_400_000L) ?: 0L
        val result = mutableListOf<LyricLine>()
        content.lineSequence().forEach { rawLine ->
            val matches = timestamp.findAll(rawLine).toList()
            if (matches.isEmpty()) return@forEach
            val lyricText = rawLine.substring(matches.last().range.last + 1).trim()
            if (lyricText.isEmpty()) return@forEach
            matches.forEach matchLoop@{ match ->
                val minutes = match.groupValues[1].toLongOrNull() ?: return@matchLoop
                val seconds = match.groupValues[2].toLongOrNull() ?: return@matchLoop
                if (minutes > 1_440L) return@matchLoop
                val fractionRaw = match.groupValues[3]
                val fractionMs = when (fractionRaw.length) {
                    1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                    2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                    3 -> fractionRaw.toLongOrNull() ?: 0L
                    else -> 0L
                }
                if (seconds >= 60) return@matchLoop
                val timestampMs = (minutes * 60 + seconds) * 1000 + fractionMs
                result += LyricLine((timestampMs + offsetMs).coerceAtLeast(0L), lyricText)
            }
        }
        return result.sortedBy { it.timeMs }
    }
}

/** Returns the latest lyric line whose timestamp is not later than playbackPositionMs. */
fun currentLyricIndex(lines: List<LyricLine>, playbackPositionMs: Long): Int {
    var selected = -1
    var selectedTime = Long.MIN_VALUE
    lines.forEachIndexed { index, line ->
        if (line.timeMs >= 0L && line.timeMs <= playbackPositionMs && line.timeMs >= selectedTime) {
            selected = index
            selectedTime = line.timeMs
        }
    }
    return selected
}

/** Stable key used to keep lyrics/calibration separated by track. */
fun trackKey(title: String, artist: String): String =
    (title.trim().lowercase(Locale.ROOT) + "|" + artist.trim().lowercase(Locale.ROOT))
        .replace(Regex("\\s+"), " ")

/** Manual calibration: replace the selected line's timestamp and keep chronological order. */
fun calibrateLine(lines: List<LyricLine>, lineIndex: Int, playbackPositionMs: Long): List<LyricLine> {
    if (lineIndex !in lines.indices || playbackPositionMs < 0L) return lines
    return lines.mapIndexed { index, line ->
        if (index == lineIndex) line.copy(timeMs = playbackPositionMs) else line
    }
}
