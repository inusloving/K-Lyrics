package com.example.klyrics

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import java.util.Locale

class LearningActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var aiResult: TextView
    private lateinit var sentenceTranslation: TextView
    private var sentence = ""
    private var selectedWord = ""
    private var title = ""
    private var artist = ""
    private var lineIndex = -1
    private val aiButtons = mutableListOf<Button>()
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var pronunciationButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sentence = intent.getStringExtra(EXTRA_SENTENCE).orEmpty()
        selectedWord = intent.getStringExtra(EXTRA_WORD).orEmpty()
        title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        artist = intent.getStringExtra(EXTRA_ARTIST).orEmpty()
        lineIndex = intent.getIntExtra(EXTRA_LINE_INDEX, -1)
        val mode = KLyricsSettings(this).learningMode
        val cache = AiStudyCache(this)
        val cachedAnalysis = cache.get("analyze", sentence)
        val cachedTranslation = cache.get("translate", sentence)
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = textToSpeech?.setLanguage(Locale.KOREAN) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                runOnUiThread {
                    if (::pronunciationButton.isInitialized) {
                        pronunciationButton.isEnabled = ttsReady
                        if (!ttsReady) pronunciationButton.text = "设备未提供韩语语音"
                    }
                }
            }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(28, 32, 28, 32)
        }
        root.addView(TextView(this).apply {
            text = if (selectedWord.isBlank()) "句子学习" else "单词学习"
            textSize = 23f
        })
        if (title.isNotBlank() || artist.isNotBlank()) {
            root.addView(body(listOf(title, artist).filter { it.isNotBlank() }.joinToString(" · "), 13f))
        }
        if (lineIndex >= 0) root.addView(body("歌词行：${lineIndex + 1}", 12f))
        root.addView(TextView(this).apply {
            textSize = 19f
            setPadding(0, 8, 0, 8)
            text = sentenceWithSelectedWord(sentence, selectedWord)
            contentDescription = if (selectedWord.isBlank()) sentence else "原句：$sentence；当前学习词：$selectedWord"
        })
        sentenceTranslation = body(
            cachedTranslation?.let { "本句中文翻译：\n$it" } ?: "本句中文翻译：尚未生成（可使用下方 AI 翻译）",
            14f
        )
        root.addView(sentenceTranslation)
        val sentenceTokens = KoreanWordTokenizer.tokenize(sentence)
        if (selectedWord.isBlank()) {
            if (sentenceTokens.isNotEmpty()) {
                root.addView(body("点击歌词中的词语进行单词学习", 14f))
                sentenceTokens.forEach { token ->
                    root.addView(Button(this).apply {
                        text = "查词：$token"
                        isAllCaps = false
                        setOnClickListener { openWordStudy(token) }
                    })
                }
            }
        } else if (sentenceTokens.size > 1) {
            root.addView(body("当前学习：$selectedWord", 14f))
            root.addView(body("同句切换（保留原歌词上下文）", 14f))
            sentenceTokens.filter { it != selectedWord }.forEach { token ->
                root.addView(Button(this).apply {
                    text = "切换到：$token"
                    isAllCaps = false
                    setOnClickListener { openWordStudy(token) }
                })
            }
        }
        pronunciationButton = Button(this).apply {
            text = if (selectedWord.isBlank()) "朗读整句韩语" else "播放单词发音"
            isEnabled = false
            setOnClickListener {
                val spoken = selectedWord.ifBlank { sentence }
                textToSpeech?.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "klyrics-pronunciation")
            }
        }
        root.addView(pronunciationButton)

        if (selectedWord.isNotBlank()) {
            val info = KoreanStudyEngine.analyzeWord(selectedWord)
            if (info == null) {
                root.addView(body("暂未收录“$selectedWord”。离线词库是精选词条，不会对未知词强行猜测词义。"))
            } else if (mode == LearningMode.SIMPLE) {
                root.addView(body("${info.meaning}"))
            } else {
                root.addView(body("原形：${info.lemma}"))
                root.addView(body("词性：${info.partOfSpeech}"))
                if (info.pluralMarker) root.addView(body("复数标记：들（表示复数；韩语中可省略，具体含义依语境判断）"))
                if (info.attachedParticles.isNotEmpty()) {
                    root.addView(body("附着助词：${info.attachedParticles.joinToString(" + ")}"))
                }
                info.adnominalEnding?.let { root.addView(body("冠形词形词尾：$it（用于修饰后面的名词）")) }
                info.nominalizingEnding?.let { ending ->
                    if (ending.contains("词汇化名词")) {
                        root.addView(body("构词后缀：$ending（已形成独立词汇化名词；优先记忆该名词的实际词义）"))
                    } else {
                        root.addView(body("名词化词尾：$ending（将动词或形容词形式转为名词性表达）"))
                    }
                }
                if (info.connectiveEnding != null) {
                    root.addView(body("连接词尾：${info.connectiveEnding}"))
                    info.connectiveMeaning?.let { root.addView(body("语法作用：$it")) }
                }
                root.addView(body("词义：${info.meaning}"))
                root.addView(body("用法：${info.explanation}"))
                root.addView(body("例句：${info.example}"))
            }
        } else {
            val hints = KoreanStudyEngine.analyzeSentence(sentence)
            if (hints.isEmpty()) {
                root.addView(body("当前离线规则库未识别到明确语法形式。复杂句式需要结合上下文分析，不能仅凭词尾下结论。"))
            } else {
                hints.forEach { hint ->
                    root.addView(body("${hint.pattern}：${hint.meaning}"))
                    if (mode == LearningMode.DETAILED) root.addView(body(hint.note))
                }
            }
            if (mode == LearningMode.DETAILED) {
                root.addView(body("说明：这是基于固定语法形式的提示，不等同于完整形态素分析或句法树。"))
            }
        }

        val aiSettings = KLyricsSettings(this)
        val endpoint = aiSettings.aiEndpoint
        if (endpoint.isNotBlank() && aiSettings.aiAccessToken.isNotBlank()) {
            aiButtons += Button(this).apply {
                text = "AI 详细语法讲解"
                setOnClickListener { requestAi("analyze") }
            }
            aiButtons += Button(this).apply {
                text = "AI 翻译这句并同步到悬浮窗"
                setOnClickListener { requestAi("translate") }
            }
            aiButtons.forEach { root.addView(it) }
        } else {
            root.addView(body("在线 AI 尚未配置服务地址；离线词典和规则提示仍可使用。"))
        }
        aiResult = body("")
        root.addView(aiResult)
        setContentView(ScrollView(this).apply { addView(root) })
        if (cachedAnalysis != null || (cachedTranslation != null && selectedWord.isBlank())) {
            aiResult.text = buildString {
                append("本机缓存（可离线查看）")
                if (cachedAnalysis != null) append("\n\n【AI 语法分析】\n").append(cachedAnalysis)
                if (cachedTranslation != null && selectedWord.isBlank()) {
                    append("\n\n【AI 中文翻译】\n").append(cachedTranslation)
                }
            }
        }
    }


    private fun openWordStudy(word: String) {
        if (word.isBlank() || word == selectedWord) return
        startActivity(android.content.Intent(this, LearningActivity::class.java).apply {
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_ARTIST, artist)
            putExtra(EXTRA_SENTENCE, sentence)
            putExtra(EXTRA_WORD, word)
            putExtra(EXTRA_LINE_INDEX, lineIndex)
        })
        // Keep the sentence page as the single return point. Replacing the current
        // word page prevents repeated same-sentence switches from growing the stack.
        if (selectedWord.isNotBlank()) finish()
    }

    private fun requestAi(task: String) {
        val aiSettings = KLyricsSettings(this)
        val endpoint = aiSettings.aiEndpoint
        val accessToken = aiSettings.aiAccessToken
        if (endpoint.isBlank() || accessToken.isBlank()) return
        if (sentence.isBlank()) {
            aiResult.text = "当前没有可分析的韩语文本。"
            return
        }
        aiButtons.forEach { it.isEnabled = false }
        val cached = AiStudyCache(this).get(task, sentence)
        val waitingText = if (cached != null) "正在读取本机缓存…" else "正在请求 AI 服务…"
        if (task == "translate") sentenceTranslation.text = "本句中文翻译：$waitingText"
        else aiResult.text = waitingText
        executor.execute {
            var failure: String? = null
            val result = try {
                cached ?: AiStudyClient.request(endpoint, accessToken, task, sentence).also {
                    AiStudyCache(this).put(task, sentence, it)
                }
            } catch (error: Exception) {
                failure = error.message ?: "网络或服务异常"
                null
            }
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    if (result == null) {
                        val errorText = "AI 请求失败：$failure"
                        if (task == "translate") sentenceTranslation.text = errorText
                        else aiResult.text = errorText
                    } else {
                        val source = if (cached != null) "本机缓存（离线可用）" else "在线 AI"
                        if (task == "translate") {
                            sentenceTranslation.text = "本句中文翻译（$source）：\n$result"
                        } else {
                            aiResult.text = "$source · 语法分析\n\n$result"
                        }
                        if (task == "translate" && title.isNotBlank() && lineIndex >= 0) {
                            LyricStore(this).saveTranslationAt(title, artist, lineIndex, result.trim())
                            sendBroadcast(android.content.Intent(LyricOverlayService.ACTION_UPDATE).setPackage(packageName).apply {
                                putExtra(LyricOverlayService.EXTRA_TITLE, title)
                                putExtra(LyricOverlayService.EXTRA_ARTIST, artist)
                                val trackPrefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
                                putExtra(LyricOverlayService.EXTRA_PLAYING, trackPrefs.getBoolean("playing", false))
                                putExtra(LyricOverlayService.EXTRA_POSITION, trackPrefs.getLong("position", 0L))
                                putExtra(LyricOverlayService.EXTRA_POSITION_AVAILABLE, trackPrefs.getBoolean("position_available", false))
                            })
                            Toast.makeText(this, "译文已保存到当前歌曲", Toast.LENGTH_SHORT).show()
                        }
                    }
                    aiButtons.forEach { it.isEnabled = true }
                }
            }
        }
    }

    /** Highlights every exact occurrence of the selected tokenizer token in its source sentence. */
    private fun sentenceWithSelectedWord(source: String, word: String): CharSequence {
        if (source.isEmpty() || word.isBlank()) return source
        val styled = SpannableString(source)
        val ranges = SelectedWordHighlighter.ranges(source, word)
        ranges.forEach { range ->
            val start = range.first
            val endExclusive = range.last + 1
            styled.setSpan(
                BackgroundColorSpan(Color.rgb(255, 235, 160)),
                start, endExclusive, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            styled.setSpan(
                ForegroundColorSpan(Color.rgb(70, 45, 0)),
                start, endExclusive, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            styled.setSpan(
                StyleSpan(Typeface.BOLD),
                start, endExclusive, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return if (ranges.isNotEmpty()) styled else source
    }

    private fun body(value: String, size: Float = 16f) = TextView(this).apply {
        text = value
        textSize = size
        setPadding(0, 8, 0, 8)
    }

    override fun onDestroy() {
        executor.shutdownNow()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TITLE = "track_title"
        const val EXTRA_ARTIST = "track_artist"
        const val EXTRA_SENTENCE = "sentence"
        const val EXTRA_WORD = "word"
        const val EXTRA_LINE_INDEX = "line_index"
    }
}
