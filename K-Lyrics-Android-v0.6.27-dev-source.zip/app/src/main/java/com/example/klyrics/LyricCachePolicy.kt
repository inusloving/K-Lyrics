package com.example.klyrics

/** Deterministic LRU eviction policy for the on-device lyric cache. */
internal object LyricCachePolicy {
    data class Entry(val trackId: String, val lastUsedAt: Long, val storedChars: Int)

    /** Throttle access-time writes so frequent overlay refreshes do not hit disk every second. */
    fun shouldRefreshAccessTime(previousAt: Long, now: Long, intervalMs: Long): Boolean {
        require(intervalMs >= 0L) { "intervalMs must not be negative" }
        if (previousAt <= 0L || now <= previousAt) return previousAt <= 0L
        return now - previousAt >= intervalMs
    }

    fun evictionIds(
        entries: List<Entry>,
        maxTracks: Int,
        maxStoredChars: Long,
        protectedTrackId: String? = null
    ): Set<String> {
        require(maxTracks >= 1) { "maxTracks must be positive" }
        require(maxStoredChars >= 1L) { "maxStoredChars must be positive" }
        if (entries.isEmpty()) return emptySet()

        val unique = entries.distinctBy { it.trackId }
        val totalChars = unique.sumOf { it.storedChars.coerceAtLeast(0).toLong() }
        var remainingTracks = unique.size
        var remainingChars = totalChars
        val evicted = linkedSetOf<String>()

        // Oldest entries go first. Keep the just-written track whenever possible.
        for (entry in unique.sortedWith(compareBy<Entry> { it.lastUsedAt }.thenBy { it.trackId })) {
            if (remainingTracks <= maxTracks && remainingChars <= maxStoredChars) break
            if (entry.trackId == protectedTrackId) continue
            evicted += entry.trackId
            remainingTracks--
            remainingChars -= entry.storedChars.coerceAtLeast(0).toLong()
        }
        return evicted
    }
}
