package com.example.klyrics

import android.content.Context
import org.json.JSONArray

/** Local-first lyric cache with optional per-line translations and manual timestamps. */
class LyricStore(context: Context) {
    private val prefs = context.getSharedPreferences("klyrics_lyrics", Context.MODE_PRIVATE)

    fun save(title: String, artist: String, rawLyrics: String) {
        require(title.isNotBlank() && title.length <= MAX_METADATA_CHARS) { "歌曲标题为空或过长" }
        require(artist.length <= MAX_METADATA_CHARS) { "歌手名称过长" }
        require(rawLyrics.isNotBlank() && rawLyrics.length <= MAX_LYRICS_CHARS) { "歌词为空或超过本地缓存限制" }
        prefs.edit()
            .putString(lyricsKey(title, artist), rawLyrics)
            .remove(trackKey(title, artist))
            .remove(calibrationKey(title, artist))
            .remove(translationKey(title, artist))
            .putLong(updatedKey(title, artist), System.currentTimeMillis())
            .putLong(accessedKey(title, artist), System.currentTimeMillis())
            .apply()
        trimCache(trackKey(title, artist))
    }

    fun saveLines(title: String, artist: String, lines: List<LyricLine>) {
        require(title.isNotBlank() && title.length <= MAX_METADATA_CHARS) { "歌曲标题为空或过长" }
        require(artist.length <= MAX_METADATA_CHARS) { "歌手名称过长" }
        require(lines.isNotEmpty() && lines.size <= MAX_LINES) { "歌词行数为空或超过缓存限制" }
        require(lines.all { it.text.isNotBlank() && it.text.length <= MAX_LINE_CHARS && it.timeMs >= -1L }) {
            "歌词行内容或时间戳无效"
        }
        val json = JSONArray()
        lines.forEach { line ->
            json.put(org.json.JSONObject().put("timeMs", line.timeMs).put("text", line.text))
        }
        prefs.edit()
            .putString(lyricsKey(title, artist), "#KLYRICS_STRUCTURED_V1\n${json}")
            .remove(trackKey(title, artist))
            .remove(calibrationKey(title, artist))
            .remove(translationKey(title, artist))
            .putLong(updatedKey(title, artist), System.currentTimeMillis())
            .putLong(accessedKey(title, artist), System.currentTimeMillis())
            .apply()
        trimCache(trackKey(title, artist))
    }

    fun saveTranslations(title: String, artist: String, translations: List<String>) {
        require(translations.size <= MAX_LINES && translations.all { it.length <= MAX_TRANSLATION_CHARS }) {
            "译文行数或单行长度超过缓存限制"
        }
        val json = JSONArray()
        translations.forEach(json::put)
        prefs.edit()
            .putString(translationKey(title, artist), json.toString())
            .putLong(updatedKey(title, artist), System.currentTimeMillis())
            .putLong(accessedKey(title, artist), System.currentTimeMillis())
            .apply()
        trimCache(trackKey(title, artist))
    }

    fun load(title: String, artist: String): List<LyricLine> {
        val raw = readRawLyrics(title, artist) ?: return emptyList()
        if (raw.length > MAX_LYRICS_CHARS) return emptyList()
        val structuredPrefix = "#KLYRICS_STRUCTURED_V1\n"
        val isStructured = raw.startsWith(structuredPrefix)
        val structured = if (isStructured) {
            runCatching { JSONArray(raw.removePrefix(structuredPrefix)) }.getOrNull()?.let(::decodeStructuredLines)
        } else null
        if (isStructured && structured == null) return emptyList()
        val parsed = if (isStructured) emptyList() else LrcParser.parse(raw)
        val base = structured ?: if (parsed.isNotEmpty()) parsed else raw.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { LyricLine(-1L, it) }
            .toList()
        if (base.isEmpty() || base.size > MAX_LINES || base.any { it.text.length > MAX_LINE_CHARS || it.timeMs < -1L }) {
            return emptyList()
        }

        val times = prefs.getString(calibrationKey(title, artist), null)?.let { encoded ->
            runCatching { JSONArray(encoded) }.getOrNull()
        }
        val withTimes = if (times == null || times.length() > MAX_LINES) base else base.mapIndexed { index, line ->
            val savedTime = times.optLong(index, line.timeMs).takeIf { it >= -1L } ?: line.timeMs
            line.copy(timeMs = savedTime)
        }
        val translations = prefs.getString(translationKey(title, artist), null)?.takeIf { it.length <= MAX_TRANSLATIONS_CHARS }?.let { encoded ->
            runCatching { JSONArray(encoded) }.getOrNull()?.takeIf { it.length() <= MAX_LINES }
        }
        val result = if (translations == null) withTimes else withTimes.mapIndexed { index, line ->
            val translation = translations.optString(index).takeIf {
                it.isNotBlank() && it != "null" && it.length <= MAX_TRANSLATION_CHARS
            }
            line.copy(translation = translation)
        }
        // LRU must reflect reads, not just writes. Overlay refreshes call load() often,
        // so throttle timestamp updates to avoid a SharedPreferences write every second.
        touchCacheEntry(title, artist)
        return result
    }

    /** Stamp the next untimed line using the current player position. */
    fun calibrateNext(title: String, artist: String, playbackPositionMs: Long): Int? {
        if (playbackPositionMs < 0L) return null
        val lines = load(title, artist)
        val index = lines.indexOfFirst { it.timeMs < 0L }
        if (index < 0) return null
        val encoded = prefs.getString(calibrationKey(title, artist), null)
        val times = if (encoded == null) JSONArray() else runCatching { JSONArray(encoded) }.getOrElse { JSONArray() }
        while (times.length() < lines.size) times.put(lines.getOrNull(times.length())?.timeMs ?: -1L)
        times.put(index, playbackPositionMs)
        prefs.edit()
            .putString(calibrationKey(title, artist), times.toString())
            .putLong(updatedKey(title, artist), System.currentTimeMillis())
            .putLong(accessedKey(title, artist), System.currentTimeMillis())
            .apply()
        trimCache(trackKey(title, artist))
        return index
    }

    fun saveTranslationAt(title: String, artist: String, lineIndex: Int, translation: String) {
        val count = load(title, artist).size
        if (lineIndex !in 0 until count || translation.length > MAX_TRANSLATION_CHARS) return
        val encoded = prefs.getString(translationKey(title, artist), null)
        val translations = if (encoded == null) JSONArray() else runCatching { JSONArray(encoded) }.getOrElse { JSONArray() }
        while (translations.length() < count) translations.put("")
        translations.put(lineIndex, translation)
        prefs.edit()
            .putString(translationKey(title, artist), translations.toString())
            .putLong(updatedKey(title, artist), System.currentTimeMillis())
            .putLong(accessedKey(title, artist), System.currentTimeMillis())
            .apply()
        trimCache(trackKey(title, artist))
    }

    fun hasLyrics(title: String, artist: String): Boolean {
        val exists = !readRawLyrics(title, artist).isNullOrBlank()
        if (exists) touchCacheEntry(title, artist)
        return exists
    }


    private fun decodeStructuredLines(array: JSONArray): List<LyricLine>? {
        if (array.length() !in 1..MAX_LINES) return null
        val decoded = ArrayList<LyricLine>(array.length())
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: return null
            val text = item.optString("text")
            val timeMs = item.optLong("timeMs", -1L)
            if (text.isBlank() || text.length > MAX_LINE_CHARS || timeMs < -1L) return null
            decoded += LyricLine(timeMs, text)
        }
        return decoded
    }

    private fun readRawLyrics(title: String, artist: String): String? {
        val key = lyricsKey(title, artist)
        prefs.getString(key, null)?.let { return it }
        // Migrate the pre-0.4 cache key without discarding existing user-imported lyrics.
        val legacyKey = trackKey(title, artist)
        val legacy = prefs.getString(legacyKey, null) ?: return null
        prefs.edit().putString(key, legacy).remove(legacyKey).apply()
        return legacy
    }

    fun untimedCount(title: String, artist: String): Int = load(title, artist).count { it.timeMs < 0L }
    fun revision(title: String, artist: String): Long = prefs.getLong(updatedKey(title, artist), 0L)

    private fun touchCacheEntry(title: String, artist: String) {
        val key = accessedKey(title, artist)
        val now = System.currentTimeMillis()
        val previous = prefs.getLong(key, 0L)
        if (LyricCachePolicy.shouldRefreshAccessTime(previous, now, ACCESS_TOUCH_INTERVAL_MS)) {
            prefs.edit().putLong(key, now).apply()
        }
    }

    /** Bound SharedPreferences growth while retaining recently used songs. */
    private fun trimCache(protectedTrackId: String) {
        val all = prefs.all
        val entries = all.keys.asSequence()
            .filter { it.startsWith("lrc:") }
            .mapNotNull { key ->
                val id = key.removePrefix("lrc:")
                val lyrics = all[key] as? String ?: return@mapNotNull null
                val translation = all["translation:$id"] as? String
                val calibration = all["calibration:$id"] as? String
                val size = lyrics.length.toLong() + (translation?.length ?: 0) + (calibration?.length ?: 0)
                val lastUsed = (all["accessed:$id"] as? Long)
                    ?: (all["updated:$id"] as? Long)
                    ?: 0L
                LyricCachePolicy.Entry(id, lastUsed, size.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            }.toList()
        val evictions = LyricCachePolicy.evictionIds(entries, MAX_CACHED_TRACKS, MAX_CACHE_CHARS, protectedTrackId)
        if (evictions.isEmpty()) return
        val editor = prefs.edit()
        evictions.forEach { id ->
            editor.remove("lrc:$id")
                .remove("translation:$id")
                .remove("calibration:$id")
                .remove("updated:$id")
                .remove("accessed:$id")
        }
        editor.apply()
    }

    private fun lyricsKey(title: String, artist: String) = "lrc:${trackKey(title, artist)}"
    private fun translationKey(title: String, artist: String) = "translation:${trackKey(title, artist)}"
    private fun calibrationKey(title: String, artist: String) = "calibration:${trackKey(title, artist)}"
    private fun updatedKey(title: String, artist: String) = "updated:${trackKey(title, artist)}"
    private fun accessedKey(title: String, artist: String) = "accessed:${trackKey(title, artist)}"

    private companion object {
        const val MAX_METADATA_CHARS = 256
        const val MAX_LYRICS_CHARS = 1_000_000
        const val MAX_LINES = 10_000
        const val MAX_LINE_CHARS = 2_000
        const val MAX_TRANSLATION_CHARS = 4_000
        const val MAX_TRANSLATIONS_CHARS = 5_000_000
        const val MAX_CACHED_TRACKS = 80
        const val MAX_CACHE_CHARS = 8_000_000L
        const val ACCESS_TOUCH_INTERVAL_MS = 5 * 60 * 1_000L
    }
}
