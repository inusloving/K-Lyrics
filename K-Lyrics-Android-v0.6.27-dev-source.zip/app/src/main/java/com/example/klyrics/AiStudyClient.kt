package com.example.klyrics

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.io.IOException

/** Calls the user's HTTPS study backend. Provider credentials never enter the Android app. */
object AiStudyClient {
    fun request(endpoint: String, accessToken: String, task: String, text: String): String {
        require(endpoint.startsWith("https://", ignoreCase = true)) { "AI 服务地址必须使用 HTTPS" }
        require(accessToken.isNotBlank()) { "缺少 AI 服务访问码" }
        require(task == "translate" || task == "translate_batch" || task == "analyze") { "不支持的学习任务" }
        require(text.isNotBlank() && text.length <= 2_000) { "文本为空或过长" }
        val url = URI(endpoint.trimEnd('/') + "/v1/study").toURL()
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $accessToken")
        }
        try {
            val payload = JSONObject()
                .put("task", task)
                .put("text", text)
                .put("targetLanguage", "简体中文")
                .toString()
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val declaredLength = connection.getHeaderFieldLong("Content-Length", -1L)
            if (declaredLength > MAX_RESPONSE_BYTES) throw IOException("AI response is too large")
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use {
                BoundedTextReader.read(it, MAX_RESPONSE_CHARS)
            }.orEmpty()
            val json = runCatching { JSONObject(response) }.getOrNull()
            if (code !in 200..299) throw IllegalStateException(
                when (json?.optString("error")) {
                    "study_service_not_configured" -> "AI 服务端尚未配置"
                    "unauthorized" -> "AI 服务访问码不正确"
                    "rate_limited" -> "请求过于频繁，请稍后再试"
                    "upstream_failed", "upstream_unavailable", "incomplete_model_response", "empty_model_response" -> "AI 模型服务暂不可用，请稍后再试"
                    else -> "AI 服务请求失败（HTTP $code）"
                }
            )
            return json?.optString("result")?.takeIf { it.isNotBlank() && it.length <= MAX_RESULT_CHARS }
                ?: throw IllegalStateException("AI 服务返回内容为空或超出长度限制")
        } finally {
            connection.disconnect()
        }
    }

    private const val MAX_RESPONSE_CHARS = 64 * 1024
    private const val MAX_RESPONSE_BYTES = 256L * 1024L
    private const val MAX_RESULT_CHARS = 48 * 1024
}
