package com.example.klyrics

import java.util.Locale
import kotlin.math.abs

/** Pure matching policy shared by the network provider and unit tests. */
object LyricMatchSelector {
    data class Candidate(
        val title: String,
        val artist: String,
        val durationSeconds: Double,
        val syncedLyrics: String?,
        val plainLyrics: String?
    )

    data class Match(val lyrics: String, val hasTimestamps: Boolean, val score: Double)

    /** Returns null for weak metadata matches or unusable lyric payloads. */
    fun select(
        requestedTitle: String,
        requestedArtist: String,
        requestedDurationMs: Long?,
        candidates: List<Candidate>
    ): Match? {
        // Bound both sides before normalization/edit-distance work. Media metadata is
        // external input and may be malformed or unexpectedly large.
        if (requestedTitle.length > MAX_METADATA_CHARS || requestedArtist.length > MAX_METADATA_CHARS) return null
        if (requestedDurationMs != null && requestedDurationMs !in 1L..MAX_DURATION_MS) return null
        val wantedTitle = normalize(requestedTitle)
        val wantedArtist = normalize(requestedArtist)
        if (wantedTitle.isBlank()) return null

        return candidates.asSequence().take(MAX_CANDIDATES).mapNotNull { candidate ->
            if (candidate.title.length > MAX_METADATA_CHARS || candidate.artist.length > MAX_METADATA_CHARS ||
                !candidate.durationSeconds.isFinite() || candidate.durationSeconds < 0.0 ||
                candidate.durationSeconds > MAX_DURATION_MS / 1_000.0) {
                return@mapNotNull null
            }
            val titleScore = similarity(wantedTitle, normalize(candidate.title))
            val artistScore = if (wantedArtist.isBlank()) 0.5 else similarity(wantedArtist, normalize(candidate.artist))
            val requestedSeconds = requestedDurationMs?.takeIf { it > 0L }?.div(1_000.0)
            val durationMismatch = requestedSeconds != null && candidate.durationSeconds > 0.0 &&
                abs(requestedSeconds - candidate.durationSeconds) > MAX_DURATION_DELTA_SECONDS
            if (titleScore < MIN_TITLE_SCORE || (wantedArtist.isNotBlank() && artistScore < MIN_ARTIST_SCORE) || durationMismatch) {
                return@mapNotNull null
            }

            // A malformed synced-LRC field must not hide a usable plain-text lyric field.
            val synced = candidate.syncedLyrics?.takeIf { it.isNotBlank() && it.length <= MAX_LYRICS_CHARS }
            val plain = candidate.plainLyrics?.takeIf { it.isNotBlank() && it.length <= MAX_LYRICS_CHARS }
            val syncedUsable = synced?.takeIf { LrcParser.parse(it).isNotEmpty() }
            val lyrics = syncedUsable ?: plain ?: return@mapNotNull null
            val hasTimestamps = syncedUsable != null
            val score = titleScore * 0.7 + artistScore * 0.3 + if (hasTimestamps) 0.05 else 0.0
            Match(lyrics, hasTimestamps, score)
        }.maxByOrNull { it.score }
            ?.takeIf { it.score >= MIN_TOTAL_SCORE }
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace(Regex("\\[[^]]*]|\\([^)]*\\)"), " ")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun similarity(a: String, b: String): Double {
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        if (maxOf(a.length, b.length) > MAX_METADATA_CHARS) return 0.0
        val distance = levenshtein(a, b)
        return 1.0 - distance.toDouble() / maxOf(a.length, b.length)
    }

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1)
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(current[j] + 1, previous[j + 1] + 1, previous[j] + cost)
            }
            previous = current
        }
        return previous[b.length]
    }

    private const val MAX_CANDIDATES = 100
    private const val MAX_METADATA_CHARS = 256
    private const val MAX_LYRICS_CHARS = 300_000
    private const val MAX_DURATION_DELTA_SECONDS = 20.0
    private const val MAX_DURATION_MS = 24L * 60L * 60L * 1_000L
    private const val MIN_TITLE_SCORE = 0.78
    private const val MIN_ARTIST_SCORE = 0.45
    private const val MIN_TOTAL_SCORE = 0.74
}
