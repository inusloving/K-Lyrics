package com.example.klyrics

import android.content.Context
import java.security.MessageDigest

/** Bounded local cache for completed AI study responses; cached entries remain usable offline. */
class AiStudyCache(context: Context) {
    private val prefs = context.getSharedPreferences("klyrics_ai_cache", Context.MODE_PRIVATE)

    @Synchronized
    fun get(task: String, text: String): String? {
        val entryKey = key(task, text)
        val value = prefs.getString(entryKey, null) ?: return null
        prefs.edit().putLong(accessKey(entryKey), System.currentTimeMillis()).apply()
        return value
    }

    @Synchronized
    fun put(task: String, text: String, result: String) {
        if (text.isBlank() || result.isBlank() || text.length > MAX_TEXT_CHARS || result.length > MAX_RESULT_CHARS) return
        val entryKey = key(task, text)
        val now = System.currentTimeMillis()
        val editor = prefs.edit()
            .putString(entryKey, result)
            .putLong(accessKey(entryKey), now)

        val existing = prefs.all.keys.filter(::isEntryKey).toMutableSet()
        existing.add(entryKey)
        if (existing.size > MAX_ENTRIES) {
            val removeCount = existing.size - MAX_ENTRIES
            val oldest = existing
                .filter { it != entryKey }
                .sortedBy { prefs.getLong(accessKey(it), 0L) }
                .take(removeCount)
            oldest.forEach {
                editor.remove(it)
                editor.remove(accessKey(it))
            }
        }
        editor.apply()
    }

    private fun key(task: String, text: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "entry:$task:$hex"
    }

    private fun accessKey(entryKey: String) = "access:$entryKey"
    private fun isEntryKey(value: String) = value.startsWith("entry:")

    private companion object {
        const val MAX_ENTRIES = 250
        const val MAX_TEXT_CHARS = 2_000
        const val MAX_RESULT_CHARS = 48 * 1024
    }
}
