package com.example.klyrics

enum class LearningMode {
    SIMPLE,
    DETAILED
}

data class LyricAppearance(
    val koreanColor: Int = 0xFFFFFFFF.toInt(),
    val chineseColor: Int = 0xFFA8D8FF.toInt(),
    val activeColor: Int = 0xFFFFD166.toInt(),
    val backgroundColor: Int = 0xFF171923.toInt(),
    val backgroundAlpha: Int = 82,
    val fontSizeSp: Float = 18f
)

/** Small preference wrapper; values remain local to the device. */
class KLyricsSettings(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("klyrics_settings", android.content.Context.MODE_PRIVATE)
    private val secretStore = SecretStore(context)

    var learningMode: LearningMode
        get() = runCatching { LearningMode.valueOf(prefs.getString("learning_mode", "DETAILED")!!) }
            .getOrDefault(LearningMode.DETAILED)
        set(value) { prefs.edit().putString("learning_mode", value.name).apply() }

    fun appearance(): LyricAppearance = LyricAppearance(
        koreanColor = prefs.getInt("korean_color", 0xFFFFFFFF.toInt()),
        chineseColor = prefs.getInt("chinese_color", 0xFFA8D8FF.toInt()),
        activeColor = prefs.getInt("active_color", 0xFFFFD166.toInt()),
        backgroundColor = prefs.getInt("background_color", 0xFF171923.toInt()),
        backgroundAlpha = prefs.getInt("background_alpha", 82),
        fontSizeSp = prefs.getFloat("font_size_sp", 18f)
    )

    var aiEndpoint: String
        get() = prefs.getString("ai_endpoint", "").orEmpty()
        set(value) { prefs.edit().putString("ai_endpoint", value.trim()).apply() }

    var aiAccessToken: String
        get() = secretStore.read("ai_access_token")
        set(value) { secretStore.write("ai_access_token", value.trim()) }

    var autoLookupEnabled: Boolean
        get() = prefs.getBoolean("auto_lookup_enabled", false)
        set(value) { prefs.edit().putBoolean("auto_lookup_enabled", value).apply() }

    fun overlayPosition(): Pair<Int, Int> = prefs.getInt("overlay_x", 0) to prefs.getInt("overlay_y", 180)

    fun saveOverlayPosition(x: Int, y: Int) {
        prefs.edit().putInt("overlay_x", x).putInt("overlay_y", y).apply()
    }

    fun saveAppearance(value: LyricAppearance) {
        prefs.edit()
            .putInt("korean_color", value.koreanColor)
            .putInt("chinese_color", value.chineseColor)
            .putInt("active_color", value.activeColor)
            .putInt("background_color", value.backgroundColor)
            .putInt("background_alpha", value.backgroundAlpha.coerceIn(0, 100))
            .putFloat("font_size_sp", value.fontSizeSp.coerceIn(12f, 36f))
            .apply()
    }
}
