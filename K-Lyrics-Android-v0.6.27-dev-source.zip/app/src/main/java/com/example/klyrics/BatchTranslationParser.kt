package com.example.klyrics

/** Validates line-preserving batch translation responses before they are cached. */
object BatchTranslationParser {
    private val numberedLine = Regex("^(\\d+)[.)、]\\s*(.+)$")
    private val bulletLine = Regex("^[-*•]\\s+(.+)$")

    /**
     * Accepts either exactly [expectedCount] plain lines or a fully numbered 1..N list.
     * Mixed numbering, missing/duplicated/out-of-order indices and extra commentary are rejected.
     */
    fun parse(response: String, expectedCount: Int): List<String> {
        require(expectedCount > 0) { "expectedCount must be positive" }
        val cleaned = response.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .filterNot { it == "```" || it.startsWith("```text") || it.startsWith("```plaintext") }
            .toList()
        require(cleaned.size == expectedCount) { "译文行数与原文不一致" }

        val numbered = cleaned.map { numberedLine.matchEntire(it) }
        if (numbered.any { it != null }) {
            require(numbered.all { it != null }) { "AI 返回了混合编号格式" }
            val indices = numbered.map { it!!.groupValues[1].toIntOrNull() }
            require(indices == (1..expectedCount).toList()) { "AI 返回的行号缺失、重复或顺序错误" }
            return numbered.map { it!!.groupValues[2].trim() }.also { lines ->
                require(lines.all { it.isNotBlank() }) { "AI 返回了空译文" }
            }
        }

        val plain = cleaned.map { line -> bulletLine.matchEntire(line)?.groupValues?.get(1)?.trim() ?: line }
        require(plain.all { it.isNotBlank() }) { "AI 返回了空译文" }
        require(plain.none { it.startsWith("说明:") || it.startsWith("说明：") || it.startsWith("译文:") || it.startsWith("译文：") }) {
            "AI 返回内容包含额外说明，无法安全对应原文"
        }
        return plain
    }
}
