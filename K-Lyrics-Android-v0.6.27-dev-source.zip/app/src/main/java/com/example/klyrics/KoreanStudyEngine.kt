package com.example.klyrics

/** Small, transparent offline reference set. It intentionally avoids guessing for unknown words. */
object KoreanStudyEngine {
    data class WordInfo(
        val surface: String,
        val lemma: String,
        val partOfSpeech: String,
        val meaning: String,
        val explanation: String,
        val example: String,
        val attachedParticle: String? = null,
        val pluralMarker: Boolean = false,
        val attachedParticles: List<String> = attachedParticle?.let(::listOf) ?: emptyList(),
        val connectiveEnding: String? = null,
        val connectiveMeaning: String? = null,
        val adnominalEnding: String? = null,
        val nominalizingEnding: String? = null
    )

    data class GrammarHint(val pattern: String, val meaning: String, val note: String)

    private data class Entry(val lemma: String, val pos: String, val meaning: String, val explanation: String, val example: String)

    private val dictionary = mapOf(
        "나" to Entry("나", "代词", "我", "说话人指称自己的非敬语表达。", "나는 오늘 집에 있어요."),
        "너" to Entry("너", "代词", "你", "对关系亲近的人使用的非敬语表达。", "너는 지금 뭐 해?"),
        "우리" to Entry("우리", "代词", "我们；我们的", "常用于表达共同体，也可用于亲近关系。", "우리 같이 가요."),
        "사람" to Entry("사람", "名词", "人；人们", "指人或某一群体。", "좋은 사람을 만났어요."),
        "마음" to Entry("마음", "名词", "心；心意；内心", "表示情感、想法或内心状态。", "네 마음을 이해해요."),
        "사랑" to Entry("사랑", "名词", "爱；爱情", "表示爱或珍惜的感情。", "사랑은 어려워요."),
        "오늘" to Entry("오늘", "名词/副词", "今天", "表示当天。", "오늘 날씨가 좋아요."),
        "내일" to Entry("내일", "名词/副词", "明天", "表示第二天。", "내일 만나요."),
        "지금" to Entry("지금", "名词/副词", "现在", "表示当前时间。", "지금 출발해요."),
        "정말" to Entry("정말", "副词", "真的；实在", "用于强调真实性或程度。", "정말 고마워요."),
        "너무" to Entry("너무", "副词", "太；非常", "表示程度高，口语中常作‘非常’。", "너무 좋아요."),
        "아직" to Entry("아직", "副词", "还；尚未", "表示某状态持续到现在或尚未发生。", "아직 안 먹었어요."),
        "다시" to Entry("다시", "副词", "再次；重新", "表示重复进行某动作。", "다시 말해 주세요."),
        "함께" to Entry("함께", "副词", "一起；共同", "表示共同参与。", "우리 함께 공부해요."),
        "괜찮다" to Entry("괜찮다", "形容词", "没关系；不错；可以", "表示状态没有问题，也可表示许可或安慰。", "이제 괜찮아요."),
        "좋다" to Entry("좋다", "形容词", "好；不错", "表示性质、状态令人满意，也可表示心情或评价良好。", "오늘 기분이 좋아요."),
        "좋아하다" to Entry("좋아하다", "动词", "喜欢", "表示对人或事物有好感。", "저는 음악을 좋아해요."),
        "사랑하다" to Entry("사랑하다", "动词", "爱；深爱", "表示深厚的喜爱或爱情。", "가족을 사랑해요."),
        "보다" to Entry("보다", "动词", "看；观看", "表示视觉感知，也可表示尝试（아/어 보다）。", "영화를 봐요."),
        "가다" to Entry("가다", "动词", "去；走", "表示朝某处移动。", "학교에 가요."),
        "오다" to Entry("오다", "动词", "来", "表示向说话人所在处移动。", "친구가 와요."),
        "하다" to Entry("하다", "动词", "做", "高频动词，可与名词结合构成动作。", "숙제를 해요."),
        "먹다" to Entry("먹다", "动词", "吃", "表示进食。", "밥을 먹어요."),
        "듣다" to Entry("듣다", "动词", "听", "ㄷ不规则动词，部分元音词尾前变为 들어。", "음악을 들어요."),
        "알다" to Entry("알다", "动词", "知道；认识", "表示掌握信息或认识某人。", "그 사람을 알아요."),
        "모르다" to Entry("모르다", "动词", "不知道", "르不规则动词，常见活用为 몰라요。", "저는 잘 몰라요."),
        "기다리다" to Entry("기다리다", "动词", "等待", "表示等待某人或某事。", "여기서 기다려요."),
        "생각하다" to Entry("생각하다", "动词", "想；认为", "表示思考或表达观点。", "좋은 생각이라고 생각해요."),
        "말하다" to Entry("말하다", "动词", "说；讲", "表示用语言表达。", "천천히 말해 주세요."),
        "웃다" to Entry("웃다", "动词", "笑", "表示发笑。", "친구가 웃어요."),
        "울다" to Entry("울다", "动词", "哭", "表示哭泣。", "아이가 울어요."),
        "되다" to Entry("되다", "动词", "成为；可以；行", "依语境表示变化、结果或许可。", "이제 시작해도 돼요."),
        "있다" to Entry("있다", "动词/形容词", "有；在；存在", "表示存在、拥有或位置。", "책이 있어요."),
        "없다" to Entry("없다", "形容词", "没有；不在", "表示不存在或不拥有。", "시간이 없어요."),
        "싶다" to Entry("싶다", "补助形容词", "想；希望", "常与 -고 결합，表示愿望。", "한국에 가고 싶어요."),
        "주다" to Entry("주다", "动词/补助动词", "给；为别人做", "表示给予，也可构成 -아/어 주다。", "도와 주세요."),
        "그대" to Entry("그대", "代词", "你；您", "常见于歌词和文学表达，带有抒情色彩。", "그대가 보고 싶어요."),
        "눈물" to Entry("눈물", "名词", "眼泪", "指因情绪或生理反应流出的泪水。", "눈물이 흘러요."),
        "기억" to Entry("기억", "名词", "记忆；回忆", "指保留在脑海中的经历或信息。", "그날을 기억해요."),
        "시간" to Entry("시간", "名词", "时间；小时", "可表示抽象时间或具体时长。", "시간이 빨리 가요."),
        "하루" to Entry("하루", "名词", "一天；一日", "表示从早到晚的一整天或一天的时长。", "하루가 길었어요."),
        "밤" to Entry("밤", "名词", "夜晚；夜里", "表示太阳落山后的时间。", "밤이 깊었어요."),
        "꿈" to Entry("꿈", "名词", "梦；梦想", "可指睡眠中的梦，也可指人生目标。", "꿈을 꾸고 있어요."),
        "끝" to Entry("끝", "名词", "尽头；结束", "表示空间或过程的终点。", "이게 끝이 아니에요."),
        "곁" to Entry("곁", "名词", "身边；旁边", "常用于 곁에，表示在某人身旁。", "언제나 네 곁에 있을게요."),
        "마지막" to Entry("마지막", "名词/冠形词", "最后；最终", "表示顺序或时间上的末尾。", "마지막 기회예요."),
        "세상" to Entry("세상", "名词", "世界；世间", "可指现实世界或人们生活的社会。", "세상이 아름다워요."),
        "하늘" to Entry("하늘", "名词", "天空；天", "指地面上方的天空，也常用于抒情比喻。", "하늘을 바라봐요."),
        "바람" to Entry("바람", "名词", "风；愿望", "既可指空气流动，也可指希望或期盼。", "바람이 불어요."),
        "길" to Entry("길", "名词", "路；道路；方法", "可指实际道路，也可比喻人生方向。", "우리의 길을 찾아요."),
        "잊다" to Entry("잊다", "动词", "忘记", "表示记忆消失或不再记得。", "약속을 잊지 마세요."),
        "떠나다" to Entry("떠나다", "动词", "离开；出发", "表示离开某地或某人，也可表示启程。", "내일 서울을 떠나요."),
        "돌아오다" to Entry("돌아오다", "动词", "回来；返回", "表示回到原来的地点或状态。", "꼭 돌아올게요."),
        "부르다" to Entry("부르다", "动词", "呼唤；唱", "可表示叫某人，也可表示唱歌。", "네 이름을 불러요."),
        "바라보다" to Entry("바라보다", "动词", "凝望；注视", "表示持续地看着某个对象。", "멀리 바다를 바라봐요."),
        "원하다" to Entry("원하다", "动词", "希望；想要", "表示希望某事发生或想得到某物。", "행복을 원해요."),
        "아프다" to Entry("아프다", "形容词", "疼；痛苦", "可表示身体疼痛，也可表示情感上的痛苦。", "마음이 아파요."),
        "믿다" to Entry("믿다", "动词", "相信；信任", "表示相信某人或某事真实可靠。", "너를 믿어요."),
        "남다" to Entry("남다", "动词", "剩下；留下", "表示未被消耗或离开后仍然存在。", "기억에 남아요."),
        "지키다" to Entry("지키다", "动词", "守护；遵守", "可表示保护某人，也可表示遵守约定或规则。", "약속을 지킬게요."),
        "찾다" to Entry("찾다", "动词", "寻找；找到", "表示寻找对象，也可表示取回或访问。", "답을 찾았어요."),
        "놓다" to Entry("놓다", "动词", "放下", "表示把物体放在某处，也常构成 -아/어 놓다。", "가방을 여기에 놓아요."),
        "안다" to Entry("안다", "动词", "拥抱；抱", "表示用手臂抱住，也可依语境表示怀抱。", "아이를 안아요."),
        "걷다" to Entry("걷다", "动词", "走路；步行", "ㄷ不规则动词，部分元音词尾前变为 걸어요。", "함께 걸어요."),
        "살다" to Entry("살다", "动词", "生活；居住；活着", "表示生活或居住，也可指生命状态。", "열심히 살아요."),
        "흐르다" to Entry("흐르다", "动词", "流动；流逝", "可指液体流动，也可指时间流逝。", "시간이 흘러가요."),
        "피다" to Entry("피다", "动词", "开花；绽放", "表示花朵开放，也可用于比喻。", "꽃이 피어요."),
        "잠들다" to Entry("잠들다", "动词", "入睡；睡着", "表示进入睡眠状态。", "조용히 잠들어요."),
        "보내다" to Entry("보내다", "动词", "送；度过；发送", "可表示送某人离开、度过时间或发送信息。", "좋은 하루 보내세요."),
        "잡다" to Entry("잡다", "动词", "抓住；握住", "表示用手抓住，也可表示把握机会。", "손을 잡아요."),
        "느끼다" to Entry("느끼다", "动词", "感受；感觉", "表示通过感官或情绪体验某种状态。", "행복을 느껴요."),
        "울리다" to Entry("울리다", "动词", "使响；使哭", "可表示让声音响起，也可表示使人哭泣。", "종이 울려요."),
        "춥다" to Entry("춥다", "形容词", "冷；寒冷", "ㅂ不规则形容词，元音词尾前常变为 추워요。", "오늘은 날씨가 추워요."),
        "덥다" to Entry("덥다", "形容词", "热；炎热", "ㅂ不规则形容词，元音词尾前常变为 더워요。", "여름에는 정말 더워요."),
        "쉽다" to Entry("쉽다", "形容词", "容易；简单", "ㅂ不规则形容词，常见活用为 쉬워요。", "생각보다 쉬워요."),
        "어렵다" to Entry("어렵다", "形容词", "困难；不容易", "ㅂ不规则形容词，常见活用为 어려워요。", "한국어 문법은 어려워요."),
        "다르다" to Entry("다르다", "形容词", "不同；不一样", "르不规则形容词，常见活用为 달라요。", "생각이 달라요."),
        "빠르다" to Entry("빠르다", "形容词", "快；迅速", "르不规则形容词，常见活用为 빨라요。", "시간이 너무 빨라요."),
        "낫다" to Entry("낫다", "动词/形容词", "痊愈；更好", "部分语义下为ㅅ不规则，常见活用为 나아요；需结合词义判断。", "이제 감기가 나아요."),
        "짓다" to Entry("짓다", "动词", "建造；写；做", "ㅅ不规则动词，元音词尾前常变为 지어요。", "집을 지어요."),
        "슬프다" to Entry("슬프다", "形容词", "悲伤；难过", "ㅡ脱落活用，常见形式为 슬퍼요、슬픈。", "마음이 슬퍼요."),
        "예쁘다" to Entry("예쁘다", "形容词", "漂亮；好看", "ㅡ脱落活用，常见形式为 예뻐요、예쁜。", "꽃이 정말 예뻐요."),
        "힘들다" to Entry("힘들다", "形容词", "辛苦；费力；困难", "词干末尾 ㄹ 在 -(으)ㄴ 前脱落，冠形形式为 힘든。", "요즘 일이 힘들어요."),
        "그립다" to Entry("그립다", "形容词", "想念；怀念", "ㅂ不规则形容词，元音词尾前变为 그리워요，冠形形式为 그리운。", "고향이 그리워요."),
        "갈다" to Entry("갈다", "动词", "更换；替换；磨", "依语境可表示更换、替换或研磨。", "낡은 부품을 새것으로 갈아요."),
        "솎다" to Entry("솎다", "动词", "间苗；疏剪；挑选", "去掉多余部分，使留下的对象更疏或更整齐。", "텃밭의 상추를 솎아요."),
        "수줍다" to Entry("수줍다", "形容词", "害羞；腼腆", "表示性格或态度羞怯、不够大方。", "그 아이는 조금 수줍어요."),
        "서럽다" to Entry("서럽다", "形容词", "悲伤；委屈", "表示因处境或感受而悲伤、委屈。", "마음이 서러워요."),
        "갚다" to Entry("갚다", "动词", "偿还；报答", "可表示偿还债务或报答恩情。", "도움을 꼭 갚고 싶어요."),
        "솟다" to Entry("솟다", "动词", "涌出；升起", "表示向上涌起或突然出现。", "힘이 솟아요."),
        "죽다" to Entry("죽다", "动词", "死；去世", "表示生命活动终止；具体语气需结合语境。", "꽃이 겨울에 죽었어요."),
        "얼다" to Entry("얼다", "动词", "结冰；冻结", "表示液体因低温变成固体。", "물이 얼었어요."),
        "졸다" to Entry("졸다", "动词", "打瞌睡；犯困", "表示困倦时不由自主地入睡片刻。", "수업 중에 졸면 안 돼요."),
        "묶다" to Entry("묶다", "动词", "捆；系；绑", "表示把物体或事物系在一起。", "끈으로 상자를 묶어요."),
        "엮다" to Entry("엮다", "动词", "编织；编排；串联", "表示交织材料，也可表示组织内容。", "이야기를 재미있게 엮었어요.")
    )

    private val forms = mapOf(
        "괜찮아요" to "괜찮다", "괜찮았어요" to "괜찮다", "좋아요" to "좋다", "좋았어요" to "좋다", "좋아해요" to "좋아하다", "좋아했어요" to "좋아하다",
        "사랑해요" to "사랑하다", "사랑했어요" to "사랑하다", "봐요" to "보다", "봤어요" to "보다",
        "가요" to "가다", "갔어요" to "가다", "와요" to "오다", "왔어요" to "오다",
        "해요" to "하다", "했어요" to "하다", "먹어요" to "먹다", "먹었어요" to "먹다",
        "들어요" to "듣다", "들었어요" to "듣다", "알아요" to "알다", "알았어요" to "알다",
        "몰라요" to "모르다", "몰랐어요" to "모르다", "기다려요" to "기다리다", "기다렸어요" to "기다리다",
        "생각해요" to "생각하다", "생각했어요" to "생각하다", "말해요" to "말하다", "말했어요" to "말하다",
        "웃어요" to "웃다", "울어요" to "울다", "돼요" to "되다", "됐어요" to "되다",
        "있어요" to "있다", "있었어요" to "있다", "없어요" to "없다", "없었어요" to "없다",
        "싶어요" to "싶다", "줘요" to "주다", "주세요" to "주다",
        "잊어요" to "잊다", "잊었어요" to "잊다", "잊지" to "잊다",
        "떠나요" to "떠나다", "떠났어요" to "떠나다", "돌아와요" to "돌아오다", "돌아왔어요" to "돌아오다",
        "불러요" to "부르다", "불렀어요" to "부르다", "바라봐요" to "바라보다", "바라봤어요" to "바라보다",
        "원해요" to "원하다", "원했어요" to "원하다", "아파요" to "아프다", "아팠어요" to "아프다",
        "믿어요" to "믿다", "믿었어요" to "믿다", "남아요" to "남다", "남았어요" to "남다",
        "지켜요" to "지키다", "지켰어요" to "지키다", "찾아요" to "찾다", "찾았어요" to "찾다",
        "놓아요" to "놓다", "놨어요" to "놓다", "안아요" to "안다", "안았어요" to "안다",
        "걸어요" to "걷다", "걸었어요" to "걷다", "살아요" to "살다", "살았어요" to "살다",
        "흘러요" to "흐르다", "흘렀어요" to "흐르다", "피어요" to "피다", "폈어요" to "피다",
        "잠들어요" to "잠들다", "잠들었어요" to "잠들다", "보내요" to "보내다", "보냈어요" to "보내다",
        "잡아요" to "잡다", "잡았어요" to "잡다", "느껴요" to "느끼다", "느꼈어요" to "느끼다",
        "울려요" to "울리다", "울렸어요" to "울리다",
        "추워요" to "춥다", "추웠어요" to "춥다", "더워요" to "덥다", "더웠어요" to "덥다",
        "쉬워요" to "쉽다", "쉬웠어요" to "쉽다", "어려워요" to "어렵다", "어려웠어요" to "어렵다",
        "달라요" to "다르다", "달랐어요" to "다르다", "빨라요" to "빠르다", "빨랐어요" to "빠르다",
        "나아요" to "낫다", "나았어요" to "낫다", "지어요" to "짓다", "지었어요" to "짓다"
    )

    // Exact, dictionary-backed adnominal forms. These are deliberately explicit to avoid
    // guessing a stem from a surface form that may be ambiguous.
    private val adnominalForms = mapOf(
        "가는" to ("가다" to "-는"), "간" to ("가다" to "-(으)ㄴ"), "갈" to ("가다" to "-(으)ㄹ"),
        "오는" to ("오다" to "-는"), "온" to ("오다" to "-(으)ㄴ"), "올" to ("오다" to "-(으)ㄹ"),
        "먹는" to ("먹다" to "-는"), "먹은" to ("먹다" to "-(으)ㄴ"), "먹을" to ("먹다" to "-(으)ㄹ"),
        "보는" to ("보다" to "-는"), "본" to ("보다" to "-(으)ㄴ"), "볼" to ("보다" to "-(으)ㄹ"),
        "하는" to ("하다" to "-는"), "한" to ("하다" to "-(으)ㄴ"), "할" to ("하다" to "-(으)ㄹ"),
        "사랑하는" to ("사랑하다" to "-는"), "사랑한" to ("사랑하다" to "-(으)ㄴ"), "사랑할" to ("사랑하다" to "-(으)ㄹ"),
        "기다리는" to ("기다리다" to "-는"), "기다린" to ("기다리다" to "-(으)ㄴ"), "기다릴" to ("기다리다" to "-(으)ㄹ"),
        "웃는" to ("웃다" to "-는"), "웃은" to ("웃다" to "-(으)ㄴ"), "웃을" to ("웃다" to "-(으)ㄹ"),
        "우는" to ("울다" to "-는"), "운" to ("울다" to "-(으)ㄴ"), "울" to ("울다" to "-(으)ㄹ"),
        // Retrospective past forms are explicit: -던 often recalls an ongoing/habitual
        // past scene, while -았/었던 more clearly presents a completed past experience.
        "가던" to ("가다" to "-던（过去回想／持续或习惯）"),
        "갔던" to ("가다" to "-았/었던（过去经历回顾）"),
        "오던" to ("오다" to "-던（过去回想／持续或习惯）"),
        "왔던" to ("오다" to "-았/었던（过去经历回顾）"),
        "먹던" to ("먹다" to "-던（过去回想／持续或习惯）"),
        "먹었던" to ("먹다" to "-았/었던（过去经历回顾）"),
        "보던" to ("보다" to "-던（过去回想／持续或习惯）"),
        "봤던" to ("보다" to "-았/었던（过去经历回顾）"),
        "하던" to ("하다" to "-던（过去回想／持续或习惯）"),
        "했던" to ("하다" to "-았/었던（过去经历回顾）"),
        "사랑하던" to ("사랑하다" to "-던（过去回想／持续或习惯）"),
        "사랑했던" to ("사랑하다" to "-았/었던（过去经历回顾）"),
        "기다리던" to ("기다리다" to "-던（过去回想／持续或习惯）"),
        "기다렸던" to ("기다리다" to "-았/었던（过去经历回顾）"),
        "웃던" to ("웃다" to "-던（过去回想／持续或习惯）"),
        "웃었던" to ("웃다" to "-았/었던（过去经历回顾）"),
        "울던" to ("울다" to "-던（过去回想／持续或习惯）"),
        "울었던" to ("울다" to "-았/었던（过去经历回顾）"),
        // Adjectives use -(으)ㄴ for the attributive form commonly describing a present state.
        "좋은" to ("좋다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "좋을" to ("좋다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "아픈" to ("아프다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "아플" to ("아프다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "추운" to ("춥다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "추울" to ("춥다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "더운" to ("덥다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "더울" to ("덥다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "쉬운" to ("쉽다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "쉬울" to ("쉽다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "어려운" to ("어렵다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "어려울" to ("어렵다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "다른" to ("다르다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "다를" to ("다르다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "빠른" to ("빠르다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "빠를" to ("빠르다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "나은" to ("낫다" to "-(으)ㄴ（形容词现在冠形词尾）"),
        "나을" to ("낫다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "있는" to ("있다" to "-는（存在状态冠形词尾）"),
        "있을" to ("있다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "없는" to ("없다" to "-는（存在状态冠形词尾）"),
        "없을" to ("없다" to "-(으)ㄹ（冠形词尾：预期／可能）"),
        "좋았던" to ("좋다" to "-았/었던（过去状态回顾）"),
        "아팠던" to ("아프다" to "-았/었던（过去状态回顾）"),
        "추웠던" to ("춥다" to "-았/었던（过去状态回顾）"),
        "더웠던" to ("덥다" to "-았/었던（过去状态回顾）"),
        "쉬웠던" to ("쉽다" to "-았/었던（过去状态回顾）"),
        "어려웠던" to ("어렵다" to "-았/었던（过去状态回顾）"),
        "달랐던" to ("다르다" to "-았/었던（过去状态回顾）"),
        "빨랐던" to ("빠르다" to "-았/었던（过去状态回顾）"),
        "나았던" to ("낫다" to "-았/었던（过去状态回顾）"),
        "살던" to ("살다" to "-던（过去回想／持续或习惯）"),
        "살았던" to ("살다" to "-았/었던（过去经历回顾）"),
        "잊던" to ("잊다" to "-던（过去回想／持续或习惯）"),
        "잊었던" to ("잊다" to "-았/었던（过去经历回顾）"),
        // Additional high-frequency adjective forms with explicit irregular/ㄹ-drop notes.
        "슬픈" to ("슬프다" to "-(으)ㄴ（ㅡ脱落后的形容词现在冠形）"),
        "슬펐던" to ("슬프다" to "-았/었던（过去状态回顾；ㅡ脱落）"),
        "예쁜" to ("예쁘다" to "-(으)ㄴ（ㅡ脱落后的形容词现在冠形）"),
        "예뻤던" to ("예쁘다" to "-았/었던（过去状态回顾；ㅡ脱落）"),
        "힘든" to ("힘들다" to "-(으)ㄴ（ㄹ脱落后的形容词现在冠形）"),
        "힘들었던" to ("힘들다" to "-았/었던（过去状态回顾）"),
        "그리운" to ("그립다" to "-(으)ㄴ（ㅂ不规则形容词现在冠形）"),
        "그리웠던" to ("그립다" to "-았/었던（过去状态回顾；ㅂ不规则）")
    )

    // Exact, dictionary-backed nominalized forms. -기 turns a predicate into a noun-like
    // expression; only listed dictionary stems are accepted to avoid speculative stemming.
    private val nominalizedForms = mapOf(
        "가기" to "가다", "오기" to "오다", "보기" to "보다", "하기" to "하다",
        "먹기" to "먹다", "듣기" to "듣다", "걷기" to "걷다", "살기" to "살다",
        "웃기" to "웃다", "울기" to "울다", "잊기" to "잊다", "믿기" to "믿다",
        "찾기" to "찾다", "지키기" to "지키다", "사랑하기" to "사랑하다",
        "좋아하기" to "좋아하다", "기다리기" to "기다리다", "생각하기" to "생각하다",
        "말하기" to "말하다", "바라보기" to "바라보다", "떠나기" to "떠나다"
    )

    // Exact lexicalized -ㅁ/-음 nominal forms. The dictionary gloss is adjusted to
    // the noun sense so the learner does not see only the source verb's definition.
    private data class EumNominal(val lemma: String, val meaning: String, val example: String)
    private val eumNominalizedForms = mapOf(
        "웃음" to EumNominal("웃다", "笑声；笑容", "그의 웃음이 참 밝아요."),
        "울음" to EumNominal("울다", "哭泣；哭声", "아이의 울음이 들려요."),
        "믿음" to EumNominal("믿다", "信任；信念", "서로에 대한 믿음이 중요해요."),
        "걸음" to EumNominal("걷다", "步伐；步行", "걸음이 조금 느려요."),
        "앎" to EumNominal("알다", "知晓；认识", "앎은 배움에서 시작돼요."),
        "삶" to EumNominal("살다", "生活；人生", "삶은 선택의 연속이에요."),
        "죽음" to EumNominal("죽다", "死亡；逝世", "죽음은 삶의 일부로 여겨지기도 해요."),
        "얼음" to EumNominal("얼다", "冰；冰块", "얼음이 천천히 녹아요."),
        "졸음" to EumNominal("졸다", "困意；睡意", "졸음이 쏟아져요."),
        "묶음" to EumNominal("묶다", "捆；束；一组", "꽃 한 묶음을 샀어요."),
        "엮음" to EumNominal("엮다", "编织；编排", "이 책은 여러 이야기를 엮음으로써 완성됐어요."),
        "갈음" to EumNominal("갈다", "替代；代替；更换", "이 문장으로 인사를 갈음할게요."),
        "솎음" to EumNominal("솎다", "间苗；疏剪", "채소 솎음 작업을 했어요."),
        "수줍음" to EumNominal("수줍다", "害羞；腼腆", "그의 수줍음이 귀여워요."),
        "서러움" to EumNominal("서럽다", "悲伤；委屈", "오랜 서러움이 조금씩 풀렸어요."),
        "앙갚음" to EumNominal("갚다", "报复；回报", "앙갚음보다는 대화로 풀어 보세요."),
        "용솟음" to EumNominal("솟다", "涌起；喷涌", "가슴에서 용솟음치는 기쁨을 느꼈어요.")
    )

    // Exact, dictionary-backed connective forms; endings are distinct from particles.
    private val connectiveForms = mapOf(
        // -고: coordination / sequence.
        "가고" to "가다", "오고" to "오다", "하고" to "하다", "먹고" to "먹다",
        "듣고" to "듣다", "보고" to "보다", "울고" to "울다", "웃고" to "웃다",
        "살고" to "살다", "잊고" to "잊다", "믿고" to "믿다", "떠나고" to "떠나다",
        "돌아오고" to "돌아오다", "기다리고" to "기다리다", "사랑하고" to "사랑하다",
        "좋아하고" to "좋아하다", "바라보고" to "바라보다", "부르고" to "부르다",
        "흐르고" to "흐르다", "피고" to "피다", "잠들고" to "잠들다",
        "보내고" to "보내다", "잡고" to "잡다", "느끼고" to "느끼다",
        "지키고" to "지키다", "찾고" to "찾다", "놓고" to "놓다", "안고" to "안다",
        // -지만: contrast. These are explicit surface forms, not generated guesses.
        "가지만" to "가다", "오지만" to "오다", "하지만" to "하다", "먹지만" to "먹다",
        "듣지만" to "듣다", "보지만" to "보다", "울지만" to "울다", "웃지만" to "웃다",
        "살지만" to "살다", "잊지만" to "잊다", "믿지만" to "믿다", "기다리지만" to "기다리다",
        "사랑하지만" to "사랑하다", "좋아하지만" to "좋아하다", "바라보지만" to "바라보다",
        "아프지만" to "아프다", "춥지만" to "춥다", "덥지만" to "덥다",
        // -아/어서 and -으며: cause, sequence, or manner depending on context.
        "가서" to "가다", "와서" to "오다", "해서" to "하다", "먹어서" to "먹다",
        "들어서" to "듣다", "봐서" to "보다", "울어서" to "울다", "웃어서" to "웃다",
        "살아서" to "살다", "기다려서" to "기다리다", "사랑해서" to "사랑하다",
        "좋아해서" to "좋아하다", "아파서" to "아프다", "몰라서" to "모르다",
        "달라서" to "다르다", "빨라서" to "빠르다", "추워서" to "춥다", "더워서" to "덥다",
        "쉬워서" to "쉽다", "어려워서" to "어렵다", "걸으며" to "걷다", "걸어서" to "걷다",
        // -면 / -(으)면: condition.
        "가면" to "가다", "오면" to "오다", "하면" to "하다", "먹으면" to "먹다",
        "들으면" to "듣다", "보면" to "보다", "울면" to "울다", "웃으면" to "웃다",
        "살면" to "살다", "잊으면" to "잊다", "믿으면" to "믿다", "기다리면" to "기다리다",
        "사랑하면" to "사랑하다", "좋아하면" to "좋아하다", "아프면" to "아프다",
        "추우면" to "춥다", "더우면" to "덥다", "쉬우면" to "쉽다", "어려우면" to "어렵다"
    )

    // Role particles are removed before auxiliary particles (e.g. 에서 + 도, 에게 + 만).
    // Keep compound source/direction forms intact where they are lexicalized as one suffix.
    private val particles = listOf(
        "으로부터", "에게서", "한테서", "한테", "에게", "에서", "으로", "부터", "까지",
        "처럼", "보다", "마다", "하고", "로", "만", "도", "은", "는", "이", "가",
        "을", "를", "의", "에", "와", "과", "랑"
    ).sortedByDescending { it.length }

    private val grammarRules = listOf(
        Regex("\\b.+고 싶(?:어요|어|다)?") to GrammarHint("-고 싶다", "想要做……", "接在动词词干后表达愿望；主语通常是说话人或感情主体。"),
        Regex(".+(아|어|여)도 돼요?") to GrammarHint("-아/어도 되다", "可以……；允许……", "用于询问或表达许可。"),
        Regex(".+(으)?면") to GrammarHint("-(으)면", "如果……；当……时", "表示条件或假设。"),
        Regex(".+고 있어요") to GrammarHint("-고 있다", "正在……", "表示动作正在进行；部分状态动词的搭配需结合语境。"),
        Regex(".+지 않아요?") to GrammarHint("-지 않다", "不……", "通过 -지 않다 构成否定表达。"),
        Regex(".+(아|어|여) 봐요") to GrammarHint("-아/어 보다", "试着……", "表示尝试做某事。"),
        Regex(".+(지만|는데|은데|ㄴ데)") to GrammarHint("-지만 / -는데", "但是；补充背景", "-지만 常表转折；-는데 可引出背景、对比或后续话语。"),
        Regex(".+(아서|어서|여서)") to GrammarHint("-아/어서", "因为……；然后……", "可表示原因或动作先后，需结合上下文判断。"),
        Regex(".+(ㄹ까요|을까요)\\?") to GrammarHint("-(으)ㄹ까요?", "要不要……？；……怎么样？", "常用于提议、征求意见或推测。"),
        Regex(".+(ㄹ게요|을게요)") to GrammarHint("-(으)ㄹ게요", "我会……；我来……", "表示说话人的意愿或承诺，通常面向听话人。"),
        Regex(".+네요") to GrammarHint("-네요", "啊；呢（即时感受）", "表达说话人当下发现、感叹或评价。"),
        Regex(".+군요") to GrammarHint("-군요", "原来如此；啊", "表示新发现或领悟，语气依场景变化。"),
        Regex(".+(세요|으세요|십니다|으십니다)") to GrammarHint("-(으)시-", "主语尊敬表达", "通过尊敬词缀表达对主语的尊敬；具体语气需结合句尾判断。"),
        Regex(".+(아|어|여) 주세요") to GrammarHint("-아/어 주세요", "请为我……；请……", "礼貌地请求对方做某事。"),
        Regex(".+(으)?ㄹ 수 있어요") to GrammarHint("-(으)ㄹ 수 있다", "能够……；可以……", "表示能力或可能性。"),
        Regex(".+는 것 같아요") to GrammarHint("-는 것 같다", "好像……；似乎……", "表示推测或不确定判断，具体形式依词类和时态变化。"),
        Regex(".+(이에요|예요|입니다)") to GrammarHint("이다 系列", "是……", "用于名词谓语；이에요/예요 为礼貌口语，입니다 更正式。"),
        Regex(".+(어요|아요|해요)") to GrammarHint("해요体", "礼貌非正式语体", "日常礼貌口语结尾；具体时态需结合词干与语境分析。")
    )

    fun analyzeWord(surface: String): WordInfo? {
        val clean = surface.trim().trim(' ', '.', ',', '!', '?', '。', '，', '！', '？', '"', '\'')
        if (clean.isBlank()) return null

        fun endingFor(form: String): String? = when {
            connectiveForms[form] == null -> null
            form.endsWith("지만") -> "-지만"
            form.endsWith("서") -> "-아/어서"
            form.endsWith("으며") -> "-으며"
            form.endsWith("고") -> "-고"
            form.endsWith("으면") || form.endsWith("면") -> "-(으)면"
            else -> null
        }

        // A recognized conjugated form may itself be followed by auxiliary particles
        // (e.g. 가고도, 추워서도). Resolve the inner form only after peeling suffixes.
        var nominalizingEnding: String? = null
        var nominalizedMeaning: String? = null
        var nominalizedExample: String? = null
        var nominalizedPartOfSpeech: String? = null
        fun resolve(candidate: String): Triple<String, String?, String?>? {
            connectiveForms[candidate]?.let { return Triple(it, endingFor(candidate), null) }
            adnominalForms[candidate]?.let { return Triple(it.first, null, it.second) }
            nominalizedForms[candidate]?.let { nominalizingEnding = "-기（名词化词尾）"; return Triple(it, null, null) }
            eumNominalizedForms[candidate]?.let {
                nominalizingEnding = "-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）"
                nominalizedMeaning = it.meaning
                nominalizedExample = it.example
                nominalizedPartOfSpeech = "名词（词汇化派生名词）"
                return Triple(it.lemma, null, null)
            }
            forms[candidate]?.let { return Triple(it, null, null) }
            if (dictionary.containsKey(candidate)) return Triple(candidate, null, null)
            return null
        }

        var particle: String? = null
        var pluralMarker = false
        var attachedParticles: List<String> = emptyList()
        var resolved: Triple<String, String?, String?>? = resolve(clean)

        if (resolved == null) {
            var best: Triple<String, String?, String?>? = null
            var bestParticles: List<String> = emptyList()
            var bestPlural = false

            fun search(current: String, suffixes: List<String>, depth: Int) {
                if (best != null) return
                val plural = current.endsWith("들") && current.length > 1
                val stem = if (plural) current.dropLast(1) else current
                resolve(stem)?.let {
                    best = it
                    bestParticles = suffixes
                    bestPlural = plural
                    return
                }
                if (depth >= 3) return
                particles.forEach { suffix ->
                    if (current.endsWith(suffix) && current.length > suffix.length) {
                        search(current.removeSuffix(suffix), suffixes + suffix, depth + 1)
                    }
                }
            }

            search(clean, emptyList(), 0)
            resolved = best
            if (best != null) {
                attachedParticles = bestParticles.reversed()
                particle = attachedParticles.joinToString("+").ifEmpty { null }
                pluralMarker = bestPlural
            }
        }

        val (lemma, connectiveEnding, adnominalEnding) = resolved ?: return null
        val entry = dictionary[lemma] ?: return null
        val connectiveMeaning = when (connectiveEnding) {
            "-고" -> "连接动作或状态，可表示并列、先后等关系；具体关系依上下文判断。"
            "-지만" -> "表示转折，相当于‘但是／虽然……却……’。"
            "-아/어서" -> "可表示原因或动作先后；通常不直接用于命令、共动句的原因表达。"
            "-(으)면" -> "表示条件或假设，相当于‘如果……／当……时’。"
            "-으며" -> "较书面地连接并列动作或状态，也可表示同时进行。"
            else -> null
        }
        return WordInfo(
            clean, entry.lemma, nominalizedPartOfSpeech ?: entry.pos,
            nominalizedMeaning ?: entry.meaning,
            if (nominalizingEnding == "-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）") "这是已词汇化的派生名词；应优先记忆该名词在实际语境中的独立含义，不宜直接套用词干的动词或形容词释义。" else entry.explanation,
            nominalizedExample ?: entry.example, particle, pluralMarker, attachedParticles,
            connectiveEnding, connectiveMeaning, adnominalEnding, nominalizingEnding
        )
    }

    /**
     * Internal data-quality audit used by regression tests. It checks references and
     * learner-facing fields without pretending to validate linguistic correctness
     * automatically; semantic review still requires a trusted dictionary/editor.
     */
    internal fun validateDictionaryData(): List<String> = buildList {
        dictionary.forEach { (key, entry) ->
            if (key != entry.lemma) add("dictionary key/lemma mismatch: $key -> ${entry.lemma}")
            if (entry.meaning.isBlank()) add("missing meaning: $key")
            if (entry.explanation.isBlank()) add("missing explanation: $key")
            if (entry.example.isBlank() || !Regex("[가-힣]").containsMatchIn(entry.example)) {
                add("missing Korean example: $key")
            }
            if (entry.pos.isBlank()) add("missing part of speech: $key")
        }
        forms.forEach { (surface, lemma) ->
            if (lemma !in dictionary) add("form target missing from dictionary: $surface -> $lemma")
        }
        adnominalForms.forEach { (surface, analysis) ->
            if (analysis.first !in dictionary) add("adnominal target missing from dictionary: $surface -> ${analysis.first}")
        }
        nominalizedForms.forEach { (surface, lemma) ->
            if (lemma !in dictionary) add("-기 target missing from dictionary: $surface -> $lemma")
        }
        eumNominalizedForms.forEach { (surface, nominal) ->
            if (nominal.lemma !in dictionary) add("-음/-ㅁ target missing from dictionary: $surface -> ${nominal.lemma}")
            if (nominal.meaning.isBlank()) add("-음/-ㅁ noun meaning missing: $surface")
            if (nominal.example.isBlank() || !Regex("[가-힣]").containsMatchIn(nominal.example)) {
                add("-음/-ㅁ Korean example missing: $surface")
            } else if (!nominal.example.contains(surface)) {
                add("-음/-ㅁ example does not demonstrate the noun: $surface")
            }
        }
        connectiveForms.forEach { (surface, lemma) ->
            if (lemma !in dictionary) add("connective target missing from dictionary: $surface -> $lemma")
        }
    }

    fun analyzeSentence(sentence: String): List<GrammarHint> = grammarRules.mapNotNull { (pattern, hint) ->
        if (pattern.containsMatchIn(sentence.trim())) hint else null
    }.distinctBy { it.pattern }
}
