package com.example.klyrics

import java.io.IOException
import java.io.Reader

/** Reads at most [maxChars] characters from an untrusted network response. */
object BoundedTextReader {
    fun read(reader: Reader, maxChars: Int): String {
        require(maxChars > 0) { "maxChars must be positive" }
        val output = StringBuilder(minOf(maxChars, 8_192))
        val buffer = CharArray(4_096)
        while (true) {
            val remaining = maxChars - output.length
            // Read one extra character at the boundary so oversized responses are rejected,
            // rather than silently truncated into potentially valid-looking JSON.
            val count = reader.read(buffer, 0, minOf(buffer.size, remaining + 1))
            if (count < 0) return output.toString()
            if (count > remaining) throw IOException("response_too_large")
            output.append(buffer, 0, count)
        }
    }
}
