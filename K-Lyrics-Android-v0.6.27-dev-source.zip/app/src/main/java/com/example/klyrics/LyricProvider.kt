package com.example.klyrics

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URI

/** Public LRCLIB lookup. Only track metadata is sent; lyrics are cached locally after an explicit search. */
object LyricProvider {
    data class Result(val lines: List<LyricLine>, val rawLyrics: String, val source: String, val hasTimestamps: Boolean)

    fun search(title: String, artist: String, durationMs: Long? = null): Result? {
        require(title.isNotBlank()) { "歌曲标题为空" }
        require(title.length <= MAX_METADATA_CHARS && artist.length <= MAX_METADATA_CHARS) { "歌曲信息过长" }
        require(title.none { it.isISOControl() } && artist.none { it.isISOControl() }) { "歌曲信息包含无效字符" }
        require(durationMs == null || durationMs in 1L..MAX_DURATION_MS) { "歌曲时长无效" }
        val query = buildString {
            append("track_name=").append(enc(title.trim()))
            if (artist.isNotBlank()) append("&artist_name=").append(enc(artist.trim()))
            if (durationMs != null && durationMs > 0L) append("&duration=").append(durationMs / 1_000.0)
        }
        val connection = (URI("https://lrclib.net/api/search?$query").toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            instanceFollowRedirects = false
            connectTimeout = 8_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "K-Lyrics-Android/0.4 (lyrics lookup)")
        }
        try {
            if (connection.responseCode !in 200..299) throw IllegalStateException("歌词服务暂不可用（HTTP ${connection.responseCode}）")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use {
                BoundedTextReader.read(it, MAX_RESPONSE_CHARS)
            }
            val results = JSONArray(body)
            if (results.length() == 0) return null

            val candidates = (0 until minOf(results.length(), MAX_CANDIDATES)).mapNotNull { index ->
                val item = results.optJSONObject(index) ?: return@mapNotNull null
                LyricMatchSelector.Candidate(
                    title = item.optString("trackName"),
                    artist = item.optString("artistName"),
                    durationSeconds = item.optDouble("duration", -1.0),
                    syncedLyrics = item.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" },
                    plainLyrics = item.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                )
            }
            val best = LyricMatchSelector.select(title, artist, durationMs, candidates) ?: return null
            val parsed = if (best.hasTimestamps) LrcParser.parse(best.lyrics) else best.lyrics.lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { LyricLine(-1L, it) }
                .toList()
            if (parsed.isEmpty()) return null
            return Result(parsed, best.lyrics, "LRCLIB", best.hasTimestamps)
        } finally {
            connection.disconnect()
        }
    }

    private const val MAX_RESPONSE_CHARS = 1_000_000
    private const val MAX_CANDIDATES = 100
    private const val MAX_METADATA_CHARS = 256
    private const val MAX_DURATION_MS = 24L * 60L * 60L * 1_000L

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
}
