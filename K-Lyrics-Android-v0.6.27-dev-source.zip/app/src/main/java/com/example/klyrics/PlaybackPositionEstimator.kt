package com.example.klyrics

/** Safely extrapolates a MediaSession position using monotonic elapsed time. */
object PlaybackPositionEstimator {
    fun estimate(
        positionMs: Long,
        playing: Boolean,
        lastUpdateElapsedMs: Long,
        nowElapsedMs: Long,
        playbackSpeed: Float
    ): Long {
        val base = positionMs.coerceAtLeast(0L)
        if (!playing || lastUpdateElapsedMs <= 0L || nowElapsedMs <= lastUpdateElapsedMs) return base
        if (!playbackSpeed.isFinite() || playbackSpeed <= 0f) return base
        val elapsed = nowElapsedMs - lastUpdateElapsedMs
        val advance = (elapsed.toDouble() * playbackSpeed.toDouble())
            .coerceAtMost(Long.MAX_VALUE.toDouble()).toLong().coerceAtLeast(0L)
        return if (Long.MAX_VALUE - base < advance) Long.MAX_VALUE else base + advance
    }
}
