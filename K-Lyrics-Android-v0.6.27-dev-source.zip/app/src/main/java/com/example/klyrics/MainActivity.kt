package com.example.klyrics

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.text.InputType
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val store by lazy { LyricStore(this) }
    private var currentTitle = ""
    private var currentArtist = ""
    private val lookupExecutor = Executors.newSingleThreadExecutor()
    private var lookupButton: Button? = null
    private var batchTranslateButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 40, 36, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "K-Lyrics 韩语歌词助手"
            textSize = 24f
        }
        val description = TextView(this).apply {
            text = "支持 LRC / TXT 导入、在线歌词匹配、逐句同步校准、双语悬浮窗和点击学习。在线歌词搜索会发送歌曲标题与歌手名；AI 学习请求会发送所选句子到你配置的服务端。暂不读取酷狗私有 KRC 文件。"
            textSize = 15f
            setPadding(0, 20, 0, 20)
        }
        status = TextView(this).apply {
            text = "歌词状态：尚未导入"
            textSize = 14f
            setPadding(0, 8, 0, 16)
        }
        val notificationButton = Button(this).apply {
            text = "1. 开启通知读取权限"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val overlayPermissionButton = Button(this).apply {
            text = "2. 授予悬浮窗权限"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val importButton = Button(this).apply {
            text = "3. 导入当前歌曲 LRC / TXT 歌词"
            setOnClickListener {
                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/*"
                }
                startActivityForResult(picker, REQUEST_LRC)
            }
        }
        lookupButton = Button(this).apply {
            text = "4. 在线搜索当前歌曲歌词"
            setOnClickListener { searchCurrentLyrics() }
        }
        batchTranslateButton = Button(this).apply {
            text = "AI 批量翻译当前歌曲"
            setOnClickListener { batchTranslateCurrentTrack() }
        }
        val calibrationButton = Button(this).apply {
            text = "标记当前句开始时间（逐句校准）"
            setOnClickListener { calibrateNextLine() }
        }
        val exportBackupButton = Button(this).apply {
            text = "导出当前歌曲 .kllyrics 备份"
            setOnClickListener {
                val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
                val trackTitle = prefs.getString("title", "").orEmpty()
                if (trackTitle.isBlank() || store.load(trackTitle, prefs.getString("artist", "").orEmpty()).isEmpty()) {
                    Toast.makeText(this@MainActivity, "当前歌曲还没有可备份的歌词", Toast.LENGTH_SHORT).show()
                } else {
                    val safeName = trackTitle.replace(Regex("[^\\p{L}\\p{N}._-]"), "_").take(60).ifBlank { "lyrics" }
                    val create = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TITLE, "$safeName.kllyrics")
                    }
                    startActivityForResult(create, REQUEST_EXPORT_BACKUP)
                }
            }
        }
        val importBackupButton = Button(this).apply {
            text = "导入 .kllyrics 备份"
            setOnClickListener {
                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/*"
                }
                startActivityForResult(picker, REQUEST_IMPORT_BACKUP)
            }
        }
        val translationButton = Button(this).apply {
            text = "导入逐行中文译文 TXT"
            setOnClickListener {
                val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/*"
                }
                startActivityForResult(picker, REQUEST_TRANSLATIONS)
            }
        }
        val showButton = Button(this).apply {
            text = "显示悬浮歌词"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, LyricOverlayService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
        val autoLookupButton = Button(this).apply {
            text = "自动匹配歌词：${if (KLyricsSettings(this@MainActivity).autoLookupEnabled) "已开启" else "已关闭"}"
            setOnClickListener {
                val settings = KLyricsSettings(this@MainActivity)
                settings.autoLookupEnabled = !settings.autoLookupEnabled
                text = "自动匹配歌词：${if (settings.autoLookupEnabled) "已开启" else "已关闭"}"
                Toast.makeText(this@MainActivity, if (settings.autoLookupEnabled) "切歌时会向 LRCLIB 发送歌名和歌手以查找歌词" else "已关闭自动在线搜索", Toast.LENGTH_LONG).show()
            }
        }
        val learningModeButton = Button(this).apply {
            text = "切换查词模式（简单/详细）"
            setOnClickListener {
                val settings = KLyricsSettings(this@MainActivity)
                settings.learningMode = if (settings.learningMode == LearningMode.SIMPLE) LearningMode.DETAILED else LearningMode.SIMPLE
                Toast.makeText(this@MainActivity, "当前模式：${if (settings.learningMode == LearningMode.SIMPLE) "简单" else "详细"}", Toast.LENGTH_SHORT).show()
            }
        }
        val aiEndpointButton = Button(this).apply {
            text = "配置在线 AI 服务地址"
            setOnClickListener { configureAiEndpoint() }
        }
        val appearanceButton = Button(this).apply {
            text = "悬浮窗外观与位置设置"
            setOnClickListener { showAppearanceDialog() }
        }
        val hideButton = Button(this).apply {
            text = "隐藏悬浮歌词"
            setOnClickListener { stopService(Intent(this@MainActivity, LyricOverlayService::class.java)) }
        }
        layout.addView(title); layout.addView(description); layout.addView(status)
        layout.addView(notificationButton); layout.addView(overlayPermissionButton)
        layout.addView(importButton); layout.addView(lookupButton); layout.addView(batchTranslateButton); layout.addView(calibrationButton); layout.addView(translationButton); layout.addView(exportBackupButton); layout.addView(importBackupButton); layout.addView(showButton); layout.addView(autoLookupButton); layout.addView(learningModeButton); layout.addView(aiEndpointButton); layout.addView(appearanceButton); layout.addView(hideButton)
        setContentView(ScrollView(this).apply { addView(layout) })
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun configureAiEndpoint() {
        val settings = KLyricsSettings(this)
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 8, 40, 8)
        }
        val endpointField = EditText(this).apply {
            hint = "HTTPS 服务端地址"
            setSingleLine(true)
            setText(settings.aiEndpoint)
        }
        val tokenField = EditText(this).apply {
            hint = "服务访问码（不是模型 API Key）"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setText(settings.aiAccessToken)
        }
        fields.addView(endpointField)
        fields.addView(tokenField)
        AlertDialog.Builder(this)
            .setTitle("AI 服务配置")
            .setMessage("填写由可信管理者部署的 HTTPS 服务地址和访问码。模型 API Key 只保存在服务端，不能填写到这里。AI 请求会将所选韩语句子发送给该服务。")
            .setView(fields)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val endpoint = endpointField.text.toString().trim().trimEnd('/')
                val token = tokenField.text.toString().trim()
                if (endpoint.isNotBlank() && !endpoint.startsWith("https://", ignoreCase = true)) {
                    Toast.makeText(this, "服务地址必须以 https:// 开头", Toast.LENGTH_LONG).show()
                } else if (endpoint.isNotBlank() && token.isBlank()) {
                    Toast.makeText(this, "请填写服务访问码", Toast.LENGTH_LONG).show()
                } else {
                    val saved = runCatching {
                        settings.aiAccessToken = token
                        settings.aiEndpoint = endpoint
                    }
                    if (saved.isSuccess) {
                        Toast.makeText(this, if (endpoint.isBlank()) "已关闭在线 AI" else "AI 服务配置已安全保存", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, saved.exceptionOrNull()?.message ?: "无法安全保存 AI 配置", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .show()
    }

    private fun showAppearanceDialog() {
        val settings = KLyricsSettings(this)
        val original = settings.appearance()
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 12, 48, 8)
        }
        fun addSlider(label: String, max: Int, initial: Int): SeekBar {
            content.addView(TextView(this).apply { text = "$label：$initial"; textSize = 14f })
            val valueLabel = content.getChildAt(content.childCount - 1) as TextView
            return SeekBar(this).apply {
                this.max = max
                progress = initial
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        valueLabel.text = "$label：$progress"
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                    override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                })
                content.addView(this)
            }
        }
        val font = addSlider("字体大小（sp）", 24, (original.fontSizeSp.toInt() - 12).coerceIn(0, 24))
        val alpha = addSlider("背景不透明度（%）", 100, original.backgroundAlpha)
        content.addView(TextView(this).apply { text = "背景配色"; textSize = 14f; setPadding(0, 12, 0, 6) })
        var selectedBackground = Color.rgb(Color.red(original.backgroundColor), Color.green(original.backgroundColor), Color.blue(original.backgroundColor))
        var selectedKorean = original.koreanColor
        var selectedChinese = original.chineseColor
        var selectedActive = original.activeColor
        content.addView(TextView(this).apply { text = "韩语文字颜色"; textSize = 14f; setPadding(0, 12, 0, 6) })
        listOf("白色" to Color.WHITE, "暖黄" to Color.rgb(255, 220, 130), "薄荷绿" to Color.rgb(160, 240, 205)).forEach { (name, color) ->
            content.addView(Button(this).apply { text = name; setOnClickListener { selectedKorean = color } })
        }
        content.addView(TextView(this).apply { text = "中文译文颜色"; textSize = 14f; setPadding(0, 12, 0, 6) })
        listOf("浅蓝" to Color.rgb(168, 216, 255), "浅灰" to Color.LTGRAY, "淡粉" to Color.rgb(255, 190, 210)).forEach { (name, color) ->
            content.addView(Button(this).apply { text = name; setOnClickListener { selectedChinese = color } })
        }
        content.addView(TextView(this).apply { text = "当前句高亮颜色"; textSize = 14f; setPadding(0, 12, 0, 6) })
        listOf("金色" to Color.rgb(255, 209, 102), "青色" to Color.rgb(110, 230, 220), "粉色" to Color.rgb(255, 145, 180)).forEach { (name, color) ->
            content.addView(Button(this).apply { text = name; setOnClickListener { selectedActive = color } })
        }
        content.addView(TextView(this).apply { text = "背景配色"; textSize = 14f; setPadding(0, 12, 0, 6) })
        val palettes = listOf(
            "深色" to Color.rgb(23, 25, 35),
            "蓝紫" to Color.rgb(35, 35, 68),
            "墨绿" to Color.rgb(20, 48, 43)
        )
        palettes.forEach { (name, color) ->
            content.addView(Button(this).apply {
                text = name
                setOnClickListener { selectedBackground = color }
            })
        }
        AlertDialog.Builder(this)
            .setTitle("悬浮窗外观")
            .setView(ScrollView(this).apply { addView(content) })
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                settings.saveAppearance(original.copy(
                    fontSizeSp = (font.progress + 12).toFloat(),
                    backgroundAlpha = alpha.progress,
                    backgroundColor = selectedBackground,
                    koreanColor = selectedKorean,
                    chineseColor = selectedChinese,
                    activeColor = selectedActive
                ))
                if (Settings.canDrawOverlays(this)) {
                    stopService(Intent(this, LyricOverlayService::class.java))
                    startService(Intent(this, LyricOverlayService::class.java))
                }
            }
            .show()
    }

    private fun calibrateNextLine() {
        val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
        val title = prefs.getString("title", "").orEmpty()
        val artist = prefs.getString("artist", "").orEmpty()
        val position = prefs.getLong("calibration_position", -1L)
        if (title.isBlank() || position < 0L || !prefs.getBoolean("calibration_available", false)) {
            Toast.makeText(this, "尚未建立播放计时，请先播放歌曲", Toast.LENGTH_LONG).show()
            return
        }
        val index = store.calibrateNext(title, artist, position)
        if (index == null) {
            Toast.makeText(this, "没有待校准的歌词；请先导入 TXT 歌词", Toast.LENGTH_SHORT).show()
        } else {
            val remaining = store.untimedCount(title, artist)
            val nextLine = store.load(title, artist).getOrNull(index)?.text.orEmpty()
            val timingNote = if (prefs.getBoolean("position_available", false)) "媒体播放进度" else "本地计时（建议从歌曲开头重新播放以提高准确度）"
            Toast.makeText(this, "已标记第 ${index + 1} 句：$nextLine。剩余 $remaining 句。来源：$timingNote。请在下一句开始时再次点击", Toast.LENGTH_LONG).show()
            refreshOverlay(title, artist)
        }
    }

    /** Read user-selected documents with an explicit cap; SAF providers are untrusted inputs. */
    private fun readDocumentText(uri: Uri, maxChars: Int): String =
        contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { reader ->
            BoundedTextReader.read(reader, maxChars).removePrefix("\uFEFF")
        } ?: error("无法读取所选文件")

    private fun exportBackup(uri: Uri) {
        try {
            val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
            val title = prefs.getString("title", "").orEmpty()
            val artist = prefs.getString("artist", "").orEmpty()
            val lines = store.load(title, artist)
            val content = LyricBackupCodec.encode(LyricBackupCodec.Backup(title, artist, lines))
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                ?: error("无法写入备份文件")
            Toast.makeText(this, "已导出 ${lines.size} 句歌词及译文/时间戳", Toast.LENGTH_LONG).show()
        } catch (error: Exception) {
            Toast.makeText(this, "导出备份失败：${error.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importBackup(uri: Uri) {
        try {
            val content = readDocumentText(uri, MAX_BACKUP_IMPORT_CHARS)
            val backup = LyricBackupCodec.decode(content)
            store.saveLines(backup.title, backup.artist, backup.lines)
            store.saveTranslations(backup.title, backup.artist, backup.lines.map { it.translation.orEmpty() })
            Toast.makeText(this, "已恢复《${backup.title}》的 ${backup.lines.size} 句歌词", Toast.LENGTH_LONG).show()
            refreshStatus()
            val trackPrefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
            if (trackPrefs.getString("title", "").orEmpty() == backup.title && trackPrefs.getString("artist", "").orEmpty() == backup.artist) {
                refreshOverlay(backup.title, backup.artist)
            }
        } catch (error: Exception) {
            Toast.makeText(this, "导入备份失败：${error.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun importTranslations(uri: Uri) {
        try {
            val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
            val title = prefs.getString("title", "").orEmpty()
            val artist = prefs.getString("artist", "").orEmpty()
            if (title.isBlank()) {
                Toast.makeText(this, "请先播放歌曲，再导入对应译文", Toast.LENGTH_LONG).show()
                return
            }
            val translations = readDocumentText(uri, MAX_TEXT_IMPORT_CHARS)
                .lineSequence().map { it.trim() }.toList()
            val lineCount = store.load(title, artist).size
            if (translations.isEmpty()) {
                Toast.makeText(this, "译文文件为空", Toast.LENGTH_SHORT).show()
                return
            }
            store.saveTranslations(title, artist, translations)
            val warning = if (lineCount > 0 && lineCount != translations.size) "；译文 ${translations.size} 行，歌词 $lineCount 句，请检查顺序" else ""
            Toast.makeText(this, "已导入 ${translations.size} 行中文译文$warning", Toast.LENGTH_LONG).show()
            refreshStatus()
            refreshOverlay(title, artist)
        } catch (error: Exception) {
            Toast.makeText(this, "导入译文失败：${error.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun searchCurrentLyrics() {
        val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
        currentTitle = prefs.getString("title", "").orEmpty()
        currentArtist = prefs.getString("artist", "").orEmpty()
        val requestedTitle = currentTitle
        val requestedArtist = currentArtist
        if (requestedTitle.isBlank()) {
            Toast.makeText(this, "请先在酷狗播放歌曲", Toast.LENGTH_SHORT).show()
            return
        }
        lookupButton?.isEnabled = false
        lookupButton?.text = "正在搜索…"
        lookupExecutor.execute {
            try {
                val duration = prefs.getLong("duration", 0L)
                val result = LyricProvider.search(requestedTitle, requestedArtist, duration)
                runOnUiThread {
                    if (result == null) {
                        Toast.makeText(this, "没有找到足够匹配的歌词，可尝试导入 LRC/TXT", Toast.LENGTH_LONG).show()
                    } else {
                        // Persist against the exact track searched, even if playback changed meanwhile.
                        store.save(requestedTitle, requestedArtist, result.rawLyrics)
                        Toast.makeText(this, if (result.hasTimestamps) "已从 ${result.source} 缓存 ${result.lines.size} 句同步歌词" else "已从 ${result.source} 缓存 ${result.lines.size} 句静态歌词；可逐句校准", Toast.LENGTH_LONG).show()
                        val trackPrefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
                        val activeTitle = trackPrefs.getString("title", "").orEmpty()
                        val activeArtist = trackPrefs.getString("artist", "").orEmpty()
                        if (trackKey(activeTitle, activeArtist) == trackKey(requestedTitle, requestedArtist)) {
                            refreshStatus()
                            if (Settings.canDrawOverlays(this)) {
                                sendBroadcast(Intent(LyricOverlayService.ACTION_UPDATE).setPackage(packageName).apply {
                                    putExtra(LyricOverlayService.EXTRA_TITLE, requestedTitle)
                                    putExtra(LyricOverlayService.EXTRA_ARTIST, requestedArtist)
                                    putExtra(LyricOverlayService.EXTRA_PLAYING, trackPrefs.getBoolean("playing", false))
                                    putExtra(LyricOverlayService.EXTRA_POSITION, trackPrefs.getLong("position", 0L))
                                    putExtra(LyricOverlayService.EXTRA_POSITION_AVAILABLE, trackPrefs.getBoolean("position_available", false))
                                })
                            }
                        }
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "在线搜索失败：${error.message ?: "网络错误"}", Toast.LENGTH_LONG).show()
                }
            } finally {
                runOnUiThread {
                    lookupButton?.isEnabled = true
                    lookupButton?.text = "4. 在线搜索当前歌曲歌词"
                }
            }
        }
    }

    override fun onDestroy() {
        lookupExecutor.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQUEST_TRANSLATIONS) {
            importTranslations(uri)
            return
        }
        if (requestCode == REQUEST_EXPORT_BACKUP) {
            exportBackup(uri)
            return
        }
        if (requestCode == REQUEST_IMPORT_BACKUP) {
            importBackup(uri)
            return
        }
        if (requestCode != REQUEST_LRC) return
        try {
            val raw = readDocumentText(uri, MAX_TEXT_IMPORT_CHARS)
            val parsed = LrcParser.parse(raw)
            if (raw.isBlank()) {
                Toast.makeText(this, "歌词文件为空", Toast.LENGTH_LONG).show()
                return
            }
            val importedCount = if (parsed.isNotEmpty()) parsed.size else raw.lineSequence().count { it.isNotBlank() && !it.trim().startsWith("#") }
            if (importedCount == 0) {
                Toast.makeText(this, "没有识别到可用歌词文本", Toast.LENGTH_LONG).show()
                return
            }
            // v0.3 first-pass import associates the selected file with the currently reported track.
            val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
            currentTitle = prefs.getString("title", "") ?: ""
            currentArtist = prefs.getString("artist", "") ?: ""
            if (currentTitle.isBlank()) {
                Toast.makeText(this, "请先播放酷狗歌曲，再导入歌词", Toast.LENGTH_LONG).show()
                return
            }
            store.save(currentTitle, currentArtist, raw)
            Toast.makeText(this, if (parsed.isNotEmpty()) "已缓存 ${parsed.size} 句带时间戳歌词" else "已缓存 $importedCount 句歌词；请播放时逐句校准", Toast.LENGTH_LONG).show()
            refreshStatus()
            refreshOverlay(currentTitle, currentArtist)
        } catch (e: Exception) {
            Toast.makeText(this, "读取歌词失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun batchTranslateCurrentTrack() {
        val settings = KLyricsSettings(this)
        if (settings.aiEndpoint.isBlank() || settings.aiAccessToken.isBlank()) {
            Toast.makeText(this, "请先配置在线 AI 服务", Toast.LENGTH_LONG).show()
            return
        }
        val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
        val title = prefs.getString("title", "").orEmpty()
        val artist = prefs.getString("artist", "").orEmpty()
        val lines = store.load(title, artist)
        if (title.isBlank() || lines.isEmpty()) {
            Toast.makeText(this, "当前歌曲没有可翻译的歌词", Toast.LENGTH_SHORT).show()
            return
        }
        val translations = lines.map { it.translation.orEmpty() }.toMutableList()
        val pending = lines.indices.filter { translations[it].isBlank() }
        if (pending.isEmpty()) {
            Toast.makeText(this, "当前歌曲已有逐句译文", Toast.LENGTH_SHORT).show()
            return
        }
        batchTranslateButton?.isEnabled = false
        batchTranslateButton?.text = "AI 翻译中…"
        val endpoint = settings.aiEndpoint
        val token = settings.aiAccessToken
        lookupExecutor.execute {
            try {
                val batches = mutableListOf<List<Int>>()
                var batch = mutableListOf<Int>()
                var batchChars = 0
                pending.forEach { sourceIndex ->
                    val lineLength = lines[sourceIndex].text.length + 12
                    if (lineLength > 1_800) error("第 ${sourceIndex + 1} 句过长，无法批量翻译")
                    if (batch.isNotEmpty() && (batch.size >= 8 || batchChars + lineLength > 1_800)) {
                        batches += batch.toList()
                        batch = mutableListOf()
                        batchChars = 0
                    }
                    batch += sourceIndex
                    batchChars += lineLength
                }
                if (batch.isNotEmpty()) batches += batch.toList()
                batches.forEach { indices ->
                    val numbered = indices.mapIndexed { localIndex, sourceIndex -> "${localIndex + 1}. ${lines[sourceIndex].text}" }
                    val requestText = numbered.joinToString("\n")
                    val response = AiStudyClient.request(endpoint, token, "translate_batch", requestText)
                    val translated = BatchTranslationParser.parse(response, indices.size)
                    indices.forEachIndexed { batchIndex, sourceIndex -> translations[sourceIndex] = translated[batchIndex] }
                    store.saveTranslations(title, artist, translations)
                }
                runOnUiThread {
                    Toast.makeText(this, "已完成 ${pending.size} 句 AI 翻译", Toast.LENGTH_LONG).show()
                    refreshOverlay(title, artist)
                    refreshStatus()
                }
            } catch (error: Exception) {
                runOnUiThread { Toast.makeText(this, "批量翻译中断：${error.message}", Toast.LENGTH_LONG).show() }
            } finally {
                runOnUiThread {
                    batchTranslateButton?.isEnabled = true
                    batchTranslateButton?.text = "AI 批量翻译当前歌曲"
                }
            }
        }
    }

    private fun refreshOverlay(title: String, artist: String) {
        if (!Settings.canDrawOverlays(this)) return
        val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
        sendBroadcast(Intent(LyricOverlayService.ACTION_UPDATE).setPackage(packageName).apply {
            putExtra(LyricOverlayService.EXTRA_TITLE, title)
            putExtra(LyricOverlayService.EXTRA_ARTIST, artist)
            putExtra(LyricOverlayService.EXTRA_PLAYING, prefs.getBoolean("playing", false))
            putExtra(LyricOverlayService.EXTRA_POSITION, prefs.getLong("position", 0L))
            putExtra(LyricOverlayService.EXTRA_POSITION_AVAILABLE, prefs.getBoolean("position_available", false))
        })
    }

    private fun refreshStatus() {
        val prefs = getSharedPreferences("klyrics_track", MODE_PRIVATE)
        val t = prefs.getString("title", "") ?: ""
        val a = prefs.getString("artist", "") ?: ""
        status.text = if (t.isBlank()) "歌词状态：请先播放酷狗歌曲" else
            "当前歌曲：$t\n歌手：$a\n本地歌词：${if (store.hasLyrics(t, a)) "已缓存" else "未导入"}\n未校准句数：${store.untimedCount(t, a)}"
    }

    companion object {
        private const val REQUEST_LRC = 701
        private const val REQUEST_TRANSLATIONS = 702
        private const val REQUEST_EXPORT_BACKUP = 703
        private const val REQUEST_IMPORT_BACKUP = 704
        private const val MAX_TEXT_IMPORT_CHARS = 1_000_000
        private const val MAX_BACKUP_IMPORT_CHARS = 5_000_000
    }
}
