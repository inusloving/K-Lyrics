package com.example.klyrics

/** Finds exact, non-overlapping occurrences of a selected token in its source sentence. */
object SelectedWordHighlighter {
    fun ranges(source: String, word: String): List<IntRange> {
        if (source.isEmpty() || word.isBlank()) return emptyList()
        val result = mutableListOf<IntRange>()
        var from = 0
        while (from <= source.length - word.length) {
            val index = source.indexOf(word, from)
            if (index < 0) break
            result += index until (index + word.length)
            from = index + word.length
        }
        return result
    }
}
