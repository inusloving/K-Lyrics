package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.IOException
import java.io.StringReader

class BoundedTextReaderTest {
    @Test fun acceptsTextExactlyAtLimit() {
        assertEquals("12345", BoundedTextReader.read(StringReader("12345"), 5))
    }

    @Test fun rejectsTextOverLimitInsteadOfTruncating() {
        assertThrows(IOException::class.java) {
            BoundedTextReader.read(StringReader("123456"), 5)
        }
    }

    @Test fun acceptsEmptyResponse() {
        assertEquals("", BoundedTextReader.read(StringReader(""), 5))
    }

    @Test fun rejectsInvalidLimit() {
        assertThrows(IllegalArgumentException::class.java) {
            BoundedTextReader.read(StringReader("x"), 0)
        }
    }
}
