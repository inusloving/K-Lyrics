package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class LyricBackupCodecTest {
    @Test fun roundTripsKoreanChineseAndTiming() {
        val source = LyricBackupCodec.Backup(
            "봄날", "방탄소년단", listOf(
                LyricLine(1_250L, "보고 싶다", "我想你"),
                LyricLine(-1L, "많이 보고 싶다", null)
            )
        )
        val restored = LyricBackupCodec.decode(LyricBackupCodec.encode(source))
        assertEquals(source, restored)
    }

    @Test fun rejectsUnknownVersionAndCorruptRows() {
        assertThrows(IllegalArgumentException::class.java) {
            LyricBackupCodec.decode("KLYRICS_BACKUP\t9\nMETA\tYQ\tYg\nLINE\t0\tYw\t\n")
        }
        val valid = LyricBackupCodec.encode(LyricBackupCodec.Backup("song", "artist", listOf(LyricLine(0, "가사"))))
        assertThrows(IllegalArgumentException::class.java) {
            LyricBackupCodec.decode(valid.replace("LINE\t", "BROKEN\t"))
        }
    }
}
