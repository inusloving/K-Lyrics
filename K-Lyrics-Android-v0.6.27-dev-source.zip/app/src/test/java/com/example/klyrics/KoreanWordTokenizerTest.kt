package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KoreanWordTokenizerTest {
    @Test fun extractsDistinctHangulTokensInReadingOrder() {
        assertEquals(listOf("오늘은", "정말", "좋아요", "함께", "가요"), KoreanWordTokenizer.tokenize("오늘은 정말 좋아요, 오늘은 함께 가요!"))
    }

    @Test fun ignoresLatinNumbersAndPunctuation() {
        assertEquals(listOf("안녕하세요", "한국어"), KoreanWordTokenizer.tokenize("Hello 2026, 안녕하세요! 한국어."))
    }

    @Test fun respectsTokenLimitAndEmptyInput() {
        assertEquals(listOf("가", "나"), KoreanWordTokenizer.tokenize("가 나 다", 2))
        assertTrue(KoreanWordTokenizer.tokenize("   ").isEmpty())
        assertTrue(KoreanWordTokenizer.tokenize("가 나", 0).isEmpty())
    }
}
