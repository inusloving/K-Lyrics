package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Test

class SelectedWordHighlighterTest {
    @Test fun findsEveryExactOccurrence() {
        assertEquals(listOf(0..1, 4..5), SelectedWordHighlighter.ranges("가나 다가나", "가나"))
    }

    @Test fun returnsNoRangesForMissingOrBlankWord() {
        assertEquals(emptyList<IntRange>(), SelectedWordHighlighter.ranges("오늘은 좋아요", "없는말"))
        assertEquals(emptyList<IntRange>(), SelectedWordHighlighter.ranges("오늘은 좋아요", " "))
    }

    @Test fun matchesAreNonOverlapping() {
        assertEquals(listOf(0..1), SelectedWordHighlighter.ranges("가가가", "가가"))
    }
}
