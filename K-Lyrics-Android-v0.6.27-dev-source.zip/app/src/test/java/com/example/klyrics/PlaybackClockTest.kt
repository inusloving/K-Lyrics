package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackClockTest {
    @Test fun estimatesTimeWhenMediaSessionHasNoPosition() {
        val clock = PlaybackClock()
        assertEquals(0L, clock.update("song", true, null, 1_000L).positionMs)
        assertEquals(2_500L, clock.update("song", true, null, 3_500L).positionMs)
    }

    @Test fun pausesAndResumesWithoutAddingPausedTime() {
        val clock = PlaybackClock()
        clock.update("song", true, null, 1_000L)
        assertEquals(2_000L, clock.update("song", false, null, 3_000L).positionMs)
        assertEquals(2_000L, clock.update("song", false, null, 9_000L).positionMs)
        assertEquals(3_000L, clock.update("song", true, null, 10_000L).positionMs)
    }

    @Test fun exactMediaPositionResetsFallbackBase() {
        val clock = PlaybackClock()
        val media = clock.update("song", true, 12_000L, 50_000L)
        assertTrue(media.fromMediaSession)
        assertEquals(12_000L, media.positionMs)
        val fallback = clock.update("song", true, null, 51_000L)
        assertFalse(fallback.fromMediaSession)
        assertEquals(13_000L, fallback.positionMs)
    }

    @Test fun newTrackResetsLocalElapsedTime() {
        val clock = PlaybackClock()
        clock.update("first", true, null, 1_000L)
        assertEquals(0L, clock.update("second", true, null, 8_000L).positionMs)
    }

    @Test fun startsCorrectlyWhenMonotonicClockIsZero() {
        val clock = PlaybackClock()
        assertEquals(0L, clock.update("song", true, null, 0L).positionMs)
        assertEquals(1_500L, clock.update("song", true, null, 1_500L).positionMs)
        assertEquals(2_000L, clock.update("song", false, null, 2_000L).positionMs)
    }

    @Test fun ignoresBackwardClockReadingsAndSaturatesOnOverflow() {
        val clock = PlaybackClock()
        clock.update("song", true, null, 5_000L)
        assertEquals(0L, clock.update("song", true, null, 4_000L).positionMs)
        assertEquals(2_000L, clock.update("song", true, null, 7_000L).positionMs)

        clock.update("song", true, Long.MAX_VALUE - 5L, 8_000L)
        assertEquals(Long.MAX_VALUE, clock.update("song", true, null, 9_000L).positionMs)
    }

    @Test fun saturatesAccumulatedPositionWhenPlaybackIsPaused() {
        val clock = PlaybackClock()
        clock.update("song", true, Long.MAX_VALUE - 5L, 1_000L)
        assertEquals(Long.MAX_VALUE, clock.update("song", false, null, 1_010L).positionMs)
        assertEquals(Long.MAX_VALUE, clock.update("song", true, null, 50_000L).positionMs)
    }

}
