package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackPositionEstimatorTest {
    @Test fun extrapolatesUsingMonotonicElapsedTime() {
        assertEquals(12_000L, PlaybackPositionEstimator.estimate(10_000L, true, 5_000L, 7_000L, 1f))
        assertEquals(14_000L, PlaybackPositionEstimator.estimate(10_000L, true, 5_000L, 7_000L, 2f))
    }

    @Test fun ignoresInvalidSpeedAndNonAdvancingClock() {
        assertEquals(10_000L, PlaybackPositionEstimator.estimate(10_000L, true, 5_000L, 7_000L, Float.NaN))
        assertEquals(10_000L, PlaybackPositionEstimator.estimate(10_000L, true, 5_000L, 7_000L, Float.POSITIVE_INFINITY))
        assertEquals(10_000L, PlaybackPositionEstimator.estimate(10_000L, true, 5_000L, 7_000L, -1f))
        assertEquals(10_000L, PlaybackPositionEstimator.estimate(10_000L, true, 7_000L, 7_000L, 1f))
    }

    @Test fun saturatesInsteadOfOverflowing() {
        assertEquals(Long.MAX_VALUE, PlaybackPositionEstimator.estimate(Long.MAX_VALUE - 5L, true, 1L, 100L, 1f))
        assertEquals(0L, PlaybackPositionEstimator.estimate(-1L, true, 1L, 100L, 1f))
    }

    @Test fun doesNotAdvanceWhenPaused() {
        assertEquals(10_000L, PlaybackPositionEstimator.estimate(10_000L, false, 5_000L, 9_000L, 1f))
    }
}
