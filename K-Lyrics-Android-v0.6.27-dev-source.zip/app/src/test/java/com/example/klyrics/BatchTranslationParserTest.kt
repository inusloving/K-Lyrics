package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class BatchTranslationParserTest {
    @Test fun acceptsExactPlainLines() {
        assertEquals(listOf("第一句", "第二句"), BatchTranslationParser.parse("第一句\n第二句", 2))
    }

    @Test fun acceptsOrderedNumberedLinesAndMarkdownFence() {
        val response = "```text\n1. 第一行\n2) 第二行\n```"
        assertEquals(listOf("第一行", "第二行"), BatchTranslationParser.parse(response, 2))
    }

    @Test fun rejectsMissingExtraAndMixedLines() {
        assertThrows(IllegalArgumentException::class.java) { BatchTranslationParser.parse("只有一行", 2) }
        assertThrows(IllegalArgumentException::class.java) { BatchTranslationParser.parse("1. 第一行\n3. 第二行", 2) }
        assertThrows(IllegalArgumentException::class.java) { BatchTranslationParser.parse("1. 第一行\n第二行", 2) }
    }

    @Test fun rejectsCommentaryAndOutOfOrderNumbering() {
        assertThrows(IllegalArgumentException::class.java) { BatchTranslationParser.parse("说明：以下是翻译\n第一行", 2) }
        assertThrows(IllegalArgumentException::class.java) { BatchTranslationParser.parse("2. 第二行\n1. 第一行", 2) }
    }
}
