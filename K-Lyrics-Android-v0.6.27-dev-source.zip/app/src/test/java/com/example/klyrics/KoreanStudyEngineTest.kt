package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KoreanStudyEngineTest {
    @Test fun recognizesCommonInflectedForms() {
        assertEquals("가다", KoreanStudyEngine.analyzeWord("갔어요")?.lemma)
        assertEquals("먹다", KoreanStudyEngine.analyzeWord("먹어요")?.lemma)
    }

    @Test fun separatesSupportedParticleAfterKnownInflection() {
        val info = KoreanStudyEngine.analyzeWord("먹어요도")
        assertEquals("먹다", info?.lemma)
        assertEquals("도", info?.attachedParticle)
    }

    @Test fun recognizesCommonLyricVocabularyAndIrregularForms() {
        assertEquals("잊다", KoreanStudyEngine.analyzeWord("잊었어요")?.lemma)
        assertEquals("걷다", KoreanStudyEngine.analyzeWord("걸어요")?.lemma)
        assertEquals("기억", KoreanStudyEngine.analyzeWord("기억이")?.lemma)
        assertEquals("눈물", KoreanStudyEngine.analyzeWord("눈물이")?.lemma)
        assertEquals("도", KoreanStudyEngine.analyzeWord("돌아왔어요도")?.attachedParticle)
    }


    @Test fun recognizesPluralMarkerBeforeCaseParticles() {
        val subject = KoreanStudyEngine.analyzeWord("사람들이")
        assertEquals("사람", subject?.lemma)
        assertEquals(true, subject?.pluralMarker)
        assertEquals("이", subject?.attachedParticle)

        val topic = KoreanStudyEngine.analyzeWord("사람들은")
        assertEquals("사람", topic?.lemma)
        assertEquals(true, topic?.pluralMarker)
        assertEquals("는", topic?.attachedParticle)

        val objectForm = KoreanStudyEngine.analyzeWord("사람들을")
        assertEquals("사람", objectForm?.lemma)
        assertEquals(true, objectForm?.pluralMarker)
        assertEquals("을", objectForm?.attachedParticle)
    }


    @Test fun recognizesStackedParticlesInNaturalOrder() {
        val location = KoreanStudyEngine.analyzeWord("사람에게도")
        assertEquals("사람", location?.lemma)
        assertEquals(listOf("에게", "도"), location?.attachedParticles)

        val pluralLocation = KoreanStudyEngine.analyzeWord("사람들에게도")
        assertEquals("사람", pluralLocation?.lemma)
        assertEquals(true, pluralLocation?.pluralMarker)
        assertEquals(listOf("에게", "도"), pluralLocation?.attachedParticles)

        val place = KoreanStudyEngine.analyzeWord("사람에서만")
        assertEquals("사람", place?.lemma)
        assertEquals(listOf("에서", "만"), place?.attachedParticles)
    }

    @Test fun leavesUnsupportedMorphologyUnknown() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜단어들이"))
    }

    @Test fun doesNotInventUnknownMeanings() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜단어"))
    }


    @Test fun recognizesCommonIrregularConjugations() {
        assertEquals("춥다", KoreanStudyEngine.analyzeWord("추워요")?.lemma)
        assertEquals("덥다", KoreanStudyEngine.analyzeWord("더웠어요")?.lemma)
        assertEquals("쉽다", KoreanStudyEngine.analyzeWord("쉬워요")?.lemma)
        assertEquals("어렵다", KoreanStudyEngine.analyzeWord("어려웠어요")?.lemma)
        assertEquals("다르다", KoreanStudyEngine.analyzeWord("달라요")?.lemma)
        assertEquals("빠르다", KoreanStudyEngine.analyzeWord("빨랐어요")?.lemma)
        assertEquals("낫다", KoreanStudyEngine.analyzeWord("나았어요")?.lemma)
        assertEquals("짓다", KoreanStudyEngine.analyzeWord("지어요")?.lemma)
    }

    @Test fun recognizesIrregularConjugationWithParticle() {
        val info = KoreanStudyEngine.analyzeWord("추워요도")
        assertEquals("춥다", info?.lemma)
        assertEquals("도", info?.attachedParticle)
    }


    @Test fun recognizesDictionaryBackedConnectiveEndingsSeparatelyFromParticles() {
        val examples = mapOf(
            "가고" to "가다", "먹고" to "먹다", "보고" to "보다",
            "사랑하고" to "사랑하다", "기다리고" to "기다리다", "걸어서" to "걷다"
        )
        examples.forEach { (surface, lemma) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(lemma, info?.lemma)
            assertTrue(info?.connectiveEnding != null)
            assertTrue(info?.attachedParticles?.isEmpty() == true)
        }
    }

    @Test fun recognizesExplicitContrastCauseAndConditionForms() {
        val examples = mapOf(
            "가지만" to ("가다" to "-지만"),
            "먹지만" to ("먹다" to "-지만"),
            "사랑하지만" to ("사랑하다" to "-지만"),
            "걸어서" to ("걷다" to "-아/어서"),
            "추워서" to ("춥다" to "-아/어서"),
            "기다려서" to ("기다리다" to "-아/어서"),
            "가면" to ("가다" to "-(으)면"),
            "먹으면" to ("먹다" to "-(으)면"),
            "추우면" to ("춥다" to "-(으)면")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.connectiveEnding)
            assertTrue(info?.attachedParticles?.isEmpty() == true)
        }
    }

    @Test fun doesNotTreatUnknownConnectiveStemAsKnown() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜어휘고"))
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜어휘지만"))
    }

    @Test fun recognizesParticlesAfterConnectiveEndingsAndKeepsEndingSeparate() {
        val coordinated = KoreanStudyEngine.analyzeWord("가고도")
        assertEquals("가다", coordinated?.lemma)
        assertEquals("-고", coordinated?.connectiveEnding)
        assertEquals(listOf("도"), coordinated?.attachedParticles)

        val cause = KoreanStudyEngine.analyzeWord("추워서도")
        assertEquals("춥다", cause?.lemma)
        assertEquals("-아/어서", cause?.connectiveEnding)
        assertEquals(listOf("도"), cause?.attachedParticles)

        val contrast = KoreanStudyEngine.analyzeWord("먹지만은")
        assertEquals("먹다", contrast?.lemma)
        assertEquals("-지만", contrast?.connectiveEnding)
        assertEquals(listOf("은"), contrast?.attachedParticles)
    }

    @Test fun doesNotGuessUnknownStemWithParticleAfterEnding() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜어휘고도"))
    }


    @Test fun explainsConnectiveEndingsByTheirDistinctFunctions() {
        val contrast = KoreanStudyEngine.analyzeWord("먹지만")
        assertTrue(contrast?.connectiveMeaning?.contains("转折") == true)

        val cause = KoreanStudyEngine.analyzeWord("추워서")
        assertTrue(cause?.connectiveMeaning?.contains("原因") == true)
        assertTrue(cause?.connectiveMeaning?.contains("先后") == true)

        val condition = KoreanStudyEngine.analyzeWord("먹으면")
        assertTrue(condition?.connectiveMeaning?.contains("条件") == true)

        val coordination = KoreanStudyEngine.analyzeWord("가고")
        assertTrue(coordination?.connectiveMeaning?.contains("并列") == true)
    }

    @Test fun connectiveMeaningIsPreservedWhenAuxiliaryParticleFollows() {
        val info = KoreanStudyEngine.analyzeWord("추워서도")
        assertEquals("-아/어서", info?.connectiveEnding)
        assertTrue(info?.connectiveMeaning?.contains("原因") == true)
        assertEquals(listOf("도"), info?.attachedParticles)
    }

    @Test fun recognizesExplicitAdnominalForms() {
        val examples = mapOf(
            "가는" to ("가다" to "-는"), "간" to ("가다" to "-(으)ㄴ"), "갈" to ("가다" to "-(으)ㄹ"),
            "먹는" to ("먹다" to "-는"), "먹은" to ("먹다" to "-(으)ㄴ"), "먹을" to ("먹다" to "-(으)ㄹ"),
            "사랑하는" to ("사랑하다" to "-는"), "기다릴" to ("기다리다" to "-(으)ㄹ"),
            "운" to ("울다" to "-(으)ㄴ")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.adnominalEnding)
            assertEquals(null, info?.connectiveEnding)
        }
    }


    @Test fun recognizesAdditionalAdjectiveAdnominalForms() {
        val examples = mapOf(
            "슬픈" to ("슬프다" to "-(으)ㄴ（ㅡ脱落后的形容词现在冠形）"),
            "예쁜" to ("예쁘다" to "-(으)ㄴ（ㅡ脱落后的形容词现在冠形）"),
            "힘든" to ("힘들다" to "-(으)ㄴ（ㄹ脱落后的形容词现在冠形）"),
            "그리운" to ("그립다" to "-(으)ㄴ（ㅂ不规则形容词现在冠形）"),
            "슬펐던" to ("슬프다" to "-았/었던（过去状态回顾；ㅡ脱落）"),
            "예뻤던" to ("예쁘다" to "-았/었던（过去状态回顾；ㅡ脱落）"),
            "힘들었던" to ("힘들다" to "-았/었던（过去状态回顾）"),
            "그리웠던" to ("그립다" to "-았/었던（过去状态回顾；ㅂ不规则）")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.adnominalEnding)
        }
    }

    @Test fun preservesAdjectiveAnalysisAfterParticleSuffix() {
        val info = KoreanStudyEngine.analyzeWord("그리운도")
        assertEquals("그립다", info?.lemma)
        assertEquals("-(으)ㄴ（ㅂ不规则形容词现在冠形）", info?.adnominalEnding)
        assertEquals(listOf("도"), info?.attachedParticles)
    }

    @Test fun doesNotGuessUnknownAdnominalStem() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜어휘는"))
    }


    @Test fun recognizesExplicitRetrospectivePastAdnominalForms() {
        val examples = mapOf(
            "가던" to ("가다" to "-던（过去回想／持续或习惯）"),
            "갔던" to ("가다" to "-았/었던（过去经历回顾）"),
            "먹던" to ("먹다" to "-던（过去回想／持续或习惯）"),
            "먹었던" to ("먹다" to "-았/었던（过去经历回顾）"),
            "봤던" to ("보다" to "-았/었던（过去经历回顾）"),
            "사랑했던" to ("사랑하다" to "-았/었던（过去经历回顾）"),
            "기다리던" to ("기다리다" to "-던（过去回想／持续或习惯）"),
            "살았던" to ("살다" to "-았/었던（过去经历回顾）")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.adnominalEnding)
            assertEquals(null, info?.connectiveEnding)
        }
    }

    @Test fun recognizesRetrospectiveAdnominalFormWithParticle() {
        val info = KoreanStudyEngine.analyzeWord("먹었던도")
        assertEquals("먹다", info?.lemma)
        assertEquals("-았/었던（过去经历回顾）", info?.adnominalEnding)
        assertEquals(listOf("도"), info?.attachedParticles)
    }

    @Test fun doesNotGuessUnknownRetrospectiveAdnominalStem() {
        assertNull(KoreanStudyEngine.analyzeWord("生소한가짜어휘던"))
    }


    @Test fun recognizesAdditionalLexicalizedEumMyeongsaForms() {
        val examples = mapOf(
            "갈음" to ("갈다" to "替代；代替；更换"),
            "솎음" to ("솎다" to "间苗；疏剪"),
            "수줍음" to ("수줍다" to "害羞；腼腆"),
            "서러움" to ("서럽다" to "悲伤；委屈"),
            "앙갚음" to ("갚다" to "报复；回报"),
            "용솟음" to ("솟다" to "涌起；喷涌")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.meaning)
            assertEquals("名词（词汇化派生名词）", info?.partOfSpeech)
            assertEquals("-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）", info?.nominalizingEnding)
        }
    }

    @Test fun recognizesEumNominalFormsWithParticlesWithoutLosingNounMeaning() {
        val info = KoreanStudyEngine.analyzeWord("수줍음도")
        assertEquals("수줍다", info?.lemma)
        assertEquals("害羞；腼腆", info?.meaning)
        assertEquals(listOf("도"), info?.attachedParticles)
        assertEquals("-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）", info?.nominalizingEnding)
    }

    @Test fun doesNotGuessUnlistedEumNominalForms() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜명사"))
    }

    @Test fun recognizesExplicitNominalizedGiForms() {
        val examples = mapOf(
            "가기" to "가다", "먹기" to "먹다", "보기" to "보다",
            "사랑하기" to "사랑하다", "기다리기" to "기다리다",
            "걷기" to "걷다", "듣기" to "듣다", "살기" to "살다"
        )
        examples.forEach { (surface, lemma) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(lemma, info?.lemma)
            assertEquals("-기（名词化词尾）", info?.nominalizingEnding)
            assertEquals(null, info?.connectiveEnding)
        }
    }

    @Test fun recognizesNominalizedGiWithAuxiliaryParticle() {
        val info = KoreanStudyEngine.analyzeWord("사랑하기도")
        assertEquals("사랑하다", info?.lemma)
        assertEquals("-기（名词化词尾）", info?.nominalizingEnding)
        assertEquals(listOf("도"), info?.attachedParticles)
    }

    @Test fun doesNotGuessUnknownNominalizedStem() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜어휘기"))
    }

    @Test fun recognizesAdjectiveAttributiveFormsAndExistenceForms() {
        val examples = mapOf(
            "좋은" to ("좋다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "아픈" to ("아프다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "추운" to ("춥다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "더운" to ("덥다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "쉬운" to ("쉽다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "어려운" to ("어렵다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "다른" to ("다르다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "빠른" to ("빠르다" to "-(으)ㄴ（形容词现在冠形词尾）"),
            "있는" to ("있다" to "-는（存在状态冠形词尾）"),
            "없는" to ("없다" to "-는（存在状态冠形词尾）")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.adnominalEnding)
        }
    }

    @Test fun recognizesAdjectiveRetrospectiveFormsAndParticles() {
        val info = KoreanStudyEngine.analyzeWord("추웠던도")
        assertEquals("춥다", info?.lemma)
        assertEquals("-았/었던（过去状态回顾）", info?.adnominalEnding)
        assertEquals(listOf("도"), info?.attachedParticles)
        assertEquals("좋다", KoreanStudyEngine.analyzeWord("좋았던")?.lemma)
        assertEquals("어렵다", KoreanStudyEngine.analyzeWord("어려웠던")?.lemma)
    }

    @Test fun keepsUnknownAdjectiveAttributiveFormsUnknown() {
        assertNull(KoreanStudyEngine.analyzeWord("낯선가짜형용사인"))
    }

    @Test fun detectsCommonGrammarPatterns() {
        val patterns = KoreanStudyEngine.analyzeSentence("한국에 가고 싶어요").map { it.pattern }
        assertTrue(patterns.contains("-고 싶다"))
    }
    @Test fun recognizesExplicitEumNominalizedFormsAndTheirNounMeanings() {
        val examples = mapOf(
            "웃음" to ("웃다" to "笑声；笑容"),
            "울음" to ("울다" to "哭泣；哭声"),
            "믿음" to ("믿다" to "信任；信念"),
            "걸음" to ("걷다" to "步伐；步行"),
            "앎" to ("알다" to "知晓；认识")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.meaning)
            assertEquals("名词（词汇化派生名词）", info?.partOfSpeech)
            assertEquals("-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）", info?.nominalizingEnding)
        }
    }

    @Test fun recognizesEumNominalizedFormsWithParticles() {
        val info = KoreanStudyEngine.analyzeWord("웃음도")
        assertEquals("웃다", info?.lemma)
        assertEquals("笑声；笑容", info?.meaning)
        assertEquals(listOf("도"), info?.attachedParticles)
        assertEquals("-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）", info?.nominalizingEnding)
    }


    @Test fun recognizesAdditionalLexicalizedEumNominals() {
        val examples = mapOf(
            "삶" to ("살다" to "生活；人生"),
            "죽음" to ("죽다" to "死亡；逝世"),
            "얼음" to ("얼다" to "冰；冰块"),
            "졸음" to ("졸다" to "困意；睡意"),
            "묶음" to ("묶다" to "捆；束；一组"),
            "엮음" to ("엮다" to "编织；编排")
        )
        examples.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.meaning)
            assertEquals("名词（词汇化派生名词）", info?.partOfSpeech)
        }
    }

    @Test fun recognizesAdditionalEumNominalsWithParticles() {
        val cases = mapOf(
            "삶도" to ("살다" to listOf("도")),
            "죽음이" to ("죽다" to listOf("이")),
            "얼음은" to ("얼다" to listOf("은")),
            "졸음도" to ("졸다" to listOf("도")),
            "묶음으로" to ("묶다" to listOf("으로"))
        )
        cases.forEach { (surface, expected) ->
            val info = KoreanStudyEngine.analyzeWord(surface)
            assertEquals(expected.first, info?.lemma)
            assertEquals(expected.second, info?.attachedParticles)
            assertTrue(info?.nominalizingEnding != null)
        }
    }

    @Test fun keepsUnsupportedEumNominalizedFormsUnknown() {
        assertNull(KoreanStudyEngine.analyzeWord("생소한가짜명사음"))
    }

    @Test fun distinguishesLexicalizedEumNounsFromProductiveGiNominalization() {
        val lexicalNoun = KoreanStudyEngine.analyzeWord("믿음")
        assertEquals("-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）", lexicalNoun?.nominalizingEnding)
        assertTrue(lexicalNoun?.explanation?.contains("已词汇化") == true)
        assertTrue(lexicalNoun?.explanation?.contains("独立含义") == true)

        val productiveNominalization = KoreanStudyEngine.analyzeWord("먹기")
        assertEquals("-기（名词化词尾）", productiveNominalization?.nominalizingEnding)
        assertEquals("吃", productiveNominalization?.meaning)
    }

    @Test fun keepsLexicalizedEumNounExplanationWhenParticleFollows() {
        val info = KoreanStudyEngine.analyzeWord("앙갚음도")
        assertEquals("-(으)ㅁ/ㅁ（名词派生后缀；词汇化名词）", info?.nominalizingEnding)
        assertTrue(info?.explanation?.contains("已词汇化") == true)
        assertEquals(listOf("도"), info?.attachedParticles)
    }


    @Test fun lexicalizedEumNounsAreLabeledAsDerivedNounsAndExamplesUseTheNoun() {
        val info = KoreanStudyEngine.analyzeWord("엮음")
        assertEquals("名词（词汇化派生名词）", info?.partOfSpeech)
        assertTrue(info?.example?.contains("엮음") == true)
        assertTrue(info?.example?.contains("완성됐어요") == true)
    }

    @Test fun dictionaryDataHasConsistentReferencesAndLearnerFields() {
        assertTrue(KoreanStudyEngine.validateDictionaryData().joinToString("\n"),
            KoreanStudyEngine.validateDictionaryData().isEmpty())
    }


}
