package com.example.klyrics

import org.junit.Assert.assertThrows
import org.junit.Test

class AiStudyClientTest {
    @Test fun rejectsInsecureBackendUrl() {
        assertThrows(IllegalArgumentException::class.java) {
            AiStudyClient.request("http://example.invalid", "token", "analyze", "안녕하세요")
        }
    }

    @Test fun rejectsUnsupportedTaskAndOversizedInputBeforeNetworkAccess() {
        assertThrows(IllegalArgumentException::class.java) {
            AiStudyClient.request("https://example.invalid", "token", "unknown", "안녕하세요")
        }
        assertThrows(IllegalArgumentException::class.java) {
            AiStudyClient.request("https://example.invalid", "token", "analyze", "가".repeat(2_001))
        }
    }
}
