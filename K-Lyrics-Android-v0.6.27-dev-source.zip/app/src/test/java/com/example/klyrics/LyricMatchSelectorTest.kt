package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricMatchSelectorTest {
    @Test fun prefersValidSyncedLyrics() {
        val match = LyricMatchSelector.select(
            "밤편지", "아이유", 240_000L,
            listOf(LyricMatchSelector.Candidate(
                "밤편지", "아이유", 240.0,
                "[00:01.00]안녕", "안녕"
            ))
        )
        assertNotNull(match)
        assertTrue(match!!.hasTimestamps)
        assertEquals("[00:01.00]안녕", match.lyrics)
    }

    @Test fun fallsBackToPlainLyricsWhenSyncedPayloadIsMalformed() {
        val match = LyricMatchSelector.select(
            "밤편지", "아이유", null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", 0.0, "[broken]", "안녕\n잘 지내"))
        )
        assertNotNull(match)
        assertEquals(false, match!!.hasTimestamps)
        assertEquals("안녕\n잘 지내", match.lyrics)
    }

    @Test fun rejectsWrongArtistAndDuration() {
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", 240_000L,
            listOf(LyricMatchSelector.Candidate("밤편지", "다른 가수", 300.0, "[00:01.00]안녕", null))
        ))
    }

    @Test fun ignoresOversizedMetadataAndLyrics() {
        val oversized = "가".repeat(257)
        val hugeLyrics = "가".repeat(300_001)
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", null,
            listOf(
                LyricMatchSelector.Candidate(oversized, "아이유", 0.0, null, "안녕"),
                LyricMatchSelector.Candidate("밤편지", "아이유", 0.0, null, hugeLyrics)
            )
        ))
    }
    @Test fun rejectsOversizedRequestedMetadataBeforeScoring() {
        val oversizedTitle = "가".repeat(257)
        assertNull(LyricMatchSelector.select(
            oversizedTitle, "아이유", null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", 0.0, "[00:01.00]안녕", null))
        ))
        assertNull(LyricMatchSelector.select(
            "밤편지", "가".repeat(257), null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", 0.0, "[00:01.00]안녕", null))
        ))
    }

    @Test fun rejectsImpossibleRequestedAndCandidateDurations() {
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", 24L * 60L * 60L * 1_000L + 1L,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", 0.0, "[00:01.00]안녕", null))
        ))
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", -1.0, "[00:01.00]안녕", null))
        ))
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", 86_401.0, "[00:01.00]안녕", null))
        ))
    }

    @Test fun ignoresNonFiniteCandidateDuration() {
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", Double.NaN, "[00:01.00]안녕", null))
        ))
        assertNull(LyricMatchSelector.select(
            "밤편지", "아이유", null,
            listOf(LyricMatchSelector.Candidate("밤편지", "아이유", Double.POSITIVE_INFINITY, "[00:01.00]안녕", null))
        ))
    }

}
