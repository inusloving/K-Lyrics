package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Test

class LyricCachePolicyTest {
    @Test fun refreshesAccessTimeOnlyAfterThrottleInterval() {
        assertEquals(true, LyricCachePolicy.shouldRefreshAccessTime(0L, 10_000L, 300_000L))
        assertEquals(false, LyricCachePolicy.shouldRefreshAccessTime(100_000L, 200_000L, 300_000L))
        assertEquals(true, LyricCachePolicy.shouldRefreshAccessTime(100_000L, 400_000L, 300_000L))
        // A wall-clock rollback must not make an entry look newer or trigger repeated writes.
        assertEquals(false, LyricCachePolicy.shouldRefreshAccessTime(400_000L, 300_000L, 300_000L))
    }

    @Test fun evictsLeastRecentlyUsedUntilTrackLimitIsMet() {
        val entries = listOf(
            LyricCachePolicy.Entry("old", 1L, 100),
            LyricCachePolicy.Entry("middle", 2L, 100),
            LyricCachePolicy.Entry("new", 3L, 100)
        )
        assertEquals(setOf("old"), LyricCachePolicy.evictionIds(entries, 2, 1_000))
    }

    @Test fun evictsByStorageBudgetAndProtectsJustWrittenTrack() {
        val entries = listOf(
            LyricCachePolicy.Entry("old", 1L, 700),
            LyricCachePolicy.Entry("recent", 2L, 500),
            LyricCachePolicy.Entry("current", 3L, 400)
        )
        assertEquals(setOf("old", "recent"), LyricCachePolicy.evictionIds(entries, 10, 500, "current"))
    }

    @Test fun doesNotEvictProtectedOnlyEntry() {
        val entries = listOf(LyricCachePolicy.Entry("current", 1L, 900))
        assertEquals(emptySet<String>(), LyricCachePolicy.evictionIds(entries, 1, 100, "current"))
    }
}
