package com.example.klyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricEngineTest {
    @Test fun parsesCentisecondsAndMultipleTimestamps() {
        val lines = LrcParser.parse("[00:01.2][00:02.34]안녕하세요")
        assertEquals(listOf(1_200L, 2_340L), lines.map { it.timeMs })
        assertTrue(lines.all { it.text == "안녕하세요" })
    }

    @Test fun appliesLrcOffsetAndClampsNegativeTimes() {
        val lines = LrcParser.parse("[offset:-750]\n[00:00.50]first\n[00:02.00]second")
        assertEquals(listOf(0L, 1_250L), lines.map { it.timeMs })
    }

    @Test fun ignoresInvalidSecondsAndMetadataOnlyLines() {
        val lines = LrcParser.parse("[00:75.00]bad\n[ar:artist]\n[00:03.00]good")
        assertEquals(1, lines.size)
        assertEquals("good", lines.single().text)
    }

    @Test fun choosesLatestTimedLineAndSkipsUntimedLines() {
        val lines = listOf(
            LyricLine(1_000L, "one"),
            LyricLine(-1L, "not calibrated"),
            LyricLine(2_000L, "two")
        )
        assertEquals(0, currentLyricIndex(lines, 1_500L))
        assertEquals(2, currentLyricIndex(lines, 2_500L))
        assertEquals(-1, currentLyricIndex(lines, 500L))
    }

    @Test fun calibrationPreservesOriginalLineOrder() {
        val lines = listOf(LyricLine(-1L, "first"), LyricLine(-1L, "second"))
        val result = calibrateLine(lines, 1, 4_200L)
        assertEquals(listOf("first", "second"), result.map { it.text })
        assertEquals(4_200L, result[1].timeMs)
    }

    @Test fun trackKeyNormalizesCaseAndWhitespace() {
        assertEquals(trackKey(" Song  Name ", "Artist"), trackKey("song name", "artist"))
    }
}
