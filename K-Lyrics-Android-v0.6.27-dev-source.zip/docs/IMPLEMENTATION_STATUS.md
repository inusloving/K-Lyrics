# Implementation status — 0.6.27-dev

| Area | Status in this source snapshot |
|---|---|
| Kugou media-session metadata | Implemented; session disappearance clears stale track metadata |
| Playback position | Uses MediaSession position plus elapsed realtime while playing; static full lyrics when unavailable, with a local elapsed-time fallback for manual calibration (requires playback detected from the start for best accuracy) |
| LRC parsing | Implemented; multiple timestamps and millisecond fractions |
| Plain-text lyric import | Implemented; lines initially remain untimed |
| Manual line calibration | Implemented in sequence using MediaSession position or a monotonic local elapsed-time fallback |
| Online lyric lookup | Manual search plus opt-in auto lookup on track changes; LRCLIB synced lyrics preferred, plain-text fallback; conservative title/artist/duration matching isolated in a tested selector; malformed synced-LRC falls back to valid plain lyrics; considers at most 100 candidates and rejects oversized metadata/lyric fields; response body capped at 1,000,000 characters and rejected rather than truncated; obsolete queued lookups are cancelled on track changes |
| Local lyric cache | Implemented with track-keyed SharedPreferences; LRU eviction bounds it to 80 tracks / 8,000,000 stored characters, preserving the just-updated track |
| Line translations | UTF-8 text import, line-index association, local cache |
| Floating overlay | Current Korean line and optional Chinese translation; title-bar drag position is persisted |
| Offline word lookup | Expanded curated dictionary (70+ lemmas), explicit conjugation mappings (including selected -고, -지만, -아/어서, -(으)면, attributive -(으)ㄴ/-는/-(으)ㄹ forms, and explicit retrospective past -던/-았던 forms), and conservative noun plural-marker parsing (들 before a recognized case/topic particle); common lyric vocabulary and selected ㄷ/르/ㅂ/ㅅ irregular forms included; unknown words are not guessed; device Korean TTS button |
| Sentence learning | Fixed-pattern grammar hints with simple/detailed views; not full syntactic analysis |
| Appearance | Font size, background opacity and color presets |
| AI translation / AI grammar analysis | On-demand sentence analysis, per-line and batch translation client + reference Node backend implemented; task-specific results are shown separately from cache, cached requests are served locally without another network call, and per-line translations are persisted; hosting, provider credential and live integration not verified |
| Backend request hardening | JSON content-type and byte-size validation, bounded per-IP rate-limit buckets, socket timeouts, and malformed-body handling; Node integration tests cover these paths |
| Full Korean morphology / IPA / bundled pronunciation audio | Not implemented; Korean TTS uses the device voice engine |
| Kugou KRC decoding | Not implemented |
| Portable `.kllyrics` backup/restore | Implemented with versioned, validated UTF-8-safe line format |
| AI access-token storage | Access token is encrypted with AES-256-GCM using a non-exportable Android Keystore key; legacy plaintext preference is migrated on read; encryption failures fail closed and never fall back to plaintext. Android runtime validation pending. |
| AI cache behavior | Startup shows cached analysis and translation in separate labeled sections; repeated requests use the task-specific local cache first |
| Batch translation integrity | Added strict parser: exact line count, sequential numbering validation, mixed-format rejection, and extra-commentary rejection before saving translations |
| Network response bounds | LRCLIB response reader rejects oversized payloads instead of loading unbounded JSON into memory; pure Kotlin boundary tests pass |
| Track-change lookup queue | Cancels an obsolete queued lyric lookup when a newer track is detected; an already-running HTTP request may continue until its configured timeout, but stale results are never published over the active track |
| Xiaomi Android 16 device validation | Not performed |

## 0.6.12-dev changes

- Added explicit dictionary-backed adnominal forms for selected high-frequency verbs (e.g. 가는/간/갈, 먹는/먹은/먹을, 사랑하는, 기다릴, 우는/운/울).
- Word detail now labels recognized adnominal endings separately from connective endings; the UI explains that these forms modify following nouns.
- Unknown adnominal-looking forms remain unresolved unless their exact surface form is in the curated mapping.
- Added unit coverage for representative present, past, and prospective adnominal forms and unknown-word protection.

## v0.6.27-dev — Android CI build handoff

- CI now pins the Android build to JDK 17 and Gradle 8.13 for the configured Android Gradle Plugin 8.13.2.
- Android unit tests and debug APK assembly use explicit `:app:` task paths.
- CI verifies the APK output, generates a SHA-256 checksum, and uploads both as a 14-day artifact.
- The workflow has not been executed from this local environment. A successful GitHub Actions run is still required before claiming a full Android build.

## Verification boundary

The current environment has Java and `kotlinc`, but no Gradle executable, Android SDK, or Android Gradle Plugin cache. The Node backend integration suite currently passes 12 tests. The bounded network-response reader and lyric-match selector pass independent Kotlin boundary smoke tests; its JUnit tests are included in the Android test source set. The pure Kotlin lyric-engine tests can be compiled/run independently; the Android application build and device behavior must be verified by CI and on a physical device. A successful APK build is not equivalent to validating notification access, floating-window behavior, playback synchronization, or online provider matching on Xiaomi Android 16.


## v0.6.4-dev change

- Offline lookup now recognizes the Korean plural marker 들 before supported particles (e.g. 사람들이, 사람들은, 사람들을) when the remaining lemma exists in the curated dictionary.
- Detailed learning view identifies 들 and the attached particle separately.
- Added regression coverage for subject/topic/object forms and unknown-word rejection.
- Independent Kotlin morphology smoke test passes. Full Android build and device validation remain pending.

## v0.4.6-dev change

- Extracted LRCLIB candidate scoring into a pure Kotlin selector with strict title/artist/duration thresholds and bounded candidate/field sizes.
- Invalid synchronized-LRC payloads no longer discard a valid plain-text lyric fallback.
- Added unit tests for synchronized preference, malformed-LRC fallback, wrong-artist/duration rejection, and oversized metadata/lyrics.
- Pure Kotlin selector smoke tests pass. The Android/JUnit suite remains pending a Gradle/Android SDK build.


## v0.4.7-dev change

- Backend now authenticates the app access token before applying per-IP rate limits or revealing service-configuration state. Invalid credentials cannot exhaust the authenticated client's quota. Added regression tests for invalid-token isolation and authenticated rate limiting.


## v0.4.8-dev change

- AI backend access tokens are now encrypted at rest with an Android Keystore AES-256-GCM key instead of being stored as plaintext SharedPreferences values.
- Existing plaintext tokens are migrated on first read; undecryptable values are discarded rather than treated as credentials.
- Saving configuration fails closed if encryption cannot be completed.
- Android Keystore behavior requires Android runtime/device validation; full Android build remains pending.


## v0.4.9-dev change

- Added strict character limits when importing user-selected LRC/TXT lyrics, line translations, and `.kllyrics` backups through Android's Storage Access Framework.
- Oversized documents are rejected instead of being fully loaded into memory; BOM handling remains supported. Limits are 1,000,000 characters for text/translation imports and 5,000,000 for backups, matching the backup codec's maximum input size.
- Backend integration tests: 10/10 pass. Android SDK/Gradle build and SAF device interaction remain unverified in this environment.


## v0.5.0-dev change

- The Node backend now streams and bounds the model-provider response body to 1,000,000 bytes before JSON parsing. Both declared oversized content-length and chunked/undeclared oversized bodies are rejected with a generic 502 response; the client receives no provider payload or internal parser details.
- Added a configurable `OPENAI_API_URL` environment override for controlled integration testing and compatible trusted deployments; the default remains the official Responses API endpoint. Production deployments should use HTTPS and a trusted host.
- Added integration tests using a local mock provider for oversized and valid upstream responses. Backend suite: 12/12 pass. Full Android build and physical-device verification remain pending.


## v0.5.1-dev change

- Fixed the playback fallback clock's use of `0` as a stopped-clock sentinel. Android's monotonic clock may validly report zero in tests or at process start, so playback now advances correctly from that origin.
- Backward clock readings cannot subtract elapsed playback time, and accumulated position uses saturating addition to avoid `Long` overflow.
- Added regression tests for zero-origin playback, backward readings, and overflow. Pure Kotlin smoke tests pass; Android Gradle build and device validation remain pending.


## v0.5.2-dev change

- Hardened the local lyric cache boundary: raw lyrics are capped at 1,000,000 characters; structured lyric caches at 10,000 lines / 2,000 characters per line; translation rows at 4,000 characters each.
- Invalid or oversized structured cache entries are rejected on load; corrupt calibration timestamps fall back to the source timestamp instead of poisoning synchronization.
- Cache writes now validate metadata, line counts, text lengths, and timestamp sentinels before persisting to SharedPreferences.
- Backend integration suite remains 12/12 passing. Android build/device validation remains pending because this environment has no Android SDK/Gradle installation.


## v0.5.3-dev change

- Added deterministic least-recently-used eviction for the local lyric cache. It is bounded to 80 tracks and approximately 8,000,000 stored characters across lyrics, translations, and calibration data.
- The just-saved or just-updated track is protected during eviction; associated translation, calibration, and timestamp records are removed together when a track is evicted.
- Added pure Kotlin policy tests for track-count eviction, storage-budget eviction, and current-track protection. Android SharedPreferences integration and the full Android build remain pending runtime/CI validation.


### v0.5.4-dev — cache access recency
- Corrected LRU semantics: successful lyric reads now refresh the cache access timestamp, rather than treating write time as last use.
- Access timestamp writes are throttled to once per five minutes per track to avoid SharedPreferences write churn during the overlay's periodic refresh.
- Added deterministic policy tests for first access, throttle interval, and wall-clock rollback.
- Verification boundary: pure Kotlin policy checks are independent of Android runtime; full Android build and device behavior still require CI/device validation.


### v0.5.5-dev — separate cache recency from content revision
- Split the cache's last-access timestamp from its content revision timestamp. Reading lyrics now updates only `accessed:<track>`, while `revision()` remains stable until lyric/translation/calibration content changes.
- This prevents the overlay from treating a routine LRU touch as a content edit and unnecessarily reloading lyric rows every five minutes.
- LRU eviction uses access time, with write time as a backward-compatible fallback for existing cache entries. Eviction removes both metadata keys.
- Verification: pure Kotlin cache policy tests and backend integration tests are run independently; Android SharedPreferences integration and full APK build still require Android CI/device validation.


### v0.5.6-dev — lyric-match input bounds
- Lyric candidate selection now rejects requested title/artist metadata over 256 characters before normalization and edit-distance scoring, bounding both sides of the comparison.
- Candidate duration metadata must be finite; malformed NaN/infinite values are ignored instead of entering duration scoring.
- Added regression tests for oversized requested metadata and non-finite candidate durations.
- Verification remains limited to pure Kotlin checks and backend tests; Android Gradle build/device validation is pending.


### v0.5.7-dev — lyric lookup metadata validation
- LRCLIB lookup now rejects blank/oversized metadata, control characters, and impossible track durations before URL encoding or network access.
- Automatic HTTP redirects are disabled for the fixed public lyric endpoint, preventing unexpected redirect destinations from being followed.
- Candidate scoring rejects negative, non-finite, and greater-than-24-hour duration metadata; requested durations are subject to the same bound.
- Added regression coverage for impossible requested and provider durations. Pure Kotlin and backend test verification follows; Android SDK build/device validation remains pending.


### v0.5.8-dev — playback position estimation
- Extracted MediaSession position extrapolation into a pure Kotlin utility. It rejects NaN/infinite/negative playback speeds and non-advancing monotonic timestamps.
- Position arithmetic saturates at `Long.MAX_VALUE` rather than overflowing, and negative base positions normalize to zero.
- Added regression tests for normal playback, variable speed, invalid speed, paused playback, clock edge cases, and overflow.
- Full Android build and physical-device validation remain pending.


## v0.5.9-dev change

- Closed an overflow edge case in `PlaybackClock`: the pause transition now uses the same saturating addition as live position estimates, so a near-maximum position cannot wrap negative when playback is paused.
- Added a regression test covering pause and resume after saturation.
- Full Android build and physical-device validation remain pending.

### v0.6.2-dev — Android plugin compatibility correction
- Updated Android Gradle Plugin from 8.13.0 to 8.13.2 while retaining Kotlin Gradle Plugin 2.3.0 and Gradle 8.13.
- AGP 8.13.2 release notes explicitly identify Kotlin 2.3 support; AGP 8.13.0 did not carry that stated R8 support. This removes an avoidable toolchain mismatch before CI validation.
- CI continues to use JDK 17, Android API 36, Gradle 8.13, backend tests, Android unit tests, and debug APK assembly.
- Android build execution and device validation remain pending a successful CI run and physical-device test.


### v0.6.3-dev — tap-to-study vocabulary shortcuts
- Added a bounded Hangul tokenizer for lyric lines. It extracts unique Korean tokens in reading order and caps the result to avoid oversized learning screens.
- Sentence learning now offers one-tap word-study shortcuts while preserving the original sentence, track metadata, and lyric line index.
- Added unit tests for token ordering, deduplication, punctuation/Latin filtering, empty input, and the token cap.
- Android CI and physical-device validation remain pending.


## v0.6.6-dev change

- Offline lookup now recognizes supported stacked particle sequences such as 에게+도 and 에서+만, including a plural marker before the particle chain when the remaining lemma exists in the curated dictionary.
- Detailed learning view displays the particle sequence in grammatical order; existing single-particle compatibility is retained.
- Added regression tests for stacked particles, plural-plus-stacked particles, and unknown-word rejection. Full Android build and device validation remain pending.


## v0.6.8-dev change

- Added exact dictionary-backed recognition for selected connective forms (-고, -지만, -아/어서, -(으)면, and -으며) and displays the connective ending separately from particles.
- Added tests for common known stems and unknown-stem rejection. This remains a curated list, not productive morphological parsing.
- Android build and physical-device validation remain pending.


### v0.6.9-dev — connective endings with auxiliary particles

- Lookup now recognizes supported connective forms followed by auxiliary particles, for example 가고도, 추워서도, and 먹지만은.
- The learning result keeps the dictionary lemma, connective ending, and attached particle as separate fields.
- Unknown stems remain unresolved; regression tests cover -고, -아/어서, and -지만 combinations.


### v0.6.10-dev — connective-ending explanations
- Detailed lookup now distinguishes the grammatical functions of supported connective endings instead of showing one generic explanation for all endings.
- The explanation is retained for forms followed by auxiliary particles.
- Added regression tests for contrast, cause/sequence, condition, coordination, and particle combinations. Android build and device validation remain pending.


## 0.6.12-dev changes

- Added explicit dictionary-backed retrospective past adnominal forms (-던 and -았/었던) for selected common lyric verbs.
- Distinguishes a recalled ongoing/habitual past scene from a more clearly completed past experience in the learning explanation.
- Added tests for exact forms, particle attachment, and unknown-word protection.
- This remains a curated lookup table, not a general Korean morphological analyzer.


## 0.6.14-dev changes

- Expanded exact dictionary-backed adnominal recognition to common adjective forms, including 좋다, 아프다, 춥다, 덥다, 쉽다, 어렵다, 다르다, 빠르다, 낫다, 있다, and 없다.
- Added selected past-state retrospective forms (-았/었던) for adjectives, with auxiliary-particle recognition (for example 추웠던도).
- Added the dictionary entry and common conjugations for 좋다.
- Added regression coverage for present/future adjective adnominals, retrospective past forms, particle attachment, and unknown-word rejection.
- This remains a curated exact-form lookup, not productive morphological analysis. Full Android build and physical-device validation remain pending.


## 0.6.15-dev changes

- Added exact, dictionary-backed `-(으)ㅁ/-ㅁ` nominalized forms for 웃음, 울음, 믿음, 걸음, and 앎.
- Nominalized forms display noun-specific glosses and examples instead of incorrectly showing only the source verb gloss.
- Particle attachment remains supported after recognized nominalized forms (for example, 웃음도).
- Unknown forms remain unresolved; no productive suffix guessing was introduced.
- Added unit coverage for five forms, noun glosses, particle attachment, and unknown-form protection.
- Full Android build and physical-device validation remain pending.


## 0.6.16-dev changes

- Added four high-frequency adjective dictionary entries: 슬프다, 예쁘다, 힘들다, and 그립다.
- Added exact present-state adnominal forms (슬픈, 예쁜, 힘든, 그리운) and selected retrospective past forms (슬펐던, 예뻤던, 힘들었던, 그리웠던).
- Explanations identify ㅡ deletion, ㄹ deletion, and ㅂ irregular conjugation where applicable.
- Added regression tests for all eight forms and particle attachment after an adnominal form.
- Forms remain explicit and dictionary-backed; unknown forms are not guessed. Full Android build and physical-device validation remain pending.


## v0.6.17-dev — expanded lexicalized -음/-ㅁ nouns

- Added explicit entries for 삶, 죽음, 얼음, 졸음, 묶음, and 엮음, each mapped to a known source lemma with a noun-specific Chinese gloss and Korean example.
- Added corresponding source lemmas to the curated dictionary; no productive suffix guessing was introduced.
- Existing attached-particle parsing applies to these exact nominal entries (e.g. 삶도, 죽음이, 얼음은, 묶음으로).
- Added unit coverage for noun meanings and particle combinations.
- Korean orthography reference distinguishes established -음/-ㅁ derived nouns and lists examples including 걸음, 믿음, 울음, 웃음, 죽음, 앎, 삶, and 묶음.


## v0.6.18-dev — expanded lexicalized -음/-ㅁ nouns

- Added six exact lexicalized nominal entries (갈음, 솎음, 수줍음, 서러움, 앙갚음, 용솟음) with noun-specific meanings and examples.
- Added their source lemmas to the curated dictionary.
- Unit tests cover noun glosses, -도 attachment, and unknown-word rejection.


## 0.6.19-dev — distinguish lexicalized -음/-ㅁ nouns

- Corrected the grammar label for curated lexicalized -음/-ㅁ nouns: these are identified as derivational suffix formations and lexicalized nouns, not presented as the productive sentence nominalizing ending.
- Updated the learner explanation to prioritize the established noun meaning instead of mechanically applying the source verb/adjective gloss.
- Kept productive -기 nominalization distinct and unchanged.
- Added regression tests for the distinction and for particle attachment after a lexicalized noun.
- Reference: Korean orthography rule 19 distinguishes established -음/-ㅁ derived nouns and gives examples including 걸음, 묶음, 믿음, 얼음, 엮음, 울음, 웃음, 졸음, 죽음, 앎, 삶, 갈음, 솎음, 수줍음, 서러움, 앙갚음, and 용솟음.
- Full Android build and physical-device validation remain pending.


## 0.6.20-dev — offline dictionary consistency audit

- Added an internal dictionary-data audit covering lemma references from inflection, connective, adnominal, and nominalization maps; it also checks required part-of-speech, meaning, explanation, and Korean example fields.
- Added a regression test requiring the curated offline dataset to pass the audit. This catches structural omissions and broken references, but does not claim automatic semantic validation of translations or grammar.
- Kept conservative exact-form recognition and unknown-word behavior unchanged.
- Full Android build and Xiaomi Android 16 device validation remain pending.


## 0.6.21-dev change

- Clarified the learner-facing POS label for curated lexicalized -음/-ㅁ forms as “词汇化派生名词”, distinguishing lexical derivation from productive sentence nominalization.
- Rewrote the 엮음 example to use the noun in a grammatical sentence.
- Extended the dictionary audit to ensure each lexicalized-noun example includes its target surface form; added regression coverage.
- This is a data-quality guard, not an automatic semantic/grammatical proofreader.

## 0.6.22-dev changes

- Corrected detailed word-study labeling for lexicalized `-(으)ㅁ/-ㅁ` nouns: the UI now calls these a derivational suffix / lexicalized noun rather than describing them as a productive sentence nominalization.
- Kept productive `-기` forms labeled as nominalizing endings, with the explanation that they create a noun-like expression.
- This is a presentation/linguistic-clarity correction; dictionary mappings and conservative unknown-word behavior are unchanged.



## 0.6.23-dev — preserve sentence context during word study

- Word-study screens now retain and display the track title/artist and lyric line number when supplied by the sentence-study entry point.
- When a sentence contains multiple recognized Korean tokens, the word-study screen offers direct switches to the other tokens from the same sentence without losing the original lyric context.
- The selected word remains separately identified; pronunciation continues to target only that word.
- This is a UI source change. Android compilation, navigation behavior, and Xiaomi Android 16 runtime behavior still require CI/device verification.


## 0.6.24-dev — stable word-switch navigation

- Switching between words extracted from the same lyric sentence now replaces the active word-study activity after launching the next one. The sentence-study page remains the single Back destination instead of accumulating one activity per word switch.
- Same-sentence switching continues to carry the track title, artist, lyric sentence, and line index. Cached AI sentence translation/analysis remains associated with the original sentence and is reloaded on the word page.
- Android activity-stack behavior is based on the platform's documented push/pop model; runtime navigation still requires device verification.


## 0.6.25-dev — sentence translation context

- Added a dedicated sentence-translation area directly below the original lyric sentence. It is populated from the existing sentence-keyed `AiStudyCache`, so word-study screens display the same translation as their source sentence.
- AI translation loading, success, and failure messages now update the dedicated translation area; grammar-analysis output remains in the AI result area.
- Translation remains sentence-scoped rather than being presented as a standalone word gloss. The offline dictionary continues to provide per-word lexical information separately.
- Full Android Gradle build and runtime verification remain pending.


## 0.6.26-dev — selected-word/source-sentence association

- Word-study view now renders the original lyric sentence with a visual highlight on each exact occurrence of the selected token.
- Uses a `SpannableString` with background, foreground, and bold spans, backed by a pure Kotlin range finder; does not mutate source text or alter token extraction, dictionary analysis, translation caching, or TTS behavior.
- Added unit coverage for repeated exact matches, absent tokens, blank tokens, and overlapping-match behavior.
- If no exact occurrence is found, the original sentence is shown unchanged.
- Full Android Gradle build and physical-device verification remain pending.
