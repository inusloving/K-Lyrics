# Physical-device validation checklist

Do not mark these items as passed until they are tested on a physical Xiaomi device running Android 16.

- [ ] Notification-listener access can be granted and revoked without stale track metadata remaining.
- [ ] Kugou title, artist, play/pause state, and playback position update correctly across pause/resume and track changes.
- [ ] The floating overlay starts from the app, remains visible after leaving the app, and stops cleanly from the app.
- [ ] The foreground-service notification is visible and its tap returns to K-Lyrics.
- [ ] LRC parsing and current-line synchronization match the player timeline, including files with `[offset:]` metadata.
- [ ] If media position is unavailable, the full lyric list is scrollable and tapping a word/sentence opens learning.
- [ ] Plain-text lyrics can be calibrated line by line; exact MediaSession timing and local elapsed-time fallback are distinguished.
- [ ] Manual lyric search and opt-in automatic lookup both cache the correct track; wrong artist/title matches are rejected.
- [ ] Imported translations remain aligned; mismatched line counts are clearly reported.
- [ ] `.kllyrics` export/import preserves Korean, Chinese, timing, and untimed lines.
- [ ] Word taps, sentence taps, simple/detailed mode, Korean TTS, and appearance settings work while the overlay is active.
- [ ] AI endpoint authentication, per-line translation, batch translation, sentence analysis, local caching, and offline reopening work against a deployed HTTPS backend.
- [ ] Battery optimization / autostart settings do not unexpectedly terminate the overlay or media listener.
