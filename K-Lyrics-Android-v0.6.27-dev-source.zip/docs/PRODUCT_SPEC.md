# K-Lyrics product specification

## Confirmed product decisions
- Primary view: Korean lyrics with Chinese translation beneath each line.
- Floating overlay stays compact during playback; tap a word for vocabulary help or a sentence for grammar analysis.
- Learning detail can switch between simple and detailed modes.
- Appearance controls include Korean/Chinese colors, active-line color, background color/opacity, font size, and saved drag position.
- Prefer local cache; online lookup/AI are optional. Provider API credentials remain on a server and are never embedded in the APK.

## Implemented in source snapshot 0.4.0-dev
- Kugou media-session detection, title/artist/status, estimated playback position, and a monotonic local fallback clock.
- LRC parsing (multiple timestamps, fractional seconds, offset tags), TXT import, static full-lyrics fallback, and sequential manual calibration.
- LRCLIB manual lookup plus opt-in automatic lookup on track changes; conservative title/artist matching; synced lyrics preferred, plain-text fallback.
- Line-by-line Chinese text import and on-demand AI translation of a selected line through an optional HTTPS backend.
- Floating bilingual overlay, word/sentence click entry points, curated offline dictionary, fixed-pattern grammar hints, and device Korean TTS.
- Versioned `.kllyrics` export/import containing line text, translations, and timestamps.

## Remaining product work
- The offline vocabulary is a small curated dictionary, not full Korean morphological analysis. IPA, morpheme segmentation, honorific/pragmatic nuance, and complete syntax trees need a proper Korean NLP engine.
- AI backend source exists, but it is not hosted or configured. Live AI use requires a trusted operator to deploy the backend over HTTPS and configure server-side credentials.
- Full-song batch translation, vocabulary/grammar favorites, spaced-repetition review, and a persistent learning database are not implemented.
- Kugou private KRC decoding is not implemented. The app uses LRCLIB, imported LRC/TXT, or user-created timing data.
- Xiaomi Android 16 real-device validation and a complete Android APK build remain required before release.

## Data and privacy
- Lyric cache is keyed by normalized title + artist and stored locally in SharedPreferences.
- LRCLIB requests transmit track title and artist; automatic lookup is opt-in and off by default.
- AI requests transmit only the selected Korean sentence to the configured HTTPS backend. The backend sends the request to its configured model provider with response storage disabled. No provider API key is shipped in the APK.
- `.kllyrics` backups are portable UTF-8-safe versioned text files.

## Verification boundary
A green CI build proves compilation and tests only. It does not prove Xiaomi overlay permissions, background survival, media-session accuracy, lyric match quality, TTS availability, or live AI hosting. These require device and deployment validation.
