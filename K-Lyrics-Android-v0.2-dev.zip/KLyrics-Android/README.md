# K-Lyrics Android 开发包 v0.2

本包基于此前起始工程，新增：
- `LyricEngine.kt`：标准 LRC 时间戳解析（含一行多个时间戳）及按播放位置查找当前句。
- `LearningMode.kt`：简单/详细查词模式枚举、歌词外观设置模型及本地 SharedPreferences 存储。
- `docs/PRODUCT_SPEC.md`：用户已确认的完整学习模式、交互方案、缓存策略和验收顺序。

## 当前状态（请注意）
这是继续开发用的源码包，不是完整版 APK。新增的解析器和偏好设置数据层尚未接入完整界面；酷狗真实歌词获取、KRC 处理、播放进度轮询、翻译/AI 分析服务、学习面板和离线数据库仍待开发与真机验证。

## 构建
使用 Android Studio 或 GitHub Actions 构建 Debug APK。目标环境为 Android 8.0+，建议在 Xiaomi Civi 4 Pro / HyperOS 上验证悬浮窗和媒体会话行为。
