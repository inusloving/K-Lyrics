package com.example.klyrics

import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class KugouNotificationListener : NotificationListenerService() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onListenerConnected() {
        super.onListenerConnected()
        refreshSessions()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refreshSessions()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refreshSessions()
    }

    private fun refreshSessions() {
        handler.post {
            try {
                val manager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                val sessions: List<MediaSession.Token> =
                    manager.getActiveSessions(ComponentName(this, KugouNotificationListener::class.java))
                val controller = sessions.firstOrNull { token ->
                    val c = android.media.session.MediaController(this, token)
                    val pkg = c.packageName.lowercase()
                    pkg.contains("kugou") || pkg.contains("酷狗")
                }?.let { android.media.session.MediaController(this, it) }

                if (controller != null) {
                    val metadata = controller.metadata
                    val title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                    val artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                    val playing = controller.playbackState?.state ==
                        android.media.session.PlaybackState.STATE_PLAYING
                    val intent = Intent(this, LyricOverlayService::class.java).apply {
                        action = LyricOverlayService.ACTION_UPDATE
                        putExtra(LyricOverlayService.EXTRA_TITLE, title)
                        putExtra(LyricOverlayService.EXTRA_ARTIST, artist)
                        putExtra(LyricOverlayService.EXTRA_PLAYING, playing)
                    }
                    if (android.provider.Settings.canDrawOverlays(this)) {
                        startService(intent)
                    }
                }
            } catch (_: SecurityException) {
                // Notification-listener access may have been revoked.
            } catch (_: Exception) {
                // Media sessions can disappear while the player changes tracks.
            }
        }
    }
}
