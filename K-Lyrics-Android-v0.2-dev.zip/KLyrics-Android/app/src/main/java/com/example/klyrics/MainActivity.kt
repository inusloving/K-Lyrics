package com.example.klyrics

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "K-Lyrics 韩语歌词助手"
            textSize = 24f
        }
        val description = TextView(this).apply {
            text = "第一阶段测试版：识别媒体通知并显示悬浮歌词示例。\n\n请先授予通知读取和悬浮窗权限。"
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }

        val notificationButton = Button(this).apply {
            text = "1. 开启通知读取权限"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        val overlayPermissionButton = Button(this).apply {
            text = "2. 授予悬浮窗权限"
            setOnClickListener {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        val showButton = Button(this).apply {
            text = "3. 显示悬浮歌词示例"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, LyricOverlayService::class.java))
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }

        val hideButton = Button(this).apply {
            text = "隐藏悬浮歌词"
            setOnClickListener {
                stopService(Intent(this@MainActivity, LyricOverlayService::class.java))
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(notificationButton)
        layout.addView(overlayPermissionButton)
        layout.addView(showButton)
        layout.addView(hideButton)
        setContentView(layout)
    }
}
