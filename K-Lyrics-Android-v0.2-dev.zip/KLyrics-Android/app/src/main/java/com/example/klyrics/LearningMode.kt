package com.example.klyrics

enum class LearningMode {
    SIMPLE,
    DETAILED
}

data class LyricAppearance(
    val koreanColor: Int = 0xFFFFFFFF.toInt(),
    val chineseColor: Int = 0xFFA8D8FF.toInt(),
    val activeColor: Int = 0xFFFFD166.toInt(),
    val backgroundColor: Int = 0xCC171923.toInt(),
    val backgroundAlpha: Int = 80,
    val fontSizeSp: Float = 18f
)

/** Small preference wrapper; values remain local to the device. */
class KLyricsSettings(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("klyrics_settings", android.content.Context.MODE_PRIVATE)

    var learningMode: LearningMode
        get() = runCatching { LearningMode.valueOf(prefs.getString("learning_mode", "DETAILED")!!) }
            .getOrDefault(LearningMode.DETAILED)
        set(value) { prefs.edit().putString("learning_mode", value.name).apply() }

    fun appearance(): LyricAppearance = LyricAppearance(
        koreanColor = prefs.getInt("korean_color", 0xFFFFFFFF.toInt()),
        chineseColor = prefs.getInt("chinese_color", 0xFFA8D8FF.toInt()),
        activeColor = prefs.getInt("active_color", 0xFFFFD166.toInt()),
        backgroundColor = prefs.getInt("background_color", 0xCC171923.toInt()),
        backgroundAlpha = prefs.getInt("background_alpha", 80),
        fontSizeSp = prefs.getFloat("font_size_sp", 18f)
    )

    fun saveAppearance(value: LyricAppearance) {
        prefs.edit()
            .putInt("korean_color", value.koreanColor)
            .putInt("chinese_color", value.chineseColor)
            .putInt("active_color", value.activeColor)
            .putInt("background_color", value.backgroundColor)
            .putInt("background_alpha", value.backgroundAlpha.coerceIn(0, 100))
            .putFloat("font_size_sp", value.fontSizeSp.coerceIn(12f, 36f))
            .apply()
    }
}
