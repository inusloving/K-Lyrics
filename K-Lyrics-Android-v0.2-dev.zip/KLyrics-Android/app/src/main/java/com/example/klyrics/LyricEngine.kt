package com.example.klyrics

/** A timestamped lyric line. timeMs is the start time relative to the track. */
data class LyricLine(
    val timeMs: Long,
    val text: String,
    val translation: String? = null
)

/** Parses standard LRC timestamps, including multiple timestamps on one line. */
object LrcParser {
    private val timestamp = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:]([0-9]{1,3}))?]")

    fun parse(content: String): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        content.lineSequence().forEach { rawLine ->
            val matches = timestamp.findAll(rawLine).toList()
            if (matches.isEmpty()) return@forEach
            val lyricText = rawLine.substring(matches.last().range.last + 1).trim()
            if (lyricText.isEmpty()) return@forEach
            matches.forEach matchLoop@{ match ->
                val minutes = match.groupValues[1].toLongOrNull() ?: return@matchLoop
                val seconds = match.groupValues[2].toLongOrNull() ?: return@matchLoop
                val fractionRaw = match.groupValues[3]
                val fractionMs = when (fractionRaw.length) {
                    1 -> (fractionRaw.toLongOrNull() ?: 0L) * 100L
                    2 -> (fractionRaw.toLongOrNull() ?: 0L) * 10L
                    3 -> fractionRaw.toLongOrNull() ?: 0L
                    else -> 0L
                }
                if (seconds >= 60) return@matchLoop
                result += LyricLine((minutes * 60 + seconds) * 1000 + fractionMs, lyricText)
            }
        }
        return result.sortedBy { it.timeMs }
    }
}

/** Returns the latest lyric line whose timestamp is not later than playbackPositionMs. */
fun currentLyricIndex(lines: List<LyricLine>, playbackPositionMs: Long): Int {
    var low = 0
    var high = lines.lastIndex
    var answer = -1
    while (low <= high) {
        val mid = (low + high) ushr 1
        if (lines[mid].timeMs <= playbackPositionMs) {
            answer = mid
            low = mid + 1
        } else {
            high = mid - 1
        }
    }
    return answer
}
