package com.example.klyrics

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class LyricOverlayService : Service() {
    companion object {
        const val ACTION_UPDATE = "com.example.klyrics.UPDATE"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_PLAYING = "playing"
    }

    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var titleView: TextView? = null
    private var artistView: TextView? = null
    private var lyricView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlay()
    }

    private fun createOverlay() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(0xCC171923.toInt())
        }
        titleView = TextView(this).apply {
            text = "等待酷狗播放歌曲"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        artistView = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFB9A5FF.toInt())
        }
        lyricView = TextView(this).apply {
            text = "韩语原文与中文翻译将在后续版本接入"
            textSize = 14f
            setPadding(0, 12, 0, 0)
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(titleView)
        root.addView(artistView)
        root.addView(lyricView)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 180
        }
        windowManager.addView(root, params)
        panel = root
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_UPDATE) {
            val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
            val artist = intent.getStringExtra(EXTRA_ARTIST).orEmpty()
            val playing = intent.getBooleanExtra(EXTRA_PLAYING, false)
            titleView?.text = if (title.isBlank()) "酷狗正在播放" else title
            artistView?.text = artist + if (playing) " · 正在播放" else " · 已暂停"
        }
        return START_STICKY
    }

    override fun onDestroy() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
