# K-Lyrics Android（开发起始版）

这是 K-Lyrics 的 Android 原生项目起始骨架，目标设备为 Xiaomi Civi 4 Pro / Android 16。

## 当前已包含
- Android 原生应用入口
- 通知监听服务注册
- 通过 MediaSessionManager 尝试识别酷狗媒体会话
- 悬浮窗权限引导
- 悬浮歌词窗口示例
- GitHub Actions 云端 Debug APK 构建工作流

## 当前尚未实现
- 尚未接入真实歌词源（LRC/KRC）
- 尚未实现歌词时间轴同步
- 尚未接入韩中翻译服务
- 尚未实现单词/语法 AI 注释
- 尚未在 Xiaomi Civi 4 Pro 真机验证
- 尚未生成或签名 APK

## 云端构建
将本项目放入 GitHub 仓库并推送到 main 分支，或在 Actions 页面手动运行 `Android APK Build`。
构建成功后，在对应工作流运行记录的 Artifacts 中下载 `K-Lyrics-debug-apk`。

## 重要说明
这是开发骨架，不是可直接交付的完整产品。酷狗的包名、媒体会话暴露方式及 HyperOS 后台策略需要在目标手机上实测。请勿将 Debug APK 当作正式发布版本。
